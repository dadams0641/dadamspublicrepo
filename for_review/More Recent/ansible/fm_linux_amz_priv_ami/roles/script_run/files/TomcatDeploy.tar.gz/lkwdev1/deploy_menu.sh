#!/bin/bash
# A menu driven shell script sample template 
## ----------------------------------
# Step #1: Define variables
# ----------------------------------
RED='\033[0;41;30m'
STD='\033[0;0;39m'
 
# ----------------------------------
# Step #2: User defined function
# ----------------------------------
pause(){
  read -p "Press [Enter] key to continue..." fackEnterKey
}

one(){
	/usr/local/bin/deploy_docsoap.sh 
        pause
}
 
# do something in two()
two(){
	/usr/local/bin/deploy_imgsoap.sh
        pause
}
three() {
     /usr/local/bin/deploy_hubsoap.sh
	     pause
}
four () {
     /usr/local/bin/deploy_soap.sh
         pause
}
five () {
     /usr/local/bin/deploy_soapout.sh
         pause
}
six () {
     /usr/local/bin/deploy_soapedm.sh
         pause
}
seven () { 
     /usr/local/bin/deploy_soapedmout.sh
         pause
}
eight () {
     /usr/local/bin/deploy_edm.sh
	     pause
}
nine ()  {
     /usr/local/bin/deploy_gateway.sh
         pause
}
ten  ()  {
     /usr/local/bin/deploy_tcuser.sh
	     pause
}
		 
 
# function to display menus
show_menus() {
	clear
	echo "~~~~~~~~~~~~~~~~~~~~~~~~~"	
	echo " Tomcat Deployment Menu"
	echo "~~~~~~~~~~~~~~~~~~~~~~~~~"
	echo "1. Deploy DocSoap"
	echo "2. Deploy ImgSoap"
	echo "3. Deploy HubSoap"
	echo "4. Deploy Soap"
	echo "5. Deploy SoapOut"
	echo "6. Deploy SoapEDM"
	echo "7. Deploy SoapEDMOut"
	echo "8. Deploy EDMUI - EDM"
	echo "9. Deploy EDMUI - EDMS Document Gateway"
	echo "10. Deploy EDMUI - Tomcat User Soap"
	echo "11. Exit"
}
# read input from the keyboard and take a action
# invoke the one() when the user select 1 from the menu option.
# invoke the two() when the user select 2 from the menu option.
# invoke the three() when the user select 3 from the menu option.
# invoke the four() when the user select 4 from the menu option.
# invoke the five() when the user select 5 from the menu option.
# invoke the six() when the user select 6 from the menu option.
# invoke the seven() when the user select 7 from the menu option.
# Exit when user the user select 8 from the menu option.
read_options(){
	local choice
	read -p "Enter choice [ 1 - 11] " choice
	case $choice in
		1) one ;;
		2) two ;;
		3) three ;;
		4) four ;;
		5) five ;;
		6) six ;;
		7) seven ;;
		8) eight ;;
		9) nine ;; 
		10) ten ;;
		11) exit 0;;
		*) echo -e "${RED}bad choice...${STD}" && sleep 2
	esac
}
 
# ----------------------------------------------
# Step #3: Trap CTRL+C, CTRL+Z and quit singles
# ----------------------------------------------
trap '' SIGINT SIGQUIT SIGTSTP
 
# -----------------------------------
# Step #4: Main logic - infinite loop
# ------------------------------------
while true
do
 
	show_menus
	read_options
done