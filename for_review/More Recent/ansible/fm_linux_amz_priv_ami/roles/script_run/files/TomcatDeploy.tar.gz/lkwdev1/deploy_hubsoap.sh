#!/usr/bin/bash
# UAT Lakewood Hubsoap deployment script
# Version 1.3.6.4
# 1.2.0 Added color coding to messages.  The bottom half of the script is now using variables.  The whole of the script is now using paramiters instead of being hard coded. 
# 1.2.0 Added directory checking to make sure we have our needed directories. 
# 1.3.0 Made the script run in 20 minutes intead of an hour by only doing two runs instead of 20. 
# 1.3.1 Added check to make sure the deployed directory is there
# 1.3.1 fixed various issues
# 1.3.1 Added TCServer variable; changed URLs to use $TCSERVER variable
# 1.3.2 Added TCRUN function.  Makes it easier to change the process checks. 
# 1.3.3 Make The number of Tocmats running a variable. 
# 1.3.4 Fixed removal of the oldest .old file.
# 1.3.5 Added Root Checking.  Is root running this thing or someone else. 
# 1.3.6 Fixed Removal of files; changed PIDFILE variable
# 1.3.6.4 Fixed the process checking 
# Written badly by Drew.

# Deployment file
DN_FILE=hubsoap

# Deploy directory
DEPLOY_DIR=/deployment/$DN_FILE

# War file Backup directory
WARBACK=/home/tomcat/warback

# Set Lock files so this can only be run once (I think)
LOCKDIR=/var/tmp/$DN_FILE/
PIDFILE=$LOCKDIR/javacore.pid

# Variable for the URLS
TCSERVER=$(uname -n)

# Date variable
DDATE=$(date +%F.%T)

# Variable for the total number of Tomcats Running
TCR=2

# Variable for Tomcats running when shutting down some of them. 
TCD=1

# Variable for the Number of Tomcat files deployed
TCF=2

# Add some color to the messages. 
RED='\033[0;41;30m'
STD='\033[0;0;39m'
GRN='\033[30;48;5;82m'
BLU='\033[0;44;97m'

# Tomcat Home Directory
TCHOME=/tomcat/uat/edm/
TCHOME_1=/tomcat/uat/edm/tomcat7_hub_1
TCHOME_2=/tomcat/uat/edm/tomcat7_hub_2

# URLS for disabling the tomcat in the Apache load balancer
URLCATDN1="http://$TCSERVER:8190/jkmanager/?cmd=update&from=list&w=edmhubbalancer&sw=edmhub1&vwa=1"
URLCATDN2="http://$TCSERVER:8190/jkmanager/?cmd=update&from=list&w=edmhubbalancer&sw=edmhub2&vwa=1"

# URLS for enabling the tomcat in the Apache load balancer
URLCATUP1="http://$TCSERVER:8190/jkmanager/?cmd=update&from=list&w=edmhubbalancer&sw=edmhub1&vwa=0"
URLCATUP2="http://$TCSERVER:8190/jkmanager/?cmd=update&from=list&w=edmhubbalancer&sw=edmhub2&vwa=0"

#Check the exit status
error_exit()
{
        echo -e "$1" 1>&2
        exit 1
}

# Check the number of running Tomcats
TCRUN()
{
		ps -ef |grep java |grep tomcat |grep hub |grep conf |grep -v grep |wc -l
}

# Checking to make sure we are running this as Root.  
if [ $(id -u) != "0" ]; then
    echo "You must be the superuser to run this script" >&2
    error_exit "You are not Root.  Please run this script with sudo" 1
fi

# Creating directories needed if they are not there. 
# This is the PID directory
if [ -d $LOCKDIR ]
then 
    echo -e "${BLU} Java Deployment PID Directory exists ${STD}"
	else 
	mkdir -p -m 777 $LOCKDIR
	chown tomcat:tomcat $LOCKDIR
	echo -e "${GRN} Java Deployment PID Directory created ${STD}"
fi
# Deployment directory
if [ -d $DEPLOY_DIR ]
then 
    echo -e "${BLU} Deployment directory exists ${STD}"
	else 
	mkdir -p -m 777 $DEPLOY_DIR
	echo -e "${GRN} $DN_FILE Deployment directory created ${STD}"
fi
# Back up directory
if [ -d $WARBACK ]
then 
    echo -e "${BLU} Warback directory exists ${STD}"
	else 
	mkdir -p -m 775 $WARBACK
	chown tomcat:tomcat $WARBACK
	echo -e "${GRN} Warback directory created ${STD}"
fi
# Deployed directory; this is where we put the new version of the war file. 
if [ -d $TCHOME/deployed/ ]
then 
    echo -e "${BLU} Deployed directory exists ${STD}"
	else 
	mkdir -p -m 775 $TCHOME/deployed/
	chown tomcat:tomcat $TCHOME/deployed/
	echo -e "${GRN} Deployed directory created ${STD}"
fi

# Lock file so that only one copy can be run. 
# remove lock file during exit
trap 'rm -f $PIDFILE; exit' INT TERM EXIT
 
if [ -f $PIDFILE ] ; then                      
    # lock is already held
    echo >&2 -e "${RED} lock not acquired, Is the script already running?  Giving up: $PIDFILE ${STD}"
    exit 1
else                      
    # nobody owns the lock
    echo $$ > "$PIDFILE"         # create the lock file
    
    # ... commands executed under lock / single instance ...
    echo -e "${BLU} lock acquired: $PIDFILE ${STD}"
fi

# Ask the question.  Where are we getting this from?
read -p "URL of $DN_FILE deployment package: " docpkg

# get the package
cd $DEPLOY_DIR
su tomcat -c "wget $docpkg -O $DN_FILE.war"

# Variable for the files. 
DEPLOY_FILE=$(ls $DEPLOY_DIR/* |tail -1)

# Checking to see if we got the file or not.  
if [ -z $DEPLOY_FILE ]; then
   error_exit "${RED} Directory is empty.  Aborting! ${STD}"
elif  [ -s $DEPLOY_FILE ]; then
             for i in $DEPLOY_FILE
             do 
                 clear
    
# Make a backup of the new Deployment file.  
echo -e "${BLU} Making a backup of the deployment file (just in case). ${STD}"
cp $i $TCHOME/deployed/$DN_FILE.war.$DDATE  	

# Disabling Tomcats in the Apache Load Balancer
echo -e "${GRN} Disabling the Odd Tomcats.  Waiting 180 seconds to stop. ${STD}"
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN1" &> /dev/null
sleep 180

# Shutting down the Tomcats
echo -e "${GRN} Stopping Odd Tomcats. ${STD}"
  su - tomcat -c "$TCHOME_1/bin/shutdown.sh"
sleep 30

# Checks to make sure we have the right number of tomcats running. 
TC_DP=$( TCRUN )
if (($TC_DP != $TCD)); then 
	echo -e "Expected $TCD Tocmats, ${RED}found $TC_DP Something went wrong! ${STD}Please check the screen output!"
    error_exit "Too many Tomcats!  Check Screen output."	
	else
	echo -e "${GRN} Checking Tomcats, looking for $TCD found $TC_DP.  Shutdown sucessful ${STD}" 
fi

# Removing the oldest version of the War file.  
echo -e "${GRN} Removing the oldest $DN_FILE ${STD}"  
su - tomcat -c "rm $WARBACK/$DN_FILE.old"
su - tomcat -c "mv $TCHOME_1/webapps/$DN_FILE.old $WARBACK/$DN_FILE.old"
	sleep 10

# Making a backup of the new oldest file
echo -e "${GRN} Backing up old $DN_FILE ${STD}"  
su - tomcat -c "mv $TCHOME_1/webapps/$DN_FILE.war $TCHOME_1/webapps/$DN_FILE.old"


# Removing old application
echo -e "${GRN} Removing old version of $DN_FILE ${STD}"  
su - tomcat -c "rm -rf $TCHOME_1/webapps/$DN_FILE/*"
	sleep 10	

# Removing the old Application directory
echo -e "${GRN} Removing old directory of $DN_FILE ${STD}" 
su - tomcat -c "rmdir $TCHOME_1/webapps/$DN_FILE/" 
	sleep 10

# Copy in new file in to each directory. 
 echo -e "${GRN} Moving new version of $DN_FILE in place ${STD}"  
  cp -p $i $TCHOME_1/webapps/$DN_FILE.war
  if [ "$?" != "0" ]; then
    error_exit "${RED} Copy Failed.  Aborting! ${STD}"  
  fi

# Starting up the Tomcats
echo -e "${GRN} Starting the Odd Tomcats. ${STD}"
  su - tomcat -c "$TCHOME_1/bin/startup.sh"
sleep 30

# Enabling Tomcats in the Apache Load Balancer
echo -e "${GRN} Enabling the Odd Tomcats.  Waiting 180 seconds to stop. ${STD}"
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP1" &> /dev/null
sleep 30

# Checks to make sure we have the right number of tomcats running. 
TC_DP=$( TCRUN )
if (($TC_DP != $TCR)); then 
	echo -e "Expected $TCR Tocmats, ${RED}found $TC_DP Something went wrong! ${STD}Please check the screen output!"
    error_exit "Too many Tomcats!  Check Screen output."	
	else
	echo -e "${GRN} Checking Tomcats, looking for $TCR found $TC_DP.  Shutdown sucessful ${STD}" 
fi

# Disabling Tomcats in the Apache Load Balancer
echo -e "${GRN} Disabling the Even Tomcats.  Waiting 180 seconds to stop. ${STD}"
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN2" &> /dev/null
sleep 180

# Shutting down the Tomcats
echo -e "${GRN} Stopping Even Tomcats. ${STD}"
  su - tomcat -c "$TCHOME_2/bin/shutdown.sh"
sleep 30

# Checks to make sure we have the right number of tomcats running. 
TC_DP=$( TCRUN )
if (($TC_DP != $TCD)); then 
	echo -e "Expected $TCD Tocmats, ${RED}found $TC_DP Something went wrong! ${STD}Please check the screen output!"
    error_exit "Too many Tomcats!  Check Screen output."	
	else
	echo -e "${GRN} Checking Tomcats, looking for $TCD found $TC_DP.  Shutdown sucessful ${STD}" 
fi

# Removing the oldest version of the War file.  
echo -e "${GRN} Removing the old $DN_FILE ${STD}"  
su - tomcat -c "rm $TCHOME_2/webapps/$DN_FILE.old"

# Making a backup of the new oldest file
echo -e "${GRN} Backing up old $DN_FILE ${STD}"  
su - tomcat -c "mv $TCHOME_2/webapps/$DN_FILE.war $TCHOME_2/webapps/$DN_FILE.old"

# Removing old application
echo -e "${GRN} Removing old version of $DN_FILE ${STD}"  
su - tomcat -c "rm -rf $TCHOME_2/webapps/$DN_FILE/*"
	sleep 10	
	
# Removing the old Application directory
echo -e "${GRN} Removing old directory of $DN_FILE ${STD}" 
su - tomcat -c "rmdir $TCHOME_2/webapps/$DN_FILE/" 
	sleep 10

# Copy in new file in to each directory. 
 echo -e "${GRN} Moving new version of $DN_FILE in place ${STD}"  
  cp -p $i $TCHOME_2/webapps/$DN_FILE.war
  if [ "$?" != "0" ]; then
    error_exit "${RED} Copy Failed.  Aborting! ${STD}"  
  fi

# Starting up the Tomcats
echo -e "${GRN} Starting the Odd Tomcats. ${STD}"
  su - tomcat -c "$TCHOME_2/bin/startup.sh"
sleep 30

# Enabling Tomcats in the Apache Load Balancer
echo -e "${GRN} Enabling the Odd Tomcats.  Waiting 180 seconds to stop. ${STD}"
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP2" &> /dev/null
sleep 30

# Checks to make sure we have the right number of tomcats running. 
TC_DP=$( TCRUN )
if (($TC_DP != $TCR)); then 
	echo -e "Expected $TCR Tocmats, ${RED}found $TC_DP Something went wrong! ${STD}Please check the screen output!"
    error_exit "Too many Tomcats!  Check Screen output."	
	else
	echo -e "${GRN} Checking Tomcats, looking for $TCR found $TC_DP.  Shutdown sucessful ${STD}" 
fi

# Deployment complete, now to start the clean up.    
echo -e "${GRN} New $DN_FILE deployed. ${STD}"
 echo -e "${GRN} Removing deployment file. ${STD}"
	rm $i 
done
rm -rf "$LOCKDIR"
trap - INT TERM EXIT
fi

# Final Checks to make sure we get the correct number of war files after we are done. 
find $TCHOME -name $DN_FILE.war -ls 
TC_DF=$(find $TCHOME -name $DN_FILE.war -ls |wc -l)
if (($TC_DF != $TCF)); then 
	echo -e "Expected $TCF $DN_FILE War Files, ${RED}found $TC_DF Something went wrong! ${STD}Please check the screen output!"  
	else
	echo -e "${GRN} Checking $DN_FILE war files, looking for $TCF found $TC_DF.  Deployment sucessful ${STD}" 
fi
read -p  "Press any key to continue... " -n1 -s
