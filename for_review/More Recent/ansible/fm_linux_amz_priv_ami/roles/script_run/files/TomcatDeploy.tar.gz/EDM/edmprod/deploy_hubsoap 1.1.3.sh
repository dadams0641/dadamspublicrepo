#!/usr/bin/bash
# Production EDMS hubsoap deployment script
# Version 1.1.3
# Added directory checking to make sure we have our needed directories. Changed lock menthodology, moved variables around to fix errors.  Changed shell from ksh to bash
# Written badly by Drew. 

# Deploy directory
DEPLOY_DIR=/deployment/hubsoap

# Deployment file
DN_FILE=hubsoap.war

# War file Backup directory
WARBACK=/home/tomcat/warback

# Set Lock files so this can only be run once (I think)
LOCKDIR=/var/tmp/deployhub/
PIDFILE=/var/tmp/deployhub/javacore.pid

# URLS for disabling and enabling the tomcat in the load balancer
URLCATDN1="http://edmprod.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat_doc21&vwa=1"
URLCATDN2="http://edmprod.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat_doc22&vwa=1"
URLCATDN3="http://edmprod.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat_doc23&vwa=1"
URLCATDN4="http://edmprod.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat_doc24&vwa=1"

URLCATUP1="http://edmprod.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat_doc21&vwa=0"
URLCATUP2="http://edmprod.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat_doc22&vwa=0"
URLCATUP3="http://edmprod.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat_doc23&vwa=0"
URLCATUP4="http://edmprod.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat_doc24&vwa=0"

#Check the exit status
error_exit()
{
        echo "$1" 1>&2
        exit 1
}

# Creating directories needed if they are not there. 
# This is the PID directory
if [ -d $LOCKDIR ]
then 
    echo "JavaCore exists"
	else 
	mkdir -p -m 777 $LOCKDIR
	chown tomcat:tomcat $LOCKDIR
	echo "JavaCore created"
fi
# Deployment directory
if [ -d $DEPLOY_DIR ]
then 
    echo "Deployment directory exists"
	else 
	mkdir -p -m 777 $DEPLOY_DIR
	echo "Deployment directory created"
fi
# Back up directory
if [ -d $WARBACK ]
then 
    echo "Warback directory exists"
	else 
	mkdir -p -m 775 $WARBACK
	chown tomcat:tomcat $WARBACK
	echo "Warback directory created"
fi

# Lock file so that only one copy can be run. 
# remove lock file during exit
trap 'rm -f $PIDFILE; exit' INT TERM EXIT
 
if [ -f $PIDFILE ] ; then                      
    # lock is already held
    echo >&2 "lock not acquired, giving up: $PIDFILE"
    exit 1
else                      
    # nobody owns the lock
    echo $$ > "$PIDFILE"         # create the lock file
    
    # ... commands executed under lock / single instance ...
    echo "lock acquired: $PIDFILE"
fi

# Ask the question.  Where are we getting this from?
read -p "URL of deployment package: " docpkg

# get the package
cd $DEPLOY_DIR
su tomcat -c "wget $docpkg -O $DN_FILE"

# Variable for the files. 
DEPLOY_FILE=$(ls $DEPLOY_DIR/* |tail -1)

# Checking to see if we got the file or not.  
if [ -z $DEPLOY_FILE ]; then
   error_exit "Directory is empty.  Aborting!"
elif  [ -s $DEPLOY_FILE ]; then
             for i in $DEPLOY_FILE
             do 
                 clear
  
# Starting in deploying package to the first Tomcat
echo "Disabling the hubsoap 1 Tomcat.  Waiting 180 seconds to stop."
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN1" &> /dev/null
  sleep 180
  echo "hubsoap 1 Tomcat is UP.  Stopping Tomcat."
  su - tomcat -c "/tomcat/lkw_hub1/bin/shutdown.sh"
  sleep 10
  echo "Backing up old hubsoap"
  su - tomcat -c "rm $WARBACK/hubsoap.old"
  sleep 10
  su - tomcat -c "mv /tomcat/lkw_hub1/webapps/hubsoap.old $WARBACK/hubsoap.old"
  sleep 10
  su - tomcat -c "mv /tomcat/lkw_hub1/webapps/hubsoap.war /tomcat/lkw_hub1/webapps/hubsoap.old"
  sleep 10
  echo "Removing old version of hubsoap"
  su - tomcat -c "rm -rf /tomcat/lkw_hub1/webapps/hubsoap/*"
  sleep 20
  su - tomcat -c "rmdir /tomcat/lkw_hub1/webapps/hubsoap/" 
  sleep 10
  echo "Moving new version of hubsoap in place"
  cp -p $i /tomcat/lkw_hub1/webapps/hubsoap.war
  if [ "$?" != "0" ]; then
    error_exit "Copy Failed.  Aborting!"
  fi
  sleep 10
  echo "Starting Tomcat"
  su - tomcat -c "/tomcat/lkw_hub1/bin/startup.sh"
  sleep 10
  echo "enabling Worker."
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP1" &> /dev/null
  
# Starting in deploying package to the second Tomcat
echo "Disabling the hubsoap 2 tomcat.  Waiting 180 seconds to stop."
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN2" &> /dev/null
  sleep 180
  echo "hubsoap 1 Tomcat is UP.  Stopping Tomcat."
  su - tomcat -c "/tomcat/lkw_hub2/bin/shutdown.sh"
  sleep 10
  echo "Backing up old hubsoap"
  su - tomcat -c "mv /tomcat/lkw_hub2/webapps/hubsoap.war /tomcat/lkw_hub2/webapps/hubsoap.old"
  sleep 10
  echo "Removing old version of hubsoap"
  su - tomcat -c "rm -rf /tomcat/lkw_hub2/webapps/hubsoap/*"
  sleep 20
  su - tomcat -c "rmdir /tomcat/lkw_hub2/webapps/hubsoap/" 
  sleep 10
  echo "Moving new version of hubsoap in place"
  cp -p $i /tomcat/lkw_hub2/webapps/hubsoap.war
  if [ "$?" != "0" ]; then
    error_exit "Copy Failed.  Aborting!"
  fi
  sleep 10
  echo "Starting Tomcat"
  su - tomcat -c "/tomcat/lkw_hub2/bin/startup.sh"
  sleep 10
  echo "enabling Worker."
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP2" &> /dev/null
  
# Starting in deploying package to the third Tomcat
echo "Disabling the hubsoap 3 tomcat.  Waiting 180 seconds to stop."
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN3" &> /dev/null
  sleep 180
  echo "hubsoap 2 Tomcat is UP.  Stopping Tomcat."
  su - tomcat -c "/tomcat/lkw_hub3/bin/shutdown.sh"
  sleep 10
  echo "Backing up old hubsoap"
  su - tomcat -c "mv /tomcat/lkw_hub3/webapps/hubsoap.war /tomcat/lkw_hub3/webapps/hubsoap.old"
  sleep 10
  echo "Removing old version of hubsoap"
  su - tomcat -c "rm -rf /tomcat/lkw_hub3/webapps/hubsoap/*"
  sleep 20
  su - tomcat -c "rmdir /tomcat/lkw_hub3/webapps/hubsoap/" 
  sleep 10
  echo "Moving new version of hubsoap in place"
  cp -p $i /tomcat/lkw_hub3/webapps/hubsoap.war
  if [ "$?" != "0" ]; then
    error_exit "Copy Failed.  Aborting!"
  fi
  sleep 10
  echo "Starting Tomcat"
  su - tomcat -c "/tomcat/lkw_hub3/bin/startup.sh"
  sleep 10
  echo "enabling Worker."
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP3" &> /dev/null
  
# Starting in deploying package to the fourth Tomcat
echo "Disabling the hubsoap 4 tomcat.  Waiting 180 seconds to stop."
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN4" &> /dev/null
  sleep 180
  echo "hubsoap 3 Tomcat is UP.  Stopping Tomcat."
  su - tomcat -c "/tomcat/lkw_hub4/bin/shutdown.sh"
  sleep 10
  echo "Backing up old hubsoap"
  su - tomcat -c "mv /tomcat/lkw_hub4/webapps/hubsoap.war /tomcat/lkw_hub4/webapps/hubsoap.old"
  sleep 10
  echo "Removing old version of hubsoap"
  su - tomcat -c "rm -rf /tomcat/lkw_hub4/webapps/hubsoap/*"
  sleep 20
  su - tomcat -c "rmdir /tomcat/lkw_hub4/webapps/hubsoap/" 
  sleep 10
  echo "Moving new version of hubsoap in place"
  cp -p $i /tomcat/lkw_hub4/webapps/hubsoap.war
  if [ "$?" != "0" ]; then
    error_exit "Copy Failed.  Aborting!"
  fi
  sleep 10
  echo "Starting Tomcat"
  su - tomcat -c "/tomcat/lkw_hub4/bin/startup.sh"
  sleep 10
  echo "enabling Worker."
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP4" &> /dev/null

echo "New hubsoaps deployed."
echo "Removing deployment file. "
	rm $i 
done
	rm -rf "$LOCKDIR"
trap - INT TERM EXIT
fi
read -p "Press any key to continue... " -n1 -s
