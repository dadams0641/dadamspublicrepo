#!/usr/bin/ksh
# Half (odd) of the tomcats shutdown
# Version 1.0.0

/usr/loca/bin/tc_doc_odd.down  
/usr/local/bin/tc_img_odd.down  
/usr/local/bin/tc_hub_odd.down  




#!/usr/bin/ksh
# Half (even) of the tomcats shutdown
# Version 1.0.0

/usr/loca/bin/tc_doc_even.down
/usr/local/bin/tc_img_even.down
/usr/local/bin/tc_hub_even.down



#!/usr/bin/ksh
# Tomcats Restart
# Version 1.0.0

# Add some color to the messages. 
RED='\033[0;41;30m'
STD='\033[0;0;39m'
GRN='\033[30;48;5;82m'
BLU='\033[0;44;97m'

#Check the exit status
error_exit()
{
        echo -e "$1" 1>&2
        exit 1
}

# Starting the shutdowns
echo -e "${BLU} Shutting down the Odd Tomcats ${STD}"

/usr/loca/bin/tc_doc_odd.down &   
/usr/local/bin/tc_img_odd.down & 
/usr/local/bin/tc_hub_odd.down & 
wait

# Checks to make sure we have the nubmer of Tomcats down that should be down.
TC_HS=$(ps -ef |grep lkw_hub |grep -v lkw_doc |grep -v lkw_img |grep -v grep |wc -l)
if (($TC_HS != 2)); then 
	echo -e "${BLU} Expected 2 HubSoap instances, ${RED}found $TC_HS Something went wrong! ${STD}Please check the screen output!"  
	exit_error "${RED} Not enough HubSoap Tomcat instances running ${STD}"
	else
	echo -e "${GRN} Checking HubSoap instances, looking for 2 found $TC_HS.  Deployment sucessful ${STD}" 
fi

# Final checks to make sure we have the nubmer of Tomcats down that should be down.
TC_IS=$(ps -ef |grep lkw_img |grep -v lkw_doc |grep -v lkw_hub |grep -v grep |wc -l)
if (($TC_IS != 1)); then 
	echo -e "${BLU} Expected 1 IMGSoap instances, ${RED}found $TC_IS Something went wrong! ${STD}Please check the screen output!"  
	exit_error "${RED} Not enough IMGSoap Tomcat instances running ${STD}"
	else
	echo -e "${GRN} Checking IMGSoap instances, looking for 1 found $TC_IS.  Deployment sucessful ${STD}" 
fi

# Checks to make sure we have the nubmer of Tomcats down that should be down.
TC_DS=$(ps -ef |grep lkw_doc |grep -v lkw_hub |grep -v lkw_img |grep -v grep |wc -l)
if (($TC_DS != 9)); then 
	echo -e "${BLU} Expected 9 DocSoap instances, ${RED}found $TC_DS Something went wrong! ${STD}Please check the screen output!"  
	exit_error "${RED} Not enough DocSoap Tomcat instances running ${STD}"
	else
	echo -e "${GRN} Checking DocSoap instances, looking for 9 found $TC_DS.  Deployment sucessful ${STD}" 
fi

echo -e "${BLU} Starting back up the Odd Tomcats ${STD}"
/usr/loca/bin/tc_doc_odd.up & 
/usr/local/bin/tc_img_odd.up &
/usr/local/bin/tc_hub_odd.up &
wait 

# Checks to make sure we have the nubmer of Tomcats down that should be down.
TC_HS=$(ps -ef |grep lkw_hub |grep -v lkw_doc |grep -v lkw_img |grep -v grep |wc -l)
if (($TC_HS != 4)); then 
	echo -e "${BLU} Expected 4 HubSoap instances, ${RED}found $TC_HS Something went wrong! ${STD}Please check the screen output!"  
	exit_error "${RED} Not enough HubSoap Tomcat instances running ${STD}"
	else
	echo -e "${GRN} Checking HubSoap instances, looking for 4 found $TC_HS.  Deployment sucessful ${STD}" 
fi

# Final checks to make sure we have the nubmer of Tomcats down that should be down.
TC_IS=$(ps -ef |grep lkw_img |grep -v lkw_doc |grep -v lkw_hub |grep -v grep |wc -l)
if (($TC_IS != 2)); then 
	echo -e "${BLU} Expected 2 IMGSoap instances, ${RED}found $TC_IS Something went wrong! ${STD}Please check the screen output!"  
	exit_error "${RED} Not enough IMGSoap Tomcat instances running ${STD}"
	else
	echo -e "${GRN} Checking IMGSoap instances, looking for 2 found $TC_IS.  Deployment sucessful ${STD}" 
fi

# Checks to make sure we have the nubmer of Tomcats down that should be down.
TC_DS=$(ps -ef |grep lkw_doc |grep -v lkw_hub |grep -v lkw_img |grep -v grep |wc -l)
if (($TC_DS != 18)); then 
	echo -e "${BLU} Expected 18 DocSoap instances, ${RED}found $TC_DS Something went wrong! ${STD}Please check the screen output!"  
	exit_error "${RED} Not enough DocSoap Tomcat instances running ${STD}"
	else
	echo -e "${GRN} Checking DocSoap instances, looking for 18 found $TC_DS.  Deployment sucessful ${STD}" 
fi

# Now on to the even number tomcats.  
echo -e " ${BLU} Shutting down the Even Tomcats ${STD} "
/usr/loca/bin/tc_doc_even.down &
/usr/local/bin/tc_img_even.down &
/usr/local/bin/tc_hub_even.down &
wait

# Checks to make sure we have the nubmer of Tomcats down that should be down.
TC_HS=$(ps -ef |grep lkw_hub |grep -v lkw_doc |grep -v lkw_img |grep -v grep |wc -l)
if (($TC_HS != 2)); then 
	echo -e "${BLU} Expected 2 HubSoap instances, ${RED}found $TC_HS Something went wrong! ${STD}Please check the screen output!"  
	exit_error "${RED} Not enough HubSoap Tomcat instances running ${STD}"
	else
	echo -e "${GRN} Checking HubSoap instances, looking for 2 found $TC_HS.  Deployment sucessful ${STD}" 
fi

# Final checks to make sure we have the nubmer of Tomcats down that should be down.
TC_IS=$(ps -ef |grep lkw_img |grep -v lkw_doc |grep -v lkw_hub |grep -v grep |wc -l)
if (($TC_IS != 1)); then 
	echo -e "${BLU} Expected 1 IMGSoap instances, ${RED}found $TC_IS Something went wrong! ${STD}Please check the screen output!"  
	exit_error "${RED} Not enough IMGSoap Tomcat instances running ${STD}"
	else
	echo -e "${GRN} Checking IMGSoap instances, looking for 1 found $TC_IS.  Deployment sucessful ${STD}" 
fi

# Checks to make sure we have the nubmer of Tomcats down that should be down.
TC_DS=$(ps -ef |grep lkw_doc |grep -v lkw_hub |grep -v lkw_img |grep -v grep |wc -l)
if (($TC_DS != 9)); then 
	echo -e "${BLU} Expected 9 DocSoap instances, ${RED}found $TC_DS Something went wrong! ${STD}Please check the screen output!"  
	exit_error "${RED} Not enough DocSoap Tomcat instances running ${STD}"
	else
	echo -e "${GRN} Checking DocSoap instances, looking for 9 found $TC_DS.  Deployment sucessful ${STD}" 
fi

# Starting back up the Even Tomcats
echo -e " ${BLU} STarting back up the Even Tomcats ${STD} "
/usr/loca/bin/tc_doc_even.up & 
/usr/local/bin/tc_img_even.up &
/usr/local/bin/tc_hub_even.up & 
wait

# Checks to make sure we have the nubmer of Tomcats down that should be down.
TC_HS=$(ps -ef |grep lkw_hub grep -v grep |wc -l)
if (($TC_HS != 4)); then 
	echo -e "${BLU} Expected 4 HubSoap instances, ${RED}found $TC_HS Something went wrong! ${STD}Please check the screen output!"  
	exit_error "${RED} Not enough HubSoap Tomcat instances running ${STD}"
	else
	echo -e "${GRN} Checking HubSoap instances, looking for 4 found $TC_HS.  Deployment sucessful ${STD}" 
fi

# Final checks to make sure we have the nubmer of Tomcats down that should be down.
TC_IS=$(ps -ef |grep lkw_img |grep -v grep |wc -l)
if (($TC_IS != 2)); then 
	echo -e "${BLU} Expected 2 IMGSoap instances, ${RED}found $TC_IS Something went wrong! ${STD}Please check the screen output!"  
	exit_error "${RED} Not enough IMGSoap Tomcat instances running ${STD}"
	else
	echo -e "${GRN} Checking IMGSoap instances, looking for 2 found $TC_IS.  Deployment sucessful ${STD}" 
fi

# Checks to make sure we have the nubmer of Tomcats down that should be down.
TC_DS=$(ps -ef |grep lkw_doc |grep -v lkw_hub |grep -v lkw_img |grep -v grep |wc -l)
if (($TC_DS != 18)); then 
	echo -e "${BLU} Expected 18 DocSoap instances, ${RED}found $TC_DS Something went wrong! ${STD}Please check the screen output!"  
	exit_error "${RED} Not enough DocSoap Tomcat instances running ${STD}"
	else
	echo -e "${GRN} Checking DocSoap instances, looking for 18 found $TC_DS.  Deployment sucessful ${STD}" 
fi

# All Tomcats have been restarted at this point (hopefully)
echo -e " ${BLU} All Tomcats have been restarted ${STD} "





#!/usr/bin/ksh
# Half (odd) of the tomcats startup
# Version 1.0.0

/usr/loca/bin/tc_doc_odd.up
/usr/local/bin/tc_img_odd.up
/usr/local/bin/tc_hub_odd.up



#!/usr/bin/ksh
# Half (even) of the tomcats startup
# Version 1.0.0

/usr/loca/bin/tc_doc_even.up
/usr/local/bin/tc_img_even.up
/usr/local/bin/tc_hub_even.up
