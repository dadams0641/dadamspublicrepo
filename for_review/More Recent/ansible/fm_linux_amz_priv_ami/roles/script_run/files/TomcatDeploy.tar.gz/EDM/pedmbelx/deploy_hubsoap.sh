#!/usr/bin/bash
# Production EDMS BE $DN_FILE deployment script
# Version 1.3.7
# 1.2.0 Added color coding to messages.  The bottom half of the script is now using variables.  The whole of the script is now using paramiters instead of being hard coded. 
# 1.2.0 Added directory checking to make sure we have our needed directories. 
# 1.3.0 Made the script run in 20 minutes intead of an hour by only doing two runs instead of 20. 
# 1.3.1 Added check to make sure the deployed directory is there
# 1.3.1 fixed various issues
# 1.3.1 Added TCServer variable; changed URLs to use $TCSERVER variable
# 1.3.2 Added TCRUN function.  Makes it easier to change the process checks. 
# 1.3.3 Make The number of Tocmats running a variable. 
# 1.3.4 Fixed removal of the oldest .old file.
# 1.3.5 Added Root Checking.  Is root running this thing or someone else. 
# 1.3.6 Fixed Removal of files; changed PIDFILE variable
# 1.3.7 normalized the URLs. 
# Written badly by Drew.


#################################################################################
#  The variables below can be edited for the server this is supposed to be on.  # 
#################################################################################

# What file are we deploying
# Deployment file
DN_FILE=hubsoap

# Variable for the total number of Tomcats Running
TCR=10

# Variable for Tomcats running when shutting down some of them. 
TCD=5

# Variable for the Number of Tomcat files deployed
TCF=10

# The instance names are the directories where Tomcat is actually run out of.  
# Instance names
INST1=instance1
INST2=instance2
INST3=instance3
INST4=instance4
INST5=instance5
INST6=instance6
INST7=instance7
INST8=instance8
INST9=instance9
INST10=instance10

# AWS variables
AWSID="Id=i-053f56444086fa129"
TARGETGROUP="arn:aws:elasticloadbalancing:us-east-1:598747928121:targetgroup/pedmbelb01-hubsoap/a1f5c24b86ba9baf"

#####################################################
# The below variables should not NEED to be edited. #
#####################################################


# Tomcat Home Directory - These are the directories where Tomcat resides and is run out of.   The base directory is first, then the individual directories.  
TCHOME=/tomcat/
TCHOME_1=$TCHOME/$INST1
TCHOME_2=$TCHOME/$INST2
TCHOME_3=$TCHOME/$INST3
TCHOME_4=$TCHOME/$INST4
TCHOME_5=$TCHOME/$INST5
TCHOME_6=$TCHOME/$INST6
TCHOME_7=$TCHOME/$INST7
TCHOME_8=$TCHOME/$INST8
TCHOME_9=$TCHOME/$INST9
TCHOME_10=$TCHOME/$INST10


# Set Lock files so this can only be run one at a time (I think)
LOCKDIR=/var/tmp/$DN_FILE/
PIDFILE=$LOCKDIR/$DN_FILE.pid

# Date variable
DDATE=$(date +%m%d%Y)

# Add some color to the messages. 
RED='\033[0;41;30m'
STD='\033[0;0;39m'
GRN='\033[30;48;5;82m'
BLU='\033[0;44;97m'

# Deploy directory
DEPLOY_DIR=/deployment/$DN_FILE

# War file Backup directory
WARBACK=/home/tomcat/warback

########################################################################
# Command line for registering and deregistering the tomcat in the ALB
DEREGISTER="elbv2 deregister-targets --target-group-arn $TARGETGROUP --targets"
REGISTER="elbv2 register-targets --target-group-arn $TARGETGROUP --targets"

# Instance Ports
LBINST1="Port=8081"
LBINST2="Port=8082"
LBINST3="Port=8083"
LBINST4="Port=8084"
LBINST5="Port=8085"
LBINST6="Port=8086"
LBINST7="Port=8087"
LBINST8="Port=8088"
LBINST9="Port=8089"
LBINST10="Port=8090"
  
#Check the exit status - This allows us to print custom error messages when something goes wrong.  
error_exit()
{
        echo -e "$1" 1>&2
        exit 1
}

TCRUN()
{
		ps -ef |grep tomcat |grep doc |grep -v grep |grep -v hub |grep -v img |wc -l
}

# Checking to make sure we are running this as Root.  
if [ $(id -u) != "0" ]; then
    echo "You must be the superuser to run this script" >&2
    error_exit "You are not Root.  Please run this script with sudo" 1
fi

# Creating directories needed if they are not there. 
# This is the PID directory. So that we only run the script once. 
if [ -d $LOCKDIR ]
then 
    echo -e "${BLU} Java Deployment PID Directory exists ${STD}"
	else 
	mkdir -p -m 777 $LOCKDIR
	chown tomcat:tomcat $LOCKDIR
	echo -e "${GRN} Java Deployment PID Directory created ${STD}"
fi
# Deployment directory.  This is where we are going to put the file for deployment to all the Tomcat directories.  
if [ -d $DEPLOY_DIR ]
then 
    echo -e "${BLU} Deployment directory exists ${STD}"
	else 
	mkdir -p -m 777 $DEPLOY_DIR
	echo -e "${GRN} $DN_FILE Deployment directory created ${STD}"
fi
# Back up directory - This is where we back up the oldest version of the deployment war file.  
if [ -d $WARBACK ]
then 
    echo -e "${BLU} Warback directory exists ${STD}"
	else 
	mkdir -p -m 775 $WARBACK
	chown tomcat:tomcat $WARBACK
	echo -e "${GRN} Warback directory created ${STD}"
fi
# Deployed directory; this is where we put the new version of the war file. 
if [ -d $TCHOME/deployed/ ]
then 
    echo -e "${BLU} Deployed directory exists ${STD}"
	else 
	mkdir -p -m 775 $TCHOME/deployed/
	chown tomcat:tomcat $TCHOME/deployed/
	echo -e "${GRN} Deployed directory created ${STD}"
fi

# Lock file so that only one copy can be run. 
# remove lock file during exit
trap 'rm -f $PIDFILE; exit' INT TERM EXIT
 
if [ -f $PIDFILE ] ; then                      
    # lock is already held
    echo >&2 -e "${RED} lock not acquired, Is the script already running?  Giving up: $PIDFILE ${STD}"
    exit 1
else                      
    # nobody owns the lock
    echo $$ > "$PIDFILE"         # create the lock file
    
    # ... commands executed under lock / single instance ...
    echo -e "${BLU} lock acquired: $PIDFILE ${STD}"
fi

# Ask the question.  Where are we getting the war file from?
read -p "URL of DOCSOAP deployment package: " docpkg

# get the package
cd $DEPLOY_DIR
su tomcat -c "wget $docpkg -O $DN_FILE.war"

# Variable for the files. 
DEPLOY_FILE=$(ls $DEPLOY_DIR/* |tail -1)

# Checking to see if we got the file or not.  
if [ -z $DEPLOY_FILE ]; then
   error_exit "${RED} Directory is empty.  Aborting! ${STD}"
elif  [ -s $DEPLOY_FILE ]; then
             for i in $DEPLOY_FILE
             do 
                 clear
# Make a backup of the new Deployment file.  
echo -e "${BLU} Making a backup of the deployment file (just in case). ${STD}"
cp $i $TCHOME/deployed/$DN_FILE.war.$DDATE  	
    
# Disabling Tomcats in the Apache Load Balancer
echo -e "${GRN} Disabling the Odd Tomcats.  Waiting 300 seconds to stop. ${STD}"
aws $DEREGISTER $AWSID,$LBINST1
aws $DEREGISTER $AWSID,$LBINST3
aws $DEREGISTER $AWSID,$LBINST5
aws $DEREGISTER $AWSID,$LBINST7
aws $DEREGISTER $AWSID,$LBINST9
sleep 300

# Shutting down the Tomcats
echo -e "${GRN} Stopping Odd Tomcats. ${STD}"
	  systemctl stop tomcat@instance1
	  systemctl stop tomcat@instance3
	  systemctl stop tomcat@instance5
	  systemctl stop tomcat@instance7
	  systemctl stop tomcat@instance9
sleep 30

# Checks to make sure we have the right number of tomcats running. 
TC_DP=$( TCRUN )
if (($TC_DP != $TCD)); then 
	echo -e "Expected $TCD Tocmats, ${RED}found $TC_DP Something went wrong! ${STD}Please check the screen output!"
    error_exit "Too many Tomcats!  Check Screen output."	
	else
	echo -e "${GRN} Checking Tomcats, looking for $TCD found $TC_DP.  Shutdown sucessful ${STD}" 
fi

# Removing the oldest version of the War file.  
echo -e "${GRN} Removing the oldest $DN_FILE ${STD}"  
su - tomcat -c "rm $WARBACK/$DN_FILE.old"
su - tomcat -c "mv $TCHOME_1/webapps/$DN_FILE.old $WARBACK/$DN_FILE.old"
su - tomcat -c "rm $TCHOME_3/webapps/$DN_FILE.old"
su - tomcat -c "rm $TCHOME_5/webapps/$DN_FILE.old"
su - tomcat -c "rm $TCHOME_7/webapps/$DN_FILE.old"
su - tomcat -c "rm $TCHOME_9/webapps/$DN_FILE.old"
sleep 10

# Making a backup of the new oldest file
echo -e "${GRN} Backing up old $DN_FILE ${STD}"  
su - tomcat -c "mv $TCHOME_1/webapps/$DN_FILE.war $TCHOME_1/webapps/$DN_FILE.old"
su - tomcat -c "mv $TCHOME_3/webapps/$DN_FILE.war $TCHOME_3/webapps/$DN_FILE.old"
su - tomcat -c "mv $TCHOME_7/webapps/$DN_FILE.war $TCHOME_5/webapps/$DN_FILE.old"
su - tomcat -c "mv $TCHOME_7/webapps/$DN_FILE.war $TCHOME_7/webapps/$DN_FILE.old"
su - tomcat -c "mv $TCHOME_9/webapps/$DN_FILE.war $TCHOME_9/webapps/$DN_FILE.old"

# Removing old application
echo -e "${GRN} Removing old version of $DN_FILE ${STD}"  
su - tomcat -c "rm -rf $TCHOME_1/webapps/$DN_FILE/*"
	sleep 10	
su - tomcat -c "rm -rf $TCHOME_3/webapps/$DN_FILE/*"
	sleep 10	
su - tomcat -c "rm -rf $TCHOME_5/webapps/$DN_FILE/*"
	sleep 10	
su - tomcat -c "rm -rf $TCHOME_7/webapps/$DN_FILE/*"
	sleep 10	
su - tomcat -c "rm -rf $TCHOME_9/webapps/$DN_FILE/*"
	sleep 10	
	
# Removing the old Application directory
echo -e "${GRN} Removing old directory of $DN_FILE ${STD}" 
su - tomcat -c "rmdir $TCHOME_1/webapps/$DN_FILE/" 
	sleep 10
su - tomcat -c "rmdir $TCHOME_3/webapps/$DN_FILE/" 
	sleep 10
su - tomcat -c "rmdir $TCHOME_5/webapps/$DN_FILE/" 
	sleep 10
su - tomcat -c "rmdir $TCHOME_7/webapps/$DN_FILE/" 
	sleep 10
su - tomcat -c "rmdir $TCHOME_9/webapps/$DN_FILE/" 
	sleep 10

# Copy in new file in to each directory. 
 echo -e "${GRN} Moving new version of $DN_FILE in place ${STD}"  
  cp -p $i $TCHOME_1/webapps/$DN_FILE.war
  if [ "$?" != "0" ]; then
    error_exit "${RED} Copy Failed.  Aborting! ${STD}"  
  fi
 echo -e "${GRN} Moving new version of $DN_FILE in place ${STD}"  
  cp -p $i $TCHOME_3/webapps/$DN_FILE.war
  if [ "$?" != "0" ]; then
    error_exit "${RED} Copy Failed.  Aborting! ${STD}"  
  fi
 echo -e "${GRN} Moving new version of $DN_FILE in place ${STD}"  
  cp -p $i $TCHOME_5/webapps/$DN_FILE.war
  if [ "$?" != "0" ]; then
    error_exit "${RED} Copy Failed.  Aborting! ${STD}"  
  fi
 echo -e "${GRN} Moving new version of $DN_FILE in place ${STD}"  
  cp -p $i $TCHOME_7/webapps/$DN_FILE.war
  if [ "$?" != "0" ]; then
    error_exit "${RED} Copy Failed.  Aborting! ${STD}"  
  fi
 echo -e "${GRN} Moving new version of $DN_FILE in place ${STD}"  
  cp -p $i $TCHOME_9/webapps/$DN_FILE.war
  if [ "$?" != "0" ]; then
    error_exit "${RED} Copy Failed.  Aborting! ${STD}"  
  fi

# Starting up the Tomcats
echo -e "${GRN} Starting the Odd Tomcats. ${STD}"
  systemctl start tomcat@instance1
  systemctl start tomcat@instance3
  systemctl start tomcat@instance5
  systemctl start tomcat@instance7
  systemctl start tomcat@instance9
  
sleep 30

# Enabling Tomcats in the Apache Load Balancer
echo -e "${GRN} Enabling the Odd Tomcats.  Waiting 180 seconds to stop. ${STD}"
aws $REGISTER $AWSID,$LBINST1
aws $REGISTER $AWSID,$LBINST3
aws $REGISTER $AWSID,$LBINST5
aws $REGISTER $AWSID,$LBINST7
aws $REGISTER $AWSID,$LBINST9
sleep 60

# Checks to make sure we have the right number of tomcats running. 
TC_DP=$( TCRUN )
if (($TC_DP != $TCR)); then 
	echo -e "Expected $TCR Tocmats, ${RED}found $TC_DP Something went wrong! ${STD}Please check the screen output!"
    error_exit "Too many Tomcats!  Check Screen output."	
	else
	echo -e "${GRN} Checking Tomcats, looking for $TCR found $TC_DP.  Shutdown sucessful ${STD}" 
fi

# Disabling Tomcats in the Apache Load Balancer
echo -e "${GRN} Disabling the Even Tomcats.  Waiting 180 seconds to stop. ${STD}"
aws $DEREGISTER $AWSID,$LBINST2
aws $DEREGISTER $AWSID,$LBINST4
aws $DEREGISTER $AWSID,$LBINST6
aws $DEREGISTER $AWSID,$LBINST8
aws $DEREGISTER $AWSID,$LBINST10
sleep 180

# Shutting down the Tomcats
echo -e "${GRN} Stopping Even Tomcats. ${STD}"
  systemctl stop tomcat@instance2
  systemctl stop tomcat@instance4
  systemctl stop tomcat@instance6
  systemctl stop tomcat@instance8
  systemctl stop tomcat@instance10
sleep 30

# Checks to make sure we have the right number of tomcats running. 
TC_DP=$( TCRUN )
if (($TC_DP != $TCD)); then 
	echo -e "Expected $TCD Tocmats, ${RED}found $TC_DP Something went wrong! ${STD}Please check the screen output!"
    error_exit "Too many Tomcats!  Check Screen output."	
	else
	echo -e "${GRN} Checking Tomcats, looking for $TCD found $TC_DP.  Shutdown sucessful ${STD}" 
fi

# Removing the oldest version of the War file.  
echo -e "${GRN} Removing the old $DN_FILE ${STD}"  
su - tomcat -c "rm $TCHOME_2/webapps/$DN_FILE.old"
su - tomcat -c "rm $TCHOME_4/webapps/$DN_FILE.old"
su - tomcat -c "rm $TCHOME_6/webapps/$DN_FILE.old"
su - tomcat -c "rm $TCHOME_8/webapps/$DN_FILE.old"
su - tomcat -c "rm $TCHOME_10/webapps/$DN_FILE.old"

# Making a backup of the new oldest file
echo -e "${GRN} Backing up old $DN_FILE ${STD}"  
su - tomcat -c "mv $TCHOME_2/webapps/$DN_FILE.war $TCHOME_2/webapps/$DN_FILE.old"
su - tomcat -c "mv $TCHOME_4/webapps/$DN_FILE.war $TCHOME_4/webapps/$DN_FILE.old"
su - tomcat -c "mv $TCHOME_6/webapps/$DN_FILE.war $TCHOME_6/webapps/$DN_FILE.old"
su - tomcat -c "mv $TCHOME_8/webapps/$DN_FILE.war $TCHOME_8/webapps/$DN_FILE.old"
su - tomcat -c "mv $TCHOME_10/webapps/$DN_FILE.war $TCHOME_10/webapps/$DN_FILE.old"


# Removing old application
echo -e "${GRN} Removing old version of $DN_FILE ${STD}"  
su - tomcat -c "rm -rf $TCHOME_2/webapps/$DN_FILE/*"
	sleep 10	
su - tomcat -c "rm -rf $TCHOME_4/webapps/$DN_FILE/*"
	sleep 10	
su - tomcat -c "rm -rf $TCHOME_6/webapps/$DN_FILE/*"
	sleep 10	
su - tomcat -c "rm -rf $TCHOME_8/webapps/$DN_FILE/*"
	sleep 10	
su - tomcat -c "rm -rf $TCHOME_10/webapps/$DN_FILE/*"
	sleep 10	
	
# Removing the old Application directory
echo -e "${GRN} Removing old directory of $DN_FILE ${STD}" 
su - tomcat -c "rmdir $TCHOME_2/webapps/$DN_FILE/" 
	sleep 10
su - tomcat -c "rmdir $TCHOME_4/webapps/$DN_FILE/" 
	sleep 10
su - tomcat -c "rmdir $TCHOME_6/webapps/$DN_FILE/" 
	sleep 10
su - tomcat -c "rmdir $TCHOME_8/webapps/$DN_FILE/" 
	sleep 10
su - tomcat -c "rmdir $TCHOME_10/webapps/$DN_FILE/" 
	sleep 10

# Copy in new file in to each directory. 
 echo -e "${GRN} Moving new version of $DN_FILE in place ${STD}"  
  cp -p $i $TCHOME_2/webapps/$DN_FILE.war
  if [ "$?" != "0" ]; then
    error_exit "${RED} Copy Failed.  Aborting! ${STD}"  
  fi
 echo -e "${GRN} Moving new version of $DN_FILE in place ${STD}"  
  cp -p $i $TCHOME_4/webapps/$DN_FILE.war
  if [ "$?" != "0" ]; then
    error_exit "${RED} Copy Failed.  Aborting! ${STD}"  
  fi
 echo -e "${GRN} Moving new version of $DN_FILE in place ${STD}"  
  cp -p $i $TCHOME_6/webapps/$DN_FILE.war
  if [ "$?" != "0" ]; then
    error_exit "${RED} Copy Failed.  Aborting! ${STD}"  
  fi
 echo -e "${GRN} Moving new version of $DN_FILE in place ${STD}"  
  cp -p $i $TCHOME_8/webapps/$DN_FILE.war
  if [ "$?" != "0" ]; then
    error_exit "${RED} Copy Failed.  Aborting! ${STD}"  
  fi
 echo -e "${GRN} Moving new version of $DN_FILE in place ${STD}"  
  cp -p $i $TCHOME_10/webapps/$DN_FILE.war
  if [ "$?" != "0" ]; then
    error_exit "${RED} Copy Failed.  Aborting! ${STD}"  
  fi

# Starting up the Tomcats
echo -e "${GRN} Starting the Odd Tomcats. ${STD}"
  systemctl start tomcat@instance2
  systemctl start tomcat@instance4
  systemctl start tomcat@instance6
  systemctl start tomcat@instance8
  systemctl start tomcat@instance10
sleep 30

# Enabling Tomcats in the Apache Load Balancer
echo -e "${GRN} Enabling the Odd Tomcats.  Waiting 180 seconds to stop. ${STD}"
aws $REGISTER $AWSID,$LBINST2
aws $REGISTER $AWSID,$LBINST4
aws $REGISTER $AWSID,$LBINST6
aws $REGISTER $AWSID,$LBINST8
aws $REGISTER $AWSID,$LBINST10
sleep 30

# Checks to make sure we have the right number of tomcats running. 
TC_DP=$( TCRUN )
if (($TC_DP != $TCR)); then 
	echo -e "Expected $TCR Tocmats, ${RED}found $TC_DP Something went wrong! ${STD}Please check the screen output!"
    error_exit "Too many Tomcats!  Check Screen output."	
	else
	echo -e "${GRN} Checking Tomcats, looking for $TCR found $TC_DP.  Shutdown sucessful ${STD}" 
fi

# Deployment complete, now to start the clean up.    
echo -e "${GRN} New $DN_FILE deployed. ${STD}"
 echo -e "${GRN} Removing deployment file. ${STD}"
	rm $i 
done
rm -rf "$LOCKDIR"
trap - INT TERM EXIT
fi

# Final Checks to make sure we get the correct number of war files after we are done. 
find $TCHOME -name $DN_FILE.war -ls 
TC_DF=$(find $TCHOME -name $DN_FILE.war -ls |wc -l)
if (($TC_DF != $TCF)); then 
	echo -e "Expected $TCF $DN_FILE War Files, ${RED}found $TC_DF Something went wrong! ${STD}Please check the screen output!"  
	else
	echo -e "${GRN} Checking $DN_FILE war files, looking for $TCF found $TC_DF.  Deployment sucessful ${STD}" 
fi
read -p  "Press any key to continue... " -n1 -s
