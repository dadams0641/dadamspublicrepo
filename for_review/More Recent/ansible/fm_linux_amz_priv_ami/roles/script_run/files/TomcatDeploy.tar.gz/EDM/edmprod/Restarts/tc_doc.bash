#!/usr/bin/bash
# Docsoap half of the tomcats shutdown
# Version 1.0.3

# Variable to disable the Tomcat in the Apache Load Balancer
URLDN=1

# Add some color to the messages. 
RED='\033[0;41;30m'
STD='\033[0;0;39m'
GRN='\033[30;48;5;82m'
BLU='\033[0;44;97m'

# Set Lock files so this can only be run once (I think)
LOCKDIR=/var/tmp/rest_docsoap_odd/
PIDFILE=/var/tmp/rest_docsoap_odd/tcrestart.pid

# Creating directories needed if they are not there. 
# This is the PID directory
if [ -d $LOCKDIR ]
then 
    echo -e "${BLU} DocSoap Odd Tomcat Restart PID Directory exists ${STD}"
	else 
	mkdir -p -m 777 $LOCKDIR
	chown tomcat:tomcat $LOCKDIR
	echo -e "${GRN} DocSoap Odd Tomcat Restart PID Directory created ${STD}"
fi

# Lock file so that only one copy can be run. 
# remove lock file during exit
trap 'rm -rf $LOCKDIR; exit' 0 1 2 3 15 
 
if [ -f $PIDFILE ] ; then                      
    # lock is already held
    echo >&2 -e "${RED} lock not acquired, giving up: $PIDFILE ${STD}"
    exit 1
else                      
    # nobody owns the lock
    echo $$ > "$PIDFILE"         # create the lock file
    
    # ... commands executed under lock / single instance ...
    echo -e "${BLU} lock acquired: $PIDFILE ${STD}"
fi

# Disable the Tomcats in the Apache Load balancer
echo -e "${BLU} Disabling the Tomcats in the Apache Load Balancer ${STD}"
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "http://edmprod.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc1&vwa="$URLDN
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "http://edmprod.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc3&vwa="$URLDN
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "http://edmprod.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc7&vwa="$URLDN
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "http://edmprod.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc9&vwa="$URLDN
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "http://edmprod.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc11&vwa="$URLDN
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "http://edmprod.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc13&vwa="$URLDN
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "http://edmprod.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc15&vwa="$URLDN
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "http://edmprod.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc17&vwa="$URLDN
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "http://edmprod.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc19&vwa="$URLDN

# Make the script wait the 3 minutes to make sure the jobs the tomcats are working on finish. 
echo -e "${GRN} Now we wait 3 minutes for processes to finish. ${STD}"
sleep 180

# Set the variable for where Java lives on the server
export JAVA_HOME=/usr/java71_64

# bring down the Tomcats 
echo -e "${BLU} Shutting down the Tomcats. ${STD}"
su tomcat -c "/tomcat/lkw_doc1/bin/shutdown.sh"
su tomcat -c "/tomcat/lkw_doc3/bin/shutdown.sh"
su tomcat -c "/tomcat/lkw_doc7/bin/shutdown.sh"
su tomcat -c "/tomcat/lkw_doc9/bin/shutdown.sh"
su tomcat -c "/tomcat/lkw_doc11/bin/shutdown.sh"
su tomcat -c "/tomcat/lkw_doc13/bin/shutdown.sh"
su tomcat -c "/tomcat/lkw_doc15/bin/shutdown.sh"
su tomcat -c "/tomcat/lkw_doc17/bin/shutdown.sh"
su tomcat -c "/tomcat/lkw_doc19/bin/shutdown.sh"

# Shutdown finished, report that it is done.  
echo -e "${BLU} Tomcat Shutdown has been run. ${STD}"

# Final checks to make sure we have the nubmer of Tomcats down that should be down.
TC_DP=$(ps -ef |grep lkw_doc |grep -v lkw_hub |grep -v lkw_img |grep -v grep |wc -l)
if (($TC_DP != 9)); then 
	echo -e "${BLU} Expected 9 DocSoap instances, ${RED}found $TC_DP Something went wrong! ${STD}Please check the screen output!"  
	else
	echo -e "${GRN} Checking DocSoap instances, looking for 9 found $TC_DP.  Deployment sucessful ${STD}" 
fi

# Complete the deployment and clean up after ourselves.    
echo -e "${GRN} All Odd Tomcats stopped ${STD}"
	rm -rf "$LOCKDIR"
trap - 0 1 2 3 15
exit 0

#!/usr/bin/bash
# Docsoap half of the tomcats shutdown
# Version 1.0.3

# Variable to disable the Tomcat in the Apache Load Balancer
URLDN=1

# Add some color to the messages. 
RED='\033[0;41;30m'
STD='\033[0;0;39m'
GRN='\033[30;48;5;82m'
BLU='\033[0;44;97m'

# Set Lock files so this can only be run once (I think)
LOCKDIR=/var/tmp/rest_docsoap_even/
PIDFILE=/var/tmp/rest_docsoap_even/tcrestart.pid

# Creating directories needed if they are not there. 
# This is the PID directory
if [ -d $LOCKDIR ]
then 
    echo -e "${BLU} DocSoap Even Tomcat Restart PID Directory exists ${STD}"
	else 
	mkdir -p -m 777 $LOCKDIR
	chown tomcat:tomcat $LOCKDIR
	echo -e "${GRN} DocSoap Even Tomcat Restart PID Directory created ${STD}"
fi

# Lock file so that only one copy can be run. 
# remove lock file during exit
trap 'rm -rf $LOCKDIR; exit' 0 1 2 3 15 
 
if [ -f $PIDFILE ] ; then                      
    # lock is already held
    echo >&2 -e "${RED} lock not acquired, giving up: $PIDFILE ${STD}"
    exit 1
else                      
    # nobody owns the lock
    echo $$ > "$PIDFILE"         # create the lock file
    
    # ... commands executed under lock / single instance ...
    echo -e "${BLU} lock acquired: $PIDFILE ${STD}"
fi

# Disable the Tomcats in the Apache Load balancer
echo -e "${BLU} Disabling the Tomcats in the Apache Load Balancer ${STD}"
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "http://edmprod.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc2&vwa="$URLDN
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "http://edmprod.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc4&vwa="$URLDN
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "http://edmprod.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc8&vwa="$URLDN
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "http://edmprod.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat_doc10&vwa="$URLDN
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "http://edmprod.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc12&vwa="$URLDN
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "http://edmprod.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc14&vwa="$URLDN
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "http://edmprod.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc16&vwa="$URLDN
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "http://edmprod.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc18&vwa="$URLDN
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "http://edmprod.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc20&vwa="$URLDN

# Make the script wait the 3 minutes to make sure the jobs the tomcats are working on finish. 
echo -e "${GRN} Now we wait 3 minutes for processes to finish. ${STD}"
sleep 180

# Set the variable for where Java lives on the server
export JAVA_HOME=/usr/java71_64

# bring down the Tomcats 
echo -e "${BLU} Shutting down the Tomcats. ${STD}"
su tomcat -c "/tomcat/lkw_doc2/bin/shutdown.sh"
su tomcat -c "/tomcat/lkw_doc4/bin/shutdown.sh"
su tomcat -c "/tomcat/lkw_doc8/bin/shutdown.sh"
su tomcat -c "/tomcat/lkw_doc10/bin/shutdown.sh"
su tomcat -c "/tomcat/lkw_doc12/bin/shutdown.sh"
su tomcat -c "/tomcat/lkw_doc14/bin/shutdown.sh"
su tomcat -c "/tomcat/lkw_doc16/bin/shutdown.sh"
su tomcat -c "/tomcat/lkw_doc18/bin/shutdown.sh"
su tomcat -c "/tomcat/lkw_doc20/bin/shutdown.sh"

# Shutdown finished, report that it is done.  
echo -e "${BLU} Tomcat Shutdown has been run. ${STD}"

# Final checks to make sure we have the nubmer of Tomcats down that should be down.
TC_DP=$(ps -ef |grep lkw_doc |grep -v lkw_hub |grep -v lkw_img |grep -v grep |wc -l)
if (($TC_DP != 9)); then 
	echo -e "${BLU} Expected 9 DocSoap instances, ${RED}found $TC_DP Something went wrong! ${STD}Please check the screen output!"  
	else
	echo -e "${GRN} Checking DocSoap instances, looking for 9 found $TC_DP.  Deployment sucessful ${STD}" 
fi

# Complete the deployment and clean up after ourselves.    
echo -e "${GRN} All Even Tomcats stopped ${STD}"
	rm -rf "$LOCKDIR"
trap - 0 1 2 3 15
exit 0





#!/usr/bin/bash
# Docsoap half of the tomcats startup
# Version 1.0.3

# Variable to disable the Tomcat in the Apache Load Balancer
URLUP=0

# Add some color to the messages. 
RED='\033[0;41;30m'
STD='\033[0;0;39m'
GRN='\033[30;48;5;82m'
BLU='\033[0;44;97m'

#Check the exit status
error_exit()
{
        echo -e "$1" 1>&2
        exit 1
}

# Set Lock files so this can only be run once (I think)
LOCKDIR=/var/tmp/rest_docsoap_odd/
PIDFILE=/var/tmp/rest_docsoap_odd/tcrestart.pid

# Creating directories needed if they are not there. 
# This is the PID directory
if [ -d $LOCKDIR ]
then 
    echo -e "${BLU} DocSoap Odd Tomcat Restart PID Directory exists ${STD}"
	else 
	mkdir -p -m 777 $LOCKDIR
	chown tomcat:tomcat $LOCKDIR
	echo -e "${GRN} DocSoap Odd Tomcat Restart PID Directory created ${STD}"
fi

# Lock file so that only one copy can be run. 
# remove lock file during exit
trap 'rm -rf $LOCKDIR; exit' 0 1 2 3 15 
 
if [ -f $PIDFILE ] ; then                      
    # lock is already held
    echo >&2 -e "${RED} lock not acquired, giving up: $PIDFILE ${STD}"
    exit 1
else                      
    # nobody owns the lock
    echo $$ > "$PIDFILE"         # create the lock file
    
    # ... commands executed under lock / single instance ...
    echo -e "${BLU} lock acquired: $PIDFILE ${STD}"
fi

# Set the variable for where Java lives on the server
export JAVA_HOME=/usr/java71_64

# bring Up the Tomcats 
echo -e "${BLU} Starting up the Tomcats. ${STD}"
su tomcat -c "/tomcat/lkw_doc1/bin/startup.sh"
su tomcat -c "/tomcat/lkw_doc3/bin/startup.sh"
su tomcat -c "/tomcat/lkw_doc7/bin/startup.sh"
su tomcat -c "/tomcat/lkw_doc9/bin/startup.sh"
su tomcat -c "/tomcat/lkw_doc11/bin/startup.sh"
su tomcat -c "/tomcat/lkw_doc13/bin/startup.sh"
su tomcat -c "/tomcat/lkw_doc15/bin/startup.sh"
su tomcat -c "/tomcat/lkw_doc17/bin/startup.sh"
su tomcat -c "/tomcat/lkw_doc19/bin/startup.sh"

# Startup finished, report that it is done.  
echo -e "${BLU} Tomcat Startup has been run. ${STD}"

# Checks to make sure we have the nubmer of Tomcats up that should be up.
TC_DP=$(ps -ef |grep lkw_doc |grep -v lkw_hub |grep -v lkw_img |grep -v grep |wc -l)
if (($TC_DP != 18)); then 
	echo -e "${BLU} Expected 18 DocSoap instances, ${RED}found $TC_DP Something went wrong! ${STD}Please check the screen output!"  
	exit_error "${RED} Not enough Tomcat instances running ${STD}"
	else
	echo -e "${GRN} Checking DocSoap instances, looking for 18 found $TC_DP.  Deployment sucessful ${STD}" 
fi

# Enable the Tomcats in the Apache Load balancer
echo -e "${BLU} Enabling the Tomcats in the Apache Load Balancer ${STD}"
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "http://edmprod.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc1&vwa="$URLUP
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "http://edmprod.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc3&vwa="$URLUP
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "http://edmprod.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc7&vwa="$URLUP
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "http://edmprod.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc9&vwa="$URLUP
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "http://edmprod.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc11&vwa="$URLUP
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "http://edmprod.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc13&vwa="$URLUP
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "http://edmprod.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc15&vwa="$URLUP
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "http://edmprod.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc17&vwa="$URLUP
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "http://edmprod.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc19&vwa="$URLUP

# Complete the deployment and clean up after ourselves.    
echo -e "${GRN} All Odd Tomcats Started ${STD}"
	rm -rf "$LOCKDIR"
trap - 0 1 2 3 15
exit 0




#!/usr/bin/bash
# Docsoap half of the tomcats startup
# Version 1.0.3

# Variable to disable the Tomcat in the Apache Load Balancer
URLUP=0

# Add some color to the messages. 
RED='\033[0;41;30m'
STD='\033[0;0;39m'
GRN='\033[30;48;5;82m'
BLU='\033[0;44;97m'

#Check the exit status
error_exit()
{
        echo -e "$1" 1>&2
        exit 1
}

# Set Lock files so this can only be run once (I think)
LOCKDIR=/var/tmp/rest_docsoap_even/
PIDFILE=/var/tmp/rest_docsoap_even/tcrestart.pid

# Creating directories needed if they are not there. 
# This is the PID directory
if [ -d $LOCKDIR ]
then 
    echo -e "${BLU} DocSoap Odd Tomcat Restart PID Directory exists ${STD}"
	else 
	mkdir -p -m 777 $LOCKDIR
	chown tomcat:tomcat $LOCKDIR
	echo -e "${GRN} DocSoap Odd Tomcat Restart PID Directory created ${STD}"
fi

# Lock file so that only one copy can be run. 
# remove lock file during exit
trap 'rm -rf $LOCKDIR; exit' 0 1 2 3 15 
 
if [ -f $PIDFILE ] ; then                      
    # lock is already held
    echo >&2 -e "${RED} lock not acquired, giving up: $PIDFILE ${STD}"
    exit 1
else                      
    # nobody owns the lock
    echo $$ > "$PIDFILE"         # create the lock file
    
    # ... commands executed under lock / single instance ...
    echo -e "${BLU} lock acquired: $PIDFILE ${STD}"
fi

# Creating directories needed if they are not there. 
# This is the PID directory
if [ -d $LOCKDIR ]
then 
    echo -e "${BLU} DocSoap Odd Tomcat Restart PID Directory exists ${STD}"
	else 
	mkdir -p -m 777 $LOCKDIR
	chown tomcat:tomcat $LOCKDIR
	echo -e "${GRN} DocSoap Odd Tomcat Restart PID Directory created ${STD}"
fi

# Lock file so that only one copy can be run. 
# remove lock file during exit
trap 'rm -f $PIDFILE; exit' INT TERM EXIT
 
if [ -f $PIDFILE ] ; then                      
    # lock is already held
    echo >&2 -e "${RED} lock not acquired, giving up: $PIDFILE ${STD}"
    exit 1
else                      
    # nobody owns the lock
    echo $$ > "$PIDFILE"         # create the lock file
    
    # ... commands executed under lock / single instance ...
    echo -e "${BLU} lock acquired: $PIDFILE ${STD}"
fi

# Set the variable for where Java lives on the server
export JAVA_HOME=/usr/java71_64

# bring down the Tomcats 
echo -e "${BLU} Starting up the Tomcats. ${STD}"
su tomcat -c "/tomcat/lkw_doc2/bin/startup.sh"
su tomcat -c "/tomcat/lkw_doc4/bin/startup.sh"
su tomcat -c "/tomcat/lkw_doc8/bin/startup.sh"
su tomcat -c "/tomcat/lkw_doc10/bin/startup.sh"
su tomcat -c "/tomcat/lkw_doc12/bin/startup.sh"
su tomcat -c "/tomcat/lkw_doc14/bin/startup.sh"
su tomcat -c "/tomcat/lkw_doc16/bin/startup.sh"
su tomcat -c "/tomcat/lkw_doc18/bin/startup.sh"
su tomcat -c "/tomcat/lkw_doc20/bin/startup.sh"

# Startup finished, report that it is done.  
echo -e "${BLU} Tomcat Startup has been run. ${STD}"

# Checks to make sure we have the nubmer of Tomcats down that should be down.
TC_DP=$(ps -ef |grep lkw_doc |grep -v lkw_hub |grep -v lkw_img |grep -v grep |wc -l)
if (($TC_DP != 18)); then 
	echo -e "${BLU} Expected 18 DocSoap instances, ${RED}found $TC_DP Something went wrong! ${STD}Please check the screen output!"  
	exit_error "${RED} Not enough Tomcat instances running ${STD}"
	else
	echo -e "${GRN} Checking DocSoap instances, looking for 18 found $TC_DP.  Deployment sucessful ${STD}" 
fi

# Enable the Tomcats in the Apache Load balancer
echo -e "${BLU} Enabling the Tomcats in the Apache Load Balancer ${STD}"
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "http://edmprod.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc2&vwa="$URLUP
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "http://edmprod.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc4&vwa="$URLUP
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "http://edmprod.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc8&vwa="$URLUP
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "http://edmprod.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat_doc10&vwa="$URLUP
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "http://edmprod.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc12&vwa="$URLUP
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "http://edmprod.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc14&vwa="$URLUP
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "http://edmprod.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc16&vwa="$URLUP
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "http://edmprod.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc18&vwa="$URLUP
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "http://edmprod.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc20&vwa="$URLUP

# Complete the deployment and clean up after ourselves.    
echo -e "${GRN} All Odd Tomcats Started ${STD}"
	rm -rf "$LOCKDIR"
trap - 0 1 2 3 15
exit 0
