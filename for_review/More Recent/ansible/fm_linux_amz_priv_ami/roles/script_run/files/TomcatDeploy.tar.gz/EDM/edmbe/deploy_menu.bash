#!/usr/bin/ksh
# Production EDMS BE hubsoap deployment script

#Check the exit status
error_exit()
{
        echo "$1" 1>&2
        exit 1
}

# Variable for the files. 
deploy_file=$(ls /deployment/hubsoap/* |tail -1)


# Set Lock files so this can only be run once (I think)
lockdir=/var/tmp/javacore/
pidfile=/var/tmp/javacore/javacore.pid
if ( mkdir ${lockdir} ) 2> /dev/null; then
        echo $$ > $pidfile
        trap 'rm -rf "$lockdir"; exit $?' INT TERM EXIT
print -n "URL of deployment package: ";read docpkg; print ""
# get the package
cd /deployment/hubsoap/
su tomcat -c "wget $docpkg -O hubsoap.war"
if [ -z "$(ls -A /deployment/hubsoap/)" ]; then
   error_exit "Directory is empty.  Aborting!"
elif  [ -s /deployment/hubsoap/hubsoap.war ]; then
             for i in $deploy_file
do 
  clear
  
  # URLS for disabling and enabling the tomcat in the load balancer
  URLCATDN1="http://in-pedmbeax01.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat1&vwa=1"
  URLCATDN2="http://in-pedmbeax01.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat2&vwa=1"
  URLCATDN3="http://in-pedmbeax01.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat3&vwa=1"
  URLCATDN4="http://in-pedmbeax01.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat4&vwa=1"
  URLCATDN5="http://in-pedmbeax01.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat5&vwa=1"
  URLCATDN6="http://in-pedmbeax01.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat6&vwa=1"
  URLCATDN7="http://in-pedmbeax01.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat7&vwa=1"
  URLCATDN8="http://in-pedmbeax01.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat8&vwa=1"
  URLCATDN9="http://in-pedmbeax01.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat9&vwa=1"
  URLCATDN10="http://in-pedmbeax01.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat10&vwa=1"
  URLCATDN11="http://in-pedmbeax01.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat11&vwa=1"
  URLCATDN12="http://in-pedmbeax01.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat12&vwa=1"
  URLCATDN13="http://in-pedmbeax01.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat13&vwa=1"
  URLCATDN14="http://in-pedmbeax01.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat14&vwa=1"
  URLCATDN15="http://in-pedmbeax01.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat15&vwa=1"
  URLCATDN16="http://in-pedmbeax01.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat16&vwa=1"
  URLCATDN17="http://in-pedmbeax01.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat17&vwa=1"
  URLCATDN18="http://in-pedmbeax01.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat18&vwa=1"
  URLCATDN19="http://in-pedmbeax01.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat19&vwa=1"
  URLCATDN20="http://in-pedmbeax01.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat20&vwa=1"
    
  URLCATUP1="http://in-pedmbeax01.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat1&vwa=0"
  URLCATUP2="http://in-pedmbeax01.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat2&vwa=0"
  URLCATUP3="http://in-pedmbeax01.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat3&vwa=0"
  URLCATUP4="http://in-pedmbeax01.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat4&vwa=0"
  URLCATUP5="http://in-pedmbeax01.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat5&vwa=0"
  URLCATUP6="http://in-pedmbeax01.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat6&vwa=0"
  URLCATUP7="http://in-pedmbeax01.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat7&vwa=0"
  URLCATUP8="http://in-pedmbeax01.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat8&vwa=0"
  URLCATUP9="http://in-pedmbeax01.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat9&vwa=0"
  URLCATUP10="http://in-pedmbeax01.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat10&vwa=0"
  URLCATUP11="http://in-pedmbeax01.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat11&vwa=0"
  URLCATUP12="http://in-pedmbeax01.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat12&vwa=0"
  URLCATUP13="http://in-pedmbeax01.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat13&vwa=0"
  URLCATUP14="http://in-pedmbeax01.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat14&vwa=0"
  URLCATUP15="http://in-pedmbeax01.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat15&vwa=0"
  URLCATUP16="http://in-pedmbeax01.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat16&vwa=0"
  URLCATUP17="http://in-pedmbeax01.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat17&vwa=0"
  URLCATUP18="http://in-pedmbeax01.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat18&vwa=0"
  URLCATUP19="http://in-pedmbeax01.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat19&vwa=0"
  URLCATUP20="http://in-pedmbeax01.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat20&vwa=0"
  
  
  # Starting in deploying package to the first Tomcat
echo "Disabling the hubsoap 1 Tomcat.  Waiting 180 seconds to stop."
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN1" &> /dev/null
  sleep 180
  echo "hubsoap 1 Tomcat is UP.  Stopping Tomcat."
  su - tomcat -c "/tomcat/tomcat01/bin/shutdown.sh"
  sleep 10
  echo "Backing up old hubsoap"
  su - tomcat -c "rm /home/tomcat/warback/hubsoap.old"
  sleep 10
  su - tomcat -c "mv /tomcat/tomcat01/webapps/hubsoap.old /home/tomcat/warback/hubsoap.old"
  sleep 10
  su - tomcat -c "mv /tomcat/tomcat01/webapps/hubsoap.war /tomcat/tomcat01/webapps/hubsoap.old"
  sleep 10
  echo "Removing old version of hubsoap"
  su - tomcat -c "rm -rf /tomcat/tomcat01/webapps/hubsoap/*"
  sleep 20
  su - tomcat -c "rmdir /tomcat/tomcat01/webapps/hubsoap/" 
  sleep 10
  echo "Moving new version of hubsoap in place"
  cp -p $i /tomcat/tomcat01/webapps/hubsoap.war
  if [ "$?" != "0" ]; then
    error_exit "Copy Failed.  Aborting!"
  fi
  sleep 10
  echo "Starting Tomcat"
  su - tomcat -c "/tomcat/tomcat01/bin/startup.sh"
  sleep 10
  echo "enabling Worker."
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP1" &> /dev/null
  
  # Starting in deploying package to the second Tomcat
echo "Disabling the hubsoap 2 tomcat.  Waiting 180 seconds to stop."
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN2" &> /dev/null
  sleep 180
  echo "hubsoap 1 Tomcat is UP.  Stopping Tomcat."
  su - tomcat -c "/tomcat/tomcat02/bin/shutdown.sh"
  sleep 10
  echo "Backing up old hubsoap"
  su - tomcat -c "mv /tomcat/tomcat02/webapps/hubsoap.war /tomcat/tomcat02/webapps/hubsoap.old"
  sleep 10
  echo "Removing old version of hubsoap"
  su - tomcat -c "rm -rf /tomcat/tomcat02/webapps/hubsoap/*"
  sleep 20
  su - tomcat -c "rmdir /tomcat/tomcat02/webapps/hubsoap/" 
  sleep 10
  echo "Moving new version of hubsoap in place"
  cp -p $i /tomcat/tomcat02/webapps/hubsoap.war
  if [ "$?" != "0" ]; then
    error_exit "Copy Failed.  Aborting!"
  fi
  sleep 10
  echo "Starting Tomcat"
  su - tomcat -c "/tomcat/tomcat02/bin/startup.sh"
  sleep 10
  echo "enabling Worker."
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP2" &> /dev/null
  
  # Starting in deploying package to the third Tomcat
echo "Disabling the hubsoap 3 tomcat.  Waiting 180 seconds to stop."
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN3" &> /dev/null
  sleep 180
  echo "hubsoap 2 Tomcat is UP.  Stopping Tomcat."
  su - tomcat -c "/tomcat/tomcat03/bin/shutdown.sh"
  sleep 10
  echo "Backing up old hubsoap"
  su - tomcat -c "mv /tomcat/tomcat03/webapps/hubsoap.war /tomcat/tomcat03/webapps/hubsoap.old"
  sleep 10
  echo "Removing old version of hubsoap"
  su - tomcat -c "rm -rf /tomcat/tomcat03/webapps/hubsoap/*"
  sleep 20
  su - tomcat -c "rmdir /tomcat/tomcat03/webapps/hubsoap/" 
  sleep 10
  echo "Moving new version of hubsoap in place"
  cp -p $i /tomcat/tomcat03/webapps/hubsoap.war
  if [ "$?" != "0" ]; then
    error_exit "Copy Failed.  Aborting!"
  fi
  sleep 10
  echo "Starting Tomcat"
  su - tomcat -c "/tomcat/tomcat03/bin/startup.sh"
  sleep 10
  echo "enabling Worker."
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP3" &> /dev/null
  
  # Starting in deploying package to the fourth Tomcat
echo "Disabling the hubsoap 4 tomcat.  Waiting 180 seconds to stop."
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN4" &> /dev/null
  sleep 180
  echo "hubsoap 3 Tomcat is UP.  Stopping Tomcat."
  su - tomcat -c "/tomcat/tomcat04/bin/shutdown.sh"
  sleep 10
  echo "Backing up old hubsoap"
  su - tomcat -c "mv /tomcat/tomcat04/webapps/hubsoap.war /tomcat/tomcat04/webapps/hubsoap.old"
  sleep 10
  echo "Removing old version of hubsoap"
  su - tomcat -c "rm -rf /tomcat/tomcat04/webapps/hubsoap/*"
  sleep 20
  su - tomcat -c "rmdir /tomcat/tomcat04/webapps/hubsoap/" 
  sleep 10
  echo "Moving new version of hubsoap in place"
  cp -p $i /tomcat/tomcat04/webapps/hubsoap.war
  if [ "$?" != "0" ]; then
    error_exit "Copy Failed.  Aborting!"
  fi
  sleep 10
  echo "Starting Tomcat"
  su - tomcat -c "/tomcat/tomcat04/bin/startup.sh"
  sleep 10
  echo "enabling Worker."
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP4" &> /dev/null

# Starting in deploying package to the fourth Tomcat
echo "Disabling the hubsoap 5 tomcat.  Waiting 180 seconds to stop."
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN5" &> /dev/null
  sleep 180
  echo "hubsoap 3 Tomcat is UP.  Stopping Tomcat."
  su - tomcat -c "/tomcat/tomcat05/bin/shutdown.sh"
  sleep 10
  echo "Backing up old hubsoap"
  su - tomcat -c "mv /tomcat/tomcat05/webapps/hubsoap.war /tomcat/tomcat05/webapps/hubsoap.old"
  sleep 10
  echo "Removing old version of hubsoap"
  su - tomcat -c "rm -rf /tomcat/tomcat05/webapps/hubsoap/*"
  sleep 20
  su - tomcat -c "rmdir /tomcat/tomcat05/webapps/hubsoap/" 
  sleep 10
  echo "Moving new version of hubsoap in place"
  cp -p $i /tomcat/tomcat05/webapps/hubsoap.war
  if [ "$?" != "0" ]; then
    error_exit "Copy Failed.  Aborting!"
  fi
  sleep 10
  echo "Starting Tomcat"
  su - tomcat -c "/tomcat/tomcat05/bin/startup.sh"
  sleep 10
  echo "enabling Worker."
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP5" &> /dev/null

# Starting in deploying package to the fourth Tomcat
echo "Disabling the hubsoap 6 tomcat.  Waiting 180 seconds to stop."
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN6" &> /dev/null
  sleep 180
  echo "hubsoap 3 Tomcat is UP.  Stopping Tomcat."
  su - tomcat -c "/tomcat/tomcat06/bin/shutdown.sh"
  sleep 10
  echo "Backing up old hubsoap"
  su - tomcat -c "mv /tomcat/tomcat06/webapps/hubsoap.war /tomcat/tomcat06/webapps/hubsoap.old"
  sleep 10
  echo "Removing old version of hubsoap"
  su - tomcat -c "rm -rf /tomcat/tomcat06/webapps/hubsoap/*"
  sleep 20
  su - tomcat -c "rmdir /tomcat/tomcat06/webapps/hubsoap/" 
  sleep 10
  echo "Moving new version of hubsoap in place"
  cp -p $i /tomcat/tomcat06/webapps/hubsoap.war
  if [ "$?" != "0" ]; then
    error_exit "Copy Failed.  Aborting!"
  fi
  sleep 10
  echo "Starting Tomcat"
  su - tomcat -c "/tomcat/tomcat06/bin/startup.sh"
  sleep 10
  echo "enabling Worker."
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP6" &> /dev/null
  
  # Starting in deploying package to the fourth Tomcat
echo "Disabling the hubsoap 7 tomcat.  Waiting 180 seconds to stop."
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN7" &> /dev/null
  sleep 180
  echo "hubsoap 3 Tomcat is UP.  Stopping Tomcat."
  su - tomcat -c "/tomcat/tomcat07/bin/shutdown.sh"
  sleep 10
  echo "Backing up old hubsoap"
  su - tomcat -c "mv /tomcat/tomcat07/webapps/hubsoap.war /tomcat/tomcat07/webapps/hubsoap.old"
  sleep 10
  echo "Removing old version of hubsoap"
  su - tomcat -c "rm -rf /tomcat/tomcat07/webapps/hubsoap/*"
  sleep 20
  su - tomcat -c "rmdir /tomcat/tomcat07/webapps/hubsoap/" 
  sleep 10
  echo "Moving new version of hubsoap in place"
  cp -p $i /tomcat/tomcat07/webapps/hubsoap.war
  if [ "$?" != "0" ]; then
    error_exit "Copy Failed.  Aborting!"
  fi
  sleep 10
  echo "Starting Tomcat"
  su - tomcat -c "/tomcat/tomcat07/bin/startup.sh"
  sleep 10
  echo "enabling Worker."
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP7" &> /dev/null
  
  # Starting in deploying package to the fourth Tomcat
echo "Disabling the hubsoap 8 tomcat.  Waiting 180 seconds to stop."
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN8" &> /dev/null
  sleep 180
  echo "hubsoap 3 Tomcat is UP.  Stopping Tomcat."
  su - tomcat -c "/tomcat/tomcat08/bin/shutdown.sh"
  sleep 10
  echo "Backing up old hubsoap"
  su - tomcat -c "mv /tomcat/tomcat08/webapps/hubsoap.war /tomcat/tomcat08/webapps/hubsoap.old"
  sleep 10
  echo "Removing old version of hubsoap"
  su - tomcat -c "rm -rf /tomcat/tomcat08/webapps/hubsoap/*"
  sleep 20
  su - tomcat -c "rmdir /tomcat/tomcat08/webapps/hubsoap/" 
  sleep 10
  echo "Moving new version of hubsoap in place"
  cp -p $i /tomcat/tomcat08/webapps/hubsoap.war
  if [ "$?" != "0" ]; then
    error_exit "Copy Failed.  Aborting!"
  fi
  sleep 10
  echo "Starting Tomcat"
  su - tomcat -c "/tomcat/tomcat08/bin/startup.sh"
  sleep 10
  echo "enabling Worker."
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP8" &> /dev/null
  
  # Starting in deploying package to the fourth Tomcat
echo "Disabling the hubsoap 9 tomcat.  Waiting 180 seconds to stop."
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN9" &> /dev/null
  sleep 180
  echo "hubsoap 3 Tomcat is UP.  Stopping Tomcat."
  su - tomcat -c "/tomcat/tomcat09/bin/shutdown.sh"
  sleep 10
  echo "Backing up old hubsoap"
  su - tomcat -c "mv /tomcat/tomcat09/webapps/hubsoap.war /tomcat/tomcat09/webapps/hubsoap.old"
  sleep 10
  echo "Removing old version of hubsoap"
  su - tomcat -c "rm -rf /tomcat/tomcat09/webapps/hubsoap/*"
  sleep 20
  su - tomcat -c "rmdir /tomcat/tomcat09/webapps/hubsoap/" 
  sleep 10
  echo "Moving new version of hubsoap in place"
  cp -p $i /tomcat/tomcat09/webapps/hubsoap.war
  if [ "$?" != "0" ]; then
    error_exit "Copy Failed.  Aborting!"
  fi
  sleep 10
  echo "Starting Tomcat"
  su - tomcat -c "/tomcat/tomcat09/bin/startup.sh"
  sleep 10
  echo "enabling Worker."
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP9" &> /dev/null
  
  # Starting in deploying package to the fourth Tomcat
echo "Disabling the hubsoap 10 tomcat.  Waiting 180 seconds to stop."
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN10" &> /dev/null
  sleep 180
  echo "hubsoap 3 Tomcat is UP.  Stopping Tomcat."
  su - tomcat -c "/tomcat/tomcat10/bin/shutdown.sh"
  sleep 10
  echo "Backing up old hubsoap"
  su - tomcat -c "mv /tomcat/tomcat10/webapps/hubsoap.war /tomcat/tomcat10/webapps/hubsoap.old"
  sleep 10
  echo "Removing old version of hubsoap"
  su - tomcat -c "rm -rf /tomcat/tomcat10/webapps/hubsoap/*"
  sleep 20
  su - tomcat -c "rmdir /tomcat/tomcat10/webapps/hubsoap/" 
  sleep 10
  echo "Moving new version of hubsoap in place"
  cp -p $i /tomcat/tomcat10/webapps/hubsoap.war
  if [ "$?" != "0" ]; then
    error_exit "Copy Failed.  Aborting!"
  fi
  sleep 10
  echo "Starting Tomcat"
  su - tomcat -c "/tomcat/tomcat10/bin/startup.sh"
  sleep 10
  echo "enabling Worker."
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP10" &> /dev/null
  
  # Starting in deploying package to the fourth Tomcat
echo "Disabling the hubsoap 11 tomcat.  Waiting 180 seconds to stop."
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN11" &> /dev/null
  sleep 180
  echo "hubsoap 3 Tomcat is UP.  Stopping Tomcat."
  su - tomcat -c "/tomcat/tomcat11/bin/shutdown.sh"
  sleep 10
  echo "Backing up old hubsoap"
  su - tomcat -c "mv /tomcat/tomcat11/webapps/hubsoap.war /tomcat/tomcat11/webapps/hubsoap.old"
  sleep 10
  echo "Removing old version of hubsoap"
  su - tomcat -c "rm -rf /tomcat/tomcat11/webapps/hubsoap/*"
  sleep 20
  su - tomcat -c "rmdir /tomcat/tomcat11/webapps/hubsoap/" 
  sleep 10
  echo "Moving new version of hubsoap in place"
  cp -p $i /tomcat/tomcat11/webapps/hubsoap.war
  if [ "$?" != "0" ]; then
    error_exit "Copy Failed.  Aborting!"
  fi
  sleep 10
  echo "Starting Tomcat"
  su - tomcat -c "/tomcat/tomcat11/bin/startup.sh"
  sleep 10
  echo "enabling Worker."
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP11" &> /dev/null
  
  # Starting in deploying package to the fourth Tomcat
echo "Disabling the hubsoap 12 tomcat.  Waiting 180 seconds to stop."
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN12" &> /dev/null
  sleep 180
  echo "hubsoap 3 Tomcat is UP.  Stopping Tomcat."
  su - tomcat -c "/tomcat/tomcat12/bin/shutdown.sh"
  sleep 10
  echo "Backing up old hubsoap"
  su - tomcat -c "mv /tomcat/tomcat12/webapps/hubsoap.war /tomcat/tomcat12/webapps/hubsoap.old"
  sleep 10
  echo "Removing old version of hubsoap"
  su - tomcat -c "rm -rf /tomcat/tomcat12/webapps/hubsoap/*"
  sleep 20
  su - tomcat -c "rmdir /tomcat/tomcat12/webapps/hubsoap/" 
  sleep 10
  echo "Moving new version of hubsoap in place"
  cp -p $i /tomcat/tomcat12/webapps/hubsoap.war
  if [ "$?" != "0" ]; then
    error_exit "Copy Failed.  Aborting!"
  fi
  sleep 10
  echo "Starting Tomcat"
  su - tomcat -c "/tomcat/tomcat12/bin/startup.sh"
  sleep 10
  echo "enabling Worker."
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP12" &> /dev/null
  
  # Starting in deploying package to the fourth Tomcat
echo "Disabling the hubsoap 12 tomcat.  Waiting 180 seconds to stop."
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN13" &> /dev/null
  sleep 180
  echo "hubsoap 3 Tomcat is UP.  Stopping Tomcat."
  su - tomcat -c "/tomcat/tomcat13/bin/shutdown.sh"
  sleep 10
  echo "Backing up old hubsoap"
  su - tomcat -c "mv /tomcat/tomcat13/webapps/hubsoap.war /tomcat/tomcat13/webapps/hubsoap.old"
  sleep 10
  echo "Removing old version of hubsoap"
  su - tomcat -c "rm -rf /tomcat/tomcat13/webapps/hubsoap/*"
  sleep 20
  su - tomcat -c "rmdir /tomcat/tomcat13/webapps/hubsoap/" 
  sleep 10
  echo "Moving new version of hubsoap in place"
  cp -p $i /tomcat/tomcat13/webapps/hubsoap.war
  if [ "$?" != "0" ]; then
    error_exit "Copy Failed.  Aborting!"
  fi
  sleep 10
  echo "Starting Tomcat"
  su - tomcat -c "/tomcat/tomcat13/bin/startup.sh"
  sleep 10
  echo "enabling Worker."
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP13" &> /dev/null
  # Starting in deploying package to the fourth Tomcat
echo "Disabling the hubsoap 14 tomcat.  Waiting 180 seconds to stop."
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN14" &> /dev/null
  sleep 180
  echo "hubsoap 3 Tomcat is UP.  Stopping Tomcat."
  su - tomcat -c "/tomcat/tomcat14/bin/shutdown.sh"
  sleep 10
  echo "Backing up old hubsoap"
  su - tomcat -c "mv /tomcat/tomcat14/webapps/hubsoap.war /tomcat/tomcat14/webapps/hubsoap.old"
  sleep 10
  echo "Removing old version of hubsoap"
  su - tomcat -c "rm -rf /tomcat/tomcat14/webapps/hubsoap/*"
  sleep 20
  su - tomcat -c "rmdir /tomcat/tomcat14/webapps/hubsoap/" 
  sleep 10
  echo "Moving new version of hubsoap in place"
  cp -p $i /tomcat/tomcat14/webapps/hubsoap.war
  if [ "$?" != "0" ]; then
    error_exit "Copy Failed.  Aborting!"
  fi
  sleep 10
  echo "Starting Tomcat"
  su - tomcat -c "/tomcat/tomcat14/bin/startup.sh"
  sleep 10
  echo "enabling Worker."
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP14" &> /dev/null
  
  # Starting in deploying package to the fourth Tomcat
echo "Disabling the hubsoap 15 tomcat.  Waiting 180 seconds to stop."
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN15" &> /dev/null
  sleep 180
  echo "hubsoap 3 Tomcat is UP.  Stopping Tomcat."
  su - tomcat -c "/tomcat/tomcat15/bin/shutdown.sh"
  sleep 10
  echo "Backing up old hubsoap"
  su - tomcat -c "mv /tomcat/tomcat15/webapps/hubsoap.war /tomcat/tomcat15/webapps/hubsoap.old"
  sleep 10
  echo "Removing old version of hubsoap"
  su - tomcat -c "rm -rf /tomcat/tomcat15/webapps/hubsoap/*"
  sleep 20
  su - tomcat -c "rmdir /tomcat/tomcat15/webapps/hubsoap/" 
  sleep 10
  echo "Moving new version of hubsoap in place"
  cp -p $i /tomcat/tomcat15/webapps/hubsoap.war
  if [ "$?" != "0" ]; then
    error_exit "Copy Failed.  Aborting!"
  fi
  sleep 10
  echo "Starting Tomcat"
  su - tomcat -c "/tomcat/tomcat15/bin/startup.sh"
  sleep 10
  echo "enabling Worker."
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP15" &> /dev/null
  
  # Starting in deploying package to the fourth Tomcat
echo "Disabling the hubsoap 16 tomcat.  Waiting 180 seconds to stop."
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN16" &> /dev/null
  sleep 180
  echo "hubsoap 3 Tomcat is UP.  Stopping Tomcat."
  su - tomcat -c "/tomcat/tomcat16/bin/shutdown.sh"
  sleep 10
  echo "Backing up old hubsoap"
  su - tomcat -c "mv /tomcat/tomcat16/webapps/hubsoap.war /tomcat/tomcat16/webapps/hubsoap.old"
  sleep 10
  echo "Removing old version of hubsoap"
  su - tomcat -c "rm -rf /tomcat/tomcat16/webapps/hubsoap/*"
  sleep 20
  su - tomcat -c "rmdir /tomcat/tomcat16/webapps/hubsoap/" 
  sleep 10
  echo "Moving new version of hubsoap in place"
  cp -p $i /tomcat/tomcat16/webapps/hubsoap.war
  if [ "$?" != "0" ]; then
    error_exit "Copy Failed.  Aborting!"
  fi
  sleep 10
  echo "Starting Tomcat"
  su - tomcat -c "/tomcat/tomcat16/bin/startup.sh"
  sleep 10
  echo "enabling Worker."
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP16" &> /dev/null
  
  # Starting in deploying package to the fourth Tomcat
echo "Disabling the hubsoap 17 tomcat.  Waiting 180 seconds to stop."
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN17" &> /dev/null
  sleep 180
  echo "hubsoap 3 Tomcat is UP.  Stopping Tomcat."
  su - tomcat -c "/tomcat/tomcat17/bin/shutdown.sh"
  sleep 10
  echo "Backing up old hubsoap"
  su - tomcat -c "mv /tomcat/tomcat17/webapps/hubsoap.war /tomcat/tomcat17/webapps/hubsoap.old"
  sleep 10
  echo "Removing old version of hubsoap"
  su - tomcat -c "rm -rf /tomcat/tomcat17/webapps/hubsoap/*"
  sleep 20
  su - tomcat -c "rmdir /tomcat/tomcat17/webapps/hubsoap/" 
  sleep 10
  echo "Moving new version of hubsoap in place"
  cp -p $i /tomcat/tomcat17/webapps/hubsoap.war
  if [ "$?" != "0" ]; then
    error_exit "Copy Failed.  Aborting!"
  fi
  sleep 10
  echo "Starting Tomcat"
  su - tomcat -c "/tomcat/tomcat17/bin/startup.sh"
  sleep 10
  echo "enabling Worker."
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP17" &> /dev/null
  
  # Starting in deploying package to the fourth Tomcat
echo "Disabling the hubsoap 18 tomcat.  Waiting 180 seconds to stop."
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN18" &> /dev/null
  sleep 180
  echo "hubsoap 3 Tomcat is UP.  Stopping Tomcat."
  su - tomcat -c "/tomcat/tomcat18/bin/shutdown.sh"
  sleep 10
  echo "Backing up old hubsoap"
  su - tomcat -c "mv /tomcat/tomcat18/webapps/hubsoap.war /tomcat/tomcat18/webapps/hubsoap.old"
  sleep 10
  echo "Removing old version of hubsoap"
  su - tomcat -c "rm -rf /tomcat/tomcat18/webapps/hubsoap/*"
  sleep 20
  su - tomcat -c "rmdir /tomcat/tomcat18/webapps/hubsoap/" 
  sleep 10
  echo "Moving new version of hubsoap in place"
  cp -p $i /tomcat/tomcat18/webapps/hubsoap.war
  if [ "$?" != "0" ]; then
    error_exit "Copy Failed.  Aborting!"
  fi
  sleep 10
  echo "Starting Tomcat"
  su - tomcat -c "/tomcat/tomcat18/bin/startup.sh"
  sleep 10
  echo "enabling Worker."
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP18" &> /dev/null
  
  # Starting in deploying package to the fourth Tomcat
echo "Disabling the hubsoap 19 tomcat.  Waiting 180 seconds to stop."
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN19" &> /dev/null
  sleep 180
  echo "hubsoap 3 Tomcat is UP.  Stopping Tomcat."
  su - tomcat -c "/tomcat/tomcat19/bin/shutdown.sh"
  sleep 10
  echo "Backing up old hubsoap"
  su - tomcat -c "mv /tomcat/tomcat19/webapps/hubsoap.war /tomcat/tomcat19/webapps/hubsoap.old"
  sleep 10
  echo "Removing old version of hubsoap"
  su - tomcat -c "rm -rf /tomcat/tomcat19/webapps/hubsoap/*"
  sleep 20
  su - tomcat -c "rmdir /tomcat/tomcat19/webapps/hubsoap/" 
  sleep 10
  echo "Moving new version of hubsoap in place"
  cp -p $i /tomcat/tomcat19/webapps/hubsoap.war
  if [ "$?" != "0" ]; then
    error_exit "Copy Failed.  Aborting!"
  fi
  sleep 10
  echo "Starting Tomcat"
  su - tomcat -c "/tomcat/tomcat19/bin/startup.sh"
  sleep 10
  echo "enabling Worker."
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP19" &> /dev/null
  

  # Starting in deploying package to the fourth Tomcat
echo "Disabling the hubsoap 20 tomcat.  Waiting 180 seconds to stop."
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN20" &> /dev/null
  sleep 180
  echo "hubsoap 3 Tomcat is UP.  Stopping Tomcat."
  su - tomcat -c "/tomcat/tomcat20/bin/shutdown.sh"
  sleep 10
  echo "Backing up old hubsoap"
  su - tomcat -c "mv /tomcat/tomcat20/webapps/hubsoap.war /tomcat/tomcat20/webapps/hubsoap.old"
  sleep 10
  echo "Removing old version of hubsoap"
  su - tomcat -c "rm -rf /tomcat/tomcat20/webapps/hubsoap/*"
  sleep 20
  su - tomcat -c "rmdir /tomcat/tomcat20/webapps/hubsoap/" 
  sleep 10
  echo "Moving new version of hubsoap in place"
  cp -p $i /tomcat/tomcat20/webapps/hubsoap.war
  if [ "$?" != "0" ]; then
    error_exit "Copy Failed.  Aborting!"
  fi
  sleep 10
  echo "Starting Tomcat"
  su - tomcat -c "/tomcat/tomcat20/bin/startup.sh"
  sleep 10
  echo "enabling Worker."
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP20" &> /dev/null
  





  echo "New hubsoaps deployed."
  echo "Removing deployment file. "
  rm $i 
done
rm -rf "$lockdir"
trap - INT TERM EXIT
else
    echo "Lock Exists: $lockdir owned by $(cat $pidfile)"
fi
  else 
error_exit "File is 0 bytes.  Aborting!"
fi
