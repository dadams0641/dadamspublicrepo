#!/usr/bin/bash
# UAT Lakewood EDM UI TomcatUser deployment script
# Version 1.2.0
# Badly written by Drew. 

# Deploy directory
DEPLOY_DIR=/deployment/hubsoap

# Deployment file
DN_FILE=hubsoap.war

# War file Backup directory
WARBACK=/home/tomcat/warback

# Set Lock files so this can only be run once (I think)
LOCKDIR=/var/tmp/deployhub/
PIDFILE=/var/tmp/deployhub/javacore.pid


# Variables for various things:

# Date variable for the log file
DTE=$(date +%Y%m%d%H%M%S)
# The Log file needed for recording what happens
LOGFILE=/home/ahappli/logs/deploy_edm_"$DTE".log
# Lock Directory & PID file
lockdir=/var/tmp/deployedm/
pidfile=/var/tmp/deployedm/javacore.pid
# Pipefile for logging
PIPEFILE=/var/tmp/deployedm/javacore.pipe
  
# URLS for disabling and enabling the tomcat in the load balancer
URLCATDN1="http://lkwdev1.fhmc.local:8190/jkmanager/?cmd=update&from=list&w=edmbalancer&sw=edmui1&vwa=1"
URLCATDN2="http://lkwdev1.fhmc.local:8190/jkmanager/?cmd=update&from=list&w=edmbalancer&sw=edmui2&vwa=1"
URLCATUP1="http://lkwdev1.fhmc.local:8190/jkmanager/?cmd=update&from=list&w=edmbalancer&sw=edmui1&vwa=0"
URLCATUP2="http://lkwdev1.fhmc.local:8190/jkmanager/?cmd=update&from=list&w=edmbalancer&sw=edmui2&vwa=0"

# Creating directories needed if they are not there. 
# This is the PID directory
if [ -d /var/tmp/deployedm/ ]
then 
    echo "JavaCore exists"
	else 
	mkdir -p 777 /var/tmp/deployedm/ 
	echo "JavaCore created"
fi
# Deployment directory
if [ -d /deployment/edmui/edm/ ]
then 
    echo "Deployment directory exists"
	else 
	mkdir -p 777 /deployment/edmui/edm/ 
	echo "Deployment directory created"
fi
# Back up directory
if [ -d /home/tomcat/warback/ ]
then 
    echo "Warback directory exists"
	else 
	mkdir -p /home/tomcat/warback/ 
	echo "Warback directory created"
fi

# Setup Pipefile
if [ ! -e $PIPEFILE ]; then 
    mkfifo $PIPEFILE
fi
if [ -e $LOGFILE ]; then 
    rm $LOGFILE
fi 

# Start tee writing to a logfile, but pulling its input from our named pipe.
exec 3>&1 4>&2
tee $LOGFILE < $PIPEFILE >&3 &

# capture tee's process ID for the wait command.
TEEPID=$!

# redirect the rest of the stderr and stdout to our named pipe.
exec > $PIPEFILE 2>&1

#Check the exit status
error_exit()
{
        echo "$1" 1>&2
        exit 1
}

# Make sure we can only run this one at a time
if ( mkdir ${lockdir} ) 2> /dev/null; then
        echo $$ > $pidfile
        trap 'rm -rf "$lockdir"; exit $?' INT TERM EXIT

# get the package
print -n "URL of deployment package: ";read docpkg; print ""
cd /deployment/edmui/edm/
su tomcat -c "wget $docpkg -O edm.war"  
if [ -z "$(ls -A /deployment/edmui/edm/)" ]; then
   error_exit "Directory is empty.  Aborting!"
elif  [ -s /deployment/edmui/edm/edm.war ]; then
# Variable for the files. 
deploy_file=$(ls /deployment/edmui/edm/* |tail -1)
             for i in $deploy_file
			 do
  clear

  #Check the exit status
error_exit()
{
        echo "$1" 1>&2
        exit 1
}

# Creating directories needed if they are not there. 
# This is the PID directory
if [ -d $LOCKDIR ]
then 
    echo "JavaCore exists"
	else 
	mkdir -p $LOCKDIR
	echo "JavaCore created"
fi
# Deployment directory
if [ -d $DEPLOY_DIR ]
then 
    echo "Deployment directory exists"
	else 
	mkdir -p $DEPLOY_DIR
	echo "Deployment directory created"
fi
# Back up directory
if [ -d $WARBACK ]
then 
    echo "Warback directory exists"
	else 
	mkdir -p $WARBACK
	echo "Warback directory created"
fi

# Lock file so that only one copy can be run. 
# remove lock file during exit
trap 'rm -f $PIDFILE; exit' INT TERM EXIT
 
if [ -f $PIDFILE ] ; then                      
    # lock is already held
    echo >&2 "lock not acquired, giving up: $PIDFILE"
    exit 1
else                      
    # nobody owns the lock
    echo $$ > "$PIDFILE"         # create the lock file
    
    # ... commands executed under lock / single instance ...
    echo "lock acquired: $PIDFILE"
fi

# Ask the question.  Where are we getting this from?
read -p "URL of deployment package: " docpkg

# get the package
cd $DEPLOY_DIR
su tomcat -c "wget $docpkg -O $DN_FILE"

# Variable for the files. 
DEPLOY_FILE=$(ls $DEPLOY_DIR/* |tail -1)

# Checking to see if we got the file or not.  
if [ -z $DEPLOY_FILE ]; then
   error_exit "Directory is empty.  Aborting!"
elif  [ -s $DEPLOY_FILE ]; then
             for i in $DEPLOY_FILE
             do 
                 clear
  
# Staring in on deploying package to the first Tomcat.    
echo "Disabling the edmui 1 Tomcat.  Waiting 180 seconds to stop."
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN1" &> /dev/null
  sleep 180
  echo "edmui 1 Tomcat is UP.  Stopping Tomcat."
  su - tomcat -c "/tomcat/edmui_uat1/bin/shutdown.sh"
  sleep 10
  echo "Backing up old edmui"
  su - tomcat -c "rm /home/tomcat/warback/edm.old"
  sleep 10
  su - tomcat -c "mv /tomcat/edmui_uat1/webapps/edm.old /home/tomcat/warback/edm.old"
  sleep 10
  su - tomcat -c "mv /tomcat/edmui_uat1/webapps/edm.war /tomcat/edmui_uat1/webapps/edm.old"
  sleep 10
  echo "Removing old version of edmui"
  su - tomcat -c "rm -rf /tomcat/edmui_uat1/webapps/edm/*"
  sleep 20
  su - tomcat -c "rmdir /tomcat/edmui_uat1/webapps/edm/" 
  sleep 10
  echo "Moving new version of edmui in place"
  cp -p $i /tomcat/edmui_uat1/webapps/
  if [ "$?" != "0" ]; then
    error_exit "Copy Failed.  Aborting!"
    fi
  sleep 10
  echo "Starting Tomcat"
  su - tomcat -c "/tomcat/edmui_uat1/bin/startup.sh"
  sleep 10
  echo "enabling Worker."
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP1" &> /dev/null
  
  # Starting in deploying package to the second Tomcat
echo "Disabling the edmui 2 tomcat.  Waiting 180 seconds to stop."
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN2" &> /dev/null
  sleep 180
  echo "edmui 1 Tomcat is UP.  Stopping Tomcat."
  su - tomcat -c "/tomcat/edmui_uat2/bin/shutdown.sh"
  sleep 10
  echo "Backing up old edmui"
  su - tomcat -c "rm /home/tomcat/warback/edm2.old"
  sleep 10
  su - tomcat -c "mv /tomcat/edmui_uat2/webapps/edm.old /home/tomcat/warback/edm2.old"
  sleep 10
  su - tomcat -c "mv /tomcat/edmui_uat2/webapps/edm.war /tomcat/edmui_uat2/webapps/edm.old"
  sleep 10
  echo "Removing old version of edmui"
  su - tomcat -c "rm -rf /tomcat/edmui_uat2/webapps/edm/*"
  sleep 20
  su - tomcat -c "rmdir /tomcat/edmui_uat2/webapps/edm/" 
  sleep 10
  echo "Moving new version of edmui in place"
  cp -p $i /tomcat/edmui_uat2/webapps/
  if [ "$?" != "0" ]; then
    error_exit "Copy Failed.  Aborting!"
  fi
  sleep 10
  echo "Starting Tomcat"
  su - tomcat -c "/tomcat/edmui_uat2/bin/startup.sh"
  sleep 10
  echo "enabling Worker."
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP2" &> /dev/null
  echo "New edmuis deployed."
  echo "Removing deployment file. "
  rm $i 
  # close the stderr and stdout file descriptors.
  exec 1>&3 3>&- 2>&4 4>&-
  # Wait for tee to finish since now that other end of the pipe has closed.
  wait $TEEPID
  done
  rm -rf "$lockdir"
  trap - INT TERM EXIT
  else
    echo "Lock Exists: $lockdir owned by $(cat $pidfile)"
  fi
  else 
error_exit "File is 0 bytes.  Aborting!"
fi
