#!/usr/bin/bash
# context.xml deployment script
# Version 2.0.1
# 1.0.0 Initial script. 
# 2.0.0 Complete Rewrite
# 2.0.1 Now we can pass a commandline option for which restore we want to do.  
# Written badly by Drew.

#################################################################################
#  The variables below can be edited for the server this is supposed to be on.  # 
#################################################################################

# What file are we downloading
# Deployment file
DN_FILE=context

# Variable for the total number of Tomcats Running
TCR=20

# Variable for Tomcats running when shutting down some of them. 
TCD=10

# Instance names
INST1=tomcat01
INST2=tomcat02
INST3=tomcat03
INST4=tomcat04
INST5=tomcat05
INST6=tomcat06
INST7=tomcat07
INST8=tomcat08
INST9=tomcat09
INST10=tomcat10
INST11=tomcat11
INST12=tomcat12
INST13=tomcat13
INST14=tomcat14
INST15=tomcat15
INST16=tomcat16
INST17=tomcat17
INST18=tomcat18
INST19=tomcat19
INST20=tomcat20

# Apache User
HTTPUSER=apacheadmin
HTTPPASS=T0mcat*22

# For the URLs 
BALANCER=hubbalancer
BTCD=tomcat

#####################################################
# The below variables should not NEED to be edited. #
#####################################################



# Tomcat Home Directory - These are the directories where Tomcat resides and is run out of.   The base directory is first, then the individual directories.  
TCHOME=/tomcat/
TCHOME_1=$TCHOME/$INST1
TCHOME_2=$TCHOME/$INST2
TCHOME_3=$TCHOME/$INST3
TCHOME_4=$TCHOME/$INST4
TCHOME_5=$TCHOME/$INST5
TCHOME_6=$TCHOME/$INST6
TCHOME_7=$TCHOME/$INST7
TCHOME_8=$TCHOME/$INST8
TCHOME_9=$TCHOME/$INST9
TCHOME_10=$TCHOME/$INST10
TCHOME_11=$TCHOME/$INST11
TCHOME_12=$TCHOME/$INST12
TCHOME_13=$TCHOME/$INST13
TCHOME_14=$TCHOME/$INST14
TCHOME_15=$TCHOME/$INST15
TCHOME_16=$TCHOME/$INST16
TCHOME_17=$TCHOME/$INST17
TCHOME_18=$TCHOME/$INST18
TCHOME_19=$TCHOME/$INST19
TCHOME_20=$TCHOME/$INST20

# Set Lock files so this can only be run once (I think)
LOCKDIR=/var/tmp/$DN_FILE/
PIDFILE=$LOCKDIR/context.pid

# Variable for the URLS
TCSERVER=$(uname -n)

# What date do we need to restore.   If we do not recieve a date to restore, then we assume it is todays date.  
DDATE="$1"

if [ -z "$DDATE" ]; then
	# Today's date will be used.  
 DDATE=$(date +%m%d%Y)
fi

# Add some color to the messages. 
RED='\033[0;41;30m'
STD='\033[0;0;39m'
GRN='\033[30;48;5;82m'
BLU='\033[0;44;97m'

# War file Backup directory
WARBACK=/home/tomcat/warback/context/$DDATE

# URLS for disabling the tomcat in the Apache load balancer
  URLCATDN1="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w="$BALANCER"&sw="$BTCD"01&vwa=1"
  URLCATDN2="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w="$BALANCER"&sw="$BTCD"02&vwa=1"
  URLCATDN3="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w="$BALANCER"&sw="$BTCD"03&vwa=1"
  URLCATDN4="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w="$BALANCER"&sw="$BTCD"04&vwa=1"
  URLCATDN5="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w="$BALANCER"&sw="$BTCD"05&vwa=1"
  URLCATDN6="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w="$BALANCER"&sw="$BTCD"06&vwa=1"
  URLCATDN7="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w="$BALANCER"&sw="$BTCD"07&vwa=1"
  URLCATDN8="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w="$BALANCER"&sw="$BTCD"08&vwa=1"
  URLCATDN9="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w="$BALANCER"&sw="$BTCD"09&vwa=1"
  URLCATDN10="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w="$BALANCER"&sw="$BTCD"10&vwa=1"
  URLCATDN11="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w="$BALANCER"&sw="$BTCD"11&vwa=1"
  URLCATDN12="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w="$BALANCER"&sw="$BTCD"12&vwa=1"
  URLCATDN13="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w="$BALANCER"&sw="$BTCD"13&vwa=1"
  URLCATDN14="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w="$BALANCER"&sw="$BTCD"14&vwa=1"
  URLCATDN15="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w="$BALANCER"&sw="$BTCD"15&vwa=1"
  URLCATDN16="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w="$BALANCER"&sw="$BTCD"16&vwa=1"
  URLCATDN17="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w="$BALANCER"&sw="$BTCD"17&vwa=1"
  URLCATDN18="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w="$BALANCER"&sw="$BTCD"18&vwa=1"
  URLCATDN19="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w="$BALANCER"&sw="$BTCD"19&vwa=1"  
  URLCATDN20="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w="$BALANCER"&sw="$BTCD"20&vwa=1"  

# URLS for enabling the tomcat in the Apache load balancer.    
  URLCATUP1="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w="$BALANCER"&sw="$BTCD"01&vwa=0"
  URLCATUP2="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w="$BALANCER"&sw="$BTCD"02&vwa=0"
  URLCATUP3="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w="$BALANCER"&sw="$BTCD"03&vwa=0"
  URLCATUP4="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w="$BALANCER"&sw="$BTCD"04&vwa=0"
  URLCATUP5="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w="$BALANCER"&sw="$BTCD"05&vwa=0"
  URLCATUP6="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w="$BALANCER"&sw="$BTCD"06&vwa=0"
  URLCATUP7="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w="$BALANCER"&sw="$BTCD"07&vwa=0"
  URLCATUP8="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w="$BALANCER"&sw="$BTCD"08&vwa=0"
  URLCATUP9="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w="$BALANCER"&sw="$BTCD"09&vwa=0"
  URLCATUP10="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w="$BALANCER"&sw="$BTCD"10&vwa=0"
  URLCATUP11="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w="$BALANCER"&sw="$BTCD"11&vwa=0"
  URLCATUP12="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w="$BALANCER"&sw="$BTCD"12&vwa=0"
  URLCATUP13="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w="$BALANCER"&sw="$BTCD"13&vwa=0"
  URLCATUP14="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w="$BALANCER"&sw="$BTCD"14&vwa=0"
  URLCATUP15="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w="$BALANCER"&sw="$BTCD"15&vwa=0"
  URLCATUP16="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w="$BALANCER"&sw="$BTCD"16&vwa=0"
  URLCATUP17="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w="$BALANCER"&sw="$BTCD"17&vwa=0"
  URLCATUP18="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w="$BALANCER"&sw="$BTCD"18&vwa=0"
  URLCATUP19="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w="$BALANCER"&sw="$BTCD"19&vwa=0"
  URLCATUP20="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w="$BALANCER"&sw="$BTCD"20&vwa=0"
  
  
#Check the exit status - This allows us to print custom error messages when something goes wrong.  
error_exit()
{
        echo -e "$1" 1>&2
        exit 1
}

TCRUN()
{
		ps -ef |grep tomcat |grep -v grep |grep t7est |wc -l
}

# Checking to make sure we are running this as Root.  
if [ $(id -u) != "0" ]; then
    echo "You must be the superuser to run this script" >&2
    error_exit "You are not Root.  Please run this script with sudo" 1
fi

# Creating directories needed if they are not there. 
# This is the PID directory. So that we only run the script once. 
if [ -d $LOCKDIR ]
then 
    echo -e "${BLU} Java Deployment PID Directory exists ${STD}"
	else 
	mkdir -p -m 777 $LOCKDIR
	chown tomcat:tomcat $LOCKDIR
	echo -e "${GRN} Java Deployment PID Directory created ${STD}"
fi

# Lock file so that only one copy can be run. 
# remove lock file during exit
trap 'rm -f $PIDFILE; exit' INT TERM EXIT
 
if [ -f $PIDFILE ] ; then                      
    # lock is already held
    echo >&2 -e "${RED} lock not acquired, Is the script already running?  Giving up: $PIDFILE ${STD}"
    exit 1
else                      
    # nobody owns the lock
    echo $$ > "$PIDFILE"         # create the lock file
    
    # ... commands executed under lock / single instance ...
    echo -e "${BLU} lock acquired: $PIDFILE ${STD}"
fi

# Disabling Tomcats in the Apache Load Balancer
echo -e "${GRN} Disabling the Odd Tomcats.  Waiting 180 seconds to stop. ${STD}"
wget -qO- --http-user=$HTTPUSER --http-passwd=$HTTPPASS "$URLCATDN1" &> /dev/null
wget -qO- --http-user=$HTTPUSER --http-passwd=$HTTPPASS "$URLCATDN3" &> /dev/null
wget -qO- --http-user=$HTTPUSER --http-passwd=$HTTPPASS "$URLCATDN5" &> /dev/null
wget -qO- --http-user=$HTTPUSER --http-passwd=$HTTPPASS "$URLCATDN7" &> /dev/null
wget -qO- --http-user=$HTTPUSER --http-passwd=$HTTPPASS "$URLCATDN9" &> /dev/null
wget -qO- --http-user=$HTTPUSER --http-passwd=$HTTPPASS "$URLCATDN11" &> /dev/null
wget -qO- --http-user=$HTTPUSER --http-passwd=$HTTPPASS "$URLCATDN13" &> /dev/null
wget -qO- --http-user=$HTTPUSER --http-passwd=$HTTPPASS "$URLCATDN15" &> /dev/null
wget -qO- --http-user=$HTTPUSER --http-passwd=$HTTPPASS "$URLCATDN17" &> /dev/null
wget -qO- --http-user=$HTTPUSER --http-passwd=$HTTPPASS "$URLCATDN19" &> /dev/null
sleep 180

# Shutting down the Tomcats
echo -e "${GRN} Stopping Odd Tomcats. ${STD}"
  su - tomcat -c "$TCHOME_1/bin/shutdown.sh"
  su - tomcat -c "$TCHOME_3/bin/shutdown.sh"
  su - tomcat -c "$TCHOME_5/bin/shutdown.sh"
  su - tomcat -c "$TCHOME_7/bin/shutdown.sh"
  su - tomcat -c "$TCHOME_9/bin/shutdown.sh"
  su - tomcat -c "$TCHOME_11/bin/shutdown.sh"
  su - tomcat -c "$TCHOME_13/bin/shutdown.sh"
  su - tomcat -c "$TCHOME_15/bin/shutdown.sh"
  su - tomcat -c "$TCHOME_17/bin/shutdown.sh"
  su - tomcat -c "$TCHOME_19/bin/shutdown.sh"
sleep 30

# Checks to make sure we have the right number of tomcats running. 
TC_DP=$( TCRUN )
if (($TC_DP != $TCD)); then 
	echo -e "Expected $TCD Tocmats, ${RED}found $TC_DP Something went wrong! ${STD}Please check the screen output!"
    error_exit "Mismatch number of Tomcats!  Check Screen output."	
	else
	echo -e "${GRN} Checking Tomcats, looking for $TCD found $TC_DP.  Shutdown sucessful ${STD}" 
fi

# remove the bad context.xml
su - tomcat -c "rm $TCHOME_1/conf/$DN_FILE.xml"
su - tomcat -c "rm $TCHOME_3/conf/$DN_FILE.xml"
su - tomcat -c "rm $TCHOME_5/conf/$DN_FILE.xml"
su - tomcat -c "rm $TCHOME_7/conf/$DN_FILE.xml"
su - tomcat -c "rm $TCHOME_9/conf/$DN_FILE.xml"
su - tomcat -c "rm $TCHOME_11/conf/$DN_FILE.xml"
su - tomcat -c "rm $TCHOME_13/conf/$DN_FILE.xml"
su - tomcat -c "rm $TCHOME_15/conf/$DN_FILE.xml"
su - tomcat -c "rm $TCHOME_17/conf/$DN_FILE.xml"
su - tomcat -c "rm $TCHOME_19/conf/$DN_FILE.xml"

# Replace the $DN_FILE with the original file
su - tomcat -c "cp $WARBACK/$INST1/context.xml.$DDATE /$TCHOME_1/conf/"
su - tomcat -c "cp $WARBACK/$INST3/context.xml.$DDATE /$TCHOME_3/conf/"
su - tomcat -c "cp $WARBACK/$INST5/context.xml.$DDATE /$TCHOME_5/conf/"
su - tomcat -c "cp $WARBACK/$INST7/context.xml.$DDATE /$TCHOME_7/conf/"
su - tomcat -c "cp $WARBACK/$INST9/context.xml.$DDATE /$TCHOME_9/conf/"
su - tomcat -c "cp $WARBACK/$INST11/context.xml.$DDATE /$TCHOME_11/conf/"
su - tomcat -c "cp $WARBACK/$INST13/context.xml.$DDATE /$TCHOME_13/conf/"
su - tomcat -c "cp $WARBACK/$INST15/context.xml.$DDATE /$TCHOME_15/conf/"
su - tomcat -c "cp $WARBACK/$INST17/context.xml.$DDATE /$TCHOME_17/conf/"
su - tomcat -c "cp $WARBACK/$INST19/context.xml.$DDATE /$TCHOME_19/conf/"

# Starting up the Tomcats
echo -e "${GRN} Starting the Odd Tomcats. ${STD}"
  su - tomcat -c "$TCHOME_1/bin/startup.sh"
  su - tomcat -c "$TCHOME_3/bin/startup.sh"
  su - tomcat -c "$TCHOME_5/bin/startup.sh"
  su - tomcat -c "$TCHOME_7/bin/startup.sh"
  su - tomcat -c "$TCHOME_9/bin/startup.sh"
  su - tomcat -c "$TCHOME_11/bin/startup.sh"
  su - tomcat -c "$TCHOME_13/bin/startup.sh"
  su - tomcat -c "$TCHOME_15/bin/startup.sh"
  su - tomcat -c "$TCHOME_17/bin/startup.sh"
  su - tomcat -c "$TCHOME_19/bin/startup.sh"
sleep 30

# Enabling Tomcats in the Apache Load Balancer
echo -e "${GRN} Enabling the Odd Tomcats.  Waiting 180 seconds to stop. ${STD}"
wget -qO- --http-user=$HTTPUSER --http-passwd=$HTTPPASS "$URLCATUP1" &> /dev/null
wget -qO- --http-user=$HTTPUSER --http-passwd=$HTTPPASS "$URLCATUP3" &> /dev/null
wget -qO- --http-user=$HTTPUSER --http-passwd=$HTTPPASS "$URLCATUP5" &> /dev/null
wget -qO- --http-user=$HTTPUSER --http-passwd=$HTTPPASS "$URLCATUP7" &> /dev/null
wget -qO- --http-user=$HTTPUSER --http-passwd=$HTTPPASS "$URLCATUP9" &> /dev/null
wget -qO- --http-user=$HTTPUSER --http-passwd=$HTTPPASS "$URLCATUP11" &> /dev/null
wget -qO- --http-user=$HTTPUSER --http-passwd=$HTTPPASS "$URLCATUP13" &> /dev/null
wget -qO- --http-user=$HTTPUSER --http-passwd=$HTTPPASS "$URLCATUP15" &> /dev/null
wget -qO- --http-user=$HTTPUSER --http-passwd=$HTTPPASS "$URLCATUP17" &> /dev/null
wget -qO- --http-user=$HTTPUSER --http-passwd=$HTTPPASS "$URLCATUP19" &> /dev/null
sleep 30

# Checks to make sure we have the right number of tomcats running. 
TC_DP=$( TCRUN )
if (($TC_DP != $TCR)); then 
	echo -e "Expected $TCR Tocmats, ${RED}found $TC_DP Something went wrong! ${STD}Please check the screen output!"
    error_exit "Mismatch number of Tomcats!  Check Screen output."	
	else
	echo -e "${GRN} Checking Tomcats, looking for $TCR found $TC_DP.  Startup sucessful ${STD}" 
fi

# Disabling Tomcats in the Apache Load Balancer
echo -e "${GRN} Disabling the Even Tomcats.  Waiting 180 seconds to stop. ${STD}"
wget -qO- --http-user=$HTTPUSER --http-passwd=$HTTPPASS "$URLCATDN2" &> /dev/null
wget -qO- --http-user=$HTTPUSER --http-passwd=$HTTPPASS "$URLCATDN4" &> /dev/null
wget -qO- --http-user=$HTTPUSER --http-passwd=$HTTPPASS "$URLCATDN6" &> /dev/null
wget -qO- --http-user=$HTTPUSER --http-passwd=$HTTPPASS "$URLCATDN8" &> /dev/null
wget -qO- --http-user=$HTTPUSER --http-passwd=$HTTPPASS "$URLCATDN10" &> /dev/null
wget -qO- --http-user=$HTTPUSER --http-passwd=$HTTPPASS "$URLCATDN12" &> /dev/null
wget -qO- --http-user=$HTTPUSER --http-passwd=$HTTPPASS "$URLCATDN14" &> /dev/null
wget -qO- --http-user=$HTTPUSER --http-passwd=$HTTPPASS "$URLCATDN16" &> /dev/null
wget -qO- --http-user=$HTTPUSER --http-passwd=$HTTPPASS "$URLCATDN18" &> /dev/null
wget -qO- --http-user=$HTTPUSER --http-passwd=$HTTPPASS "$URLCATDN20" &> /dev/null
sleep 180

# Shutting down the Tomcats
echo -e "${GRN} Stopping Even Tomcats. ${STD}"
  su - tomcat -c "$TCHOME_2/bin/shutdown.sh"
  su - tomcat -c "$TCHOME_4/bin/shutdown.sh"
  su - tomcat -c "$TCHOME_6/bin/shutdown.sh"
  su - tomcat -c "$TCHOME_8/bin/shutdown.sh"
  su - tomcat -c "$TCHOME_10/bin/shutdown.sh"
  su - tomcat -c "$TCHOME_12/bin/shutdown.sh"
  su - tomcat -c "$TCHOME_14/bin/shutdown.sh"
  su - tomcat -c "$TCHOME_16/bin/shutdown.sh"
  su - tomcat -c "$TCHOME_18/bin/shutdown.sh"
  su - tomcat -c "$TCHOME_20/bin/shutdown.sh"
sleep 30

# Checks to make sure we have the right number of tomcats running. 
TC_DP=$( TCRUN )
if (($TC_DP != $TCD)); then 
	echo -e "Expected $TCD Tocmats, ${RED}found $TC_DP Something went wrong! ${STD}Please check the screen output!"
    error_exit "Mismatch number of Tomcats!  Check Screen output."	
	else
	echo -e "${GRN} Checking Tomcats, looking for $TCD found $TC_DP.  Shutdown sucessful ${STD}" 
fi

# remove the bad context.xml
su - tomcat -c "rm $TCHOME_2/conf/$DN_FILE.xml"
su - tomcat -c "rm $TCHOME_4/conf/$DN_FILE.xml"
su - tomcat -c "rm $TCHOME_6/conf/$DN_FILE.xml"
su - tomcat -c "rm $TCHOME_8/conf/$DN_FILE.xml"
su - tomcat -c "rm $TCHOME_10/conf/$DN_FILE.xml"
su - tomcat -c "rm $TCHOME_12/conf/$DN_FILE.xml"
su - tomcat -c "rm $TCHOME_14/conf/$DN_FILE.xml"
su - tomcat -c "rm $TCHOME_16/conf/$DN_FILE.xml"
su - tomcat -c "rm $TCHOME_18/conf/$DN_FILE.xml"
su - tomcat -c "rm $TCHOME_20/conf/$DN_FILE.xml"

# Replace the $DN_FILE with the original file
su - tomcat -c "cp $WARBACK/$INST2/context.xml.$DDATE /$TCHOME_2/conf/"
su - tomcat -c "cp $WARBACK/$INST4/context.xml.$DDATE /$TCHOME_4/conf/"
su - tomcat -c "cp $WARBACK/$INST6/context.xml.$DDATE /$TCHOME_6/conf/"
su - tomcat -c "cp $WARBACK/$INST8/context.xml.$DDATE /$TCHOME_8/conf/"
su - tomcat -c "cp $WARBACK/$INST10/context.xml.$DDATE /$TCHOME_10/conf/"
su - tomcat -c "cp $WARBACK/$INST12/context.xml.$DDATE /$TCHOME_12/conf/"
su - tomcat -c "cp $WARBACK/$INST14/context.xml.$DDATE /$TCHOME_14/conf/"
su - tomcat -c "cp $WARBACK/$INST16/context.xml.$DDATE /$TCHOME_16/conf/"
su - tomcat -c "cp $WARBACK/$INST18/context.xml.$DDATE /$TCHOME_18/conf/"
su - tomcat -c "cp $WARBACK/$INST19/context.xml.$DDATE /$TCHOME_20/conf/"

# Starting up the Tomcats
echo -e "${GRN} Starting the Even Tomcats. ${STD}"
  su - tomcat -c "$TCHOME_2/bin/startup.sh"
  su - tomcat -c "$TCHOME_4/bin/startup.sh"
  su - tomcat -c "$TCHOME_6/bin/startup.sh"
  su - tomcat -c "$TCHOME_8/bin/startup.sh"
  su - tomcat -c "$TCHOME_10/bin/startup.sh"
  su - tomcat -c "$TCHOME_12/bin/startup.sh"
  su - tomcat -c "$TCHOME_14/bin/startup.sh"
  su - tomcat -c "$TCHOME_16/bin/startup.sh"
  su - tomcat -c "$TCHOME_18/bin/startup.sh"
  su - tomcat -c "$TCHOME_20/bin/startup.sh"
sleep 30

# Enabling Tomcats in the Apache Load Balancer
echo -e "${GRN} Enabling the Even Tomcats.  Waiting 180 seconds to stop. ${STD}"
wget -qO- --http-user=$HTTPUSER --http-passwd=$HTTPPASS "$URLCATUP2" &> /dev/null
wget -qO- --http-user=$HTTPUSER --http-passwd=$HTTPPASS "$URLCATUP4" &> /dev/null
wget -qO- --http-user=$HTTPUSER --http-passwd=$HTTPPASS "$URLCATUP6" &> /dev/null
wget -qO- --http-user=$HTTPUSER --http-passwd=$HTTPPASS "$URLCATUP8" &> /dev/null
wget -qO- --http-user=$HTTPUSER --http-passwd=$HTTPPASS "$URLCATUP10" &> /dev/null
wget -qO- --http-user=$HTTPUSER --http-passwd=$HTTPPASS "$URLCATUP12" &> /dev/null
wget -qO- --http-user=$HTTPUSER --http-passwd=$HTTPPASS "$URLCATUP14" &> /dev/null
wget -qO- --http-user=$HTTPUSER --http-passwd=$HTTPPASS "$URLCATUP16" &> /dev/null
wget -qO- --http-user=$HTTPUSER --http-passwd=$HTTPPASS "$URLCATUP18" &> /dev/null
wget -qO- --http-user=$HTTPUSER --http-passwd=$HTTPPASS "$URLCATUP20" &> /dev/null
sleep 30

# Checks to make sure we have the right number of tomcats running. 
TC_DP=$( TCRUN )
if (($TC_DP != $TCR)); then 
	echo -e "Expected $TCR Tocmats, ${RED}found $TC_DP Something went wrong! ${STD}Please check the screen output!"
    error_exit "Mismatch number of Tomcats!  Check Screen output."	
	else
	echo -e "${GRN} Checking Tomcats, looking for $TCR found $TC_DP.  Startup sucessful ${STD}" 
fi

# Deployment complete, now to start the clean up.    
	echo -e "${GRN} New $DN_FILE deployed. ${STD}"
	rm -rf "$LOCKDIR"
	trap - INT TERM EXIT


