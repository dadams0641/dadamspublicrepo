#!/usr/bin/bash
# EDMS Production Docsoap deployment script
# Version 1.1.3
# Added directory checking to make sure we have our needed directories. Changed lock menthodology, moved variables around to fix errors.  
# Written badly by Drew. 

# Deploy directory
DEPLOY_DIR=/deployment/docsoap/

# Deployment file
DN_FILE=docsoap.war

# Set Lock files so this can only be run once (I think)
LOCKDIR=/var/tmp/deploydoc/
PIDFILE=/var/tmp/deploydoc/javacore.pid

# War file Backup directory
WARBACK=/home/tomcat/warback

# URLS for disabling and enabling the tomcat in the load balancer
  URLCATDN1="http://edmprod.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc1&vwa=1"
  URLCATDN2="http://edmprod.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc2&vwa=1"
  URLCATDN3="http://edmprod.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc3&vwa=1"
  URLCATDN4="http://edmprod.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc4&vwa=1"
  URLCATDN7="http://edmprod.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc7&vwa=1"
  URLCATDN8="http://edmprod.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc8&vwa=1"
  URLCATDN9="http://edmprod.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc9&vwa=1"
  URLCATDN10="http://edmprod.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc10&vwa=1"
  URLCATDN11="http://edmprod.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc11&vwa=1"
  URLCATDN12="http://edmprod.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc12&vwa=1"
  URLCATDN13="http://edmprod.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc13&vwa=1"
  URLCATDN14="http://edmprod.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc14&vwa=1"
  URLCATDN15="http://edmprod.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc15&vwa=1"
  URLCATDN16="http://edmprod.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc16&vwa=1"
  URLCATDN17="http://edmprod.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc17&vwa=1"
  URLCATDN18="http://edmprod.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc18&vwa=1"
  URLCATDN19="http://edmprod.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc19&vwa=1"  
  URLCATDN20="http://edmprod.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc20&vwa=1"  
  
  URLCATUP1="http://edmprod.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc1&vwa=0"
  URLCATUP2="http://edmprod.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc2&vwa=0"
  URLCATUP3="http://edmprod.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc3&vwa=0"
  URLCATUP4="http://edmprod.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc4&vwa=0"
  URLCATUP7="http://edmprod.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc7&vwa=0"
  URLCATUP8="http://edmprod.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc8&vwa=0"
  URLCATUP9="http://edmprod.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc9&vwa=0"
  URLCATUP10="http://edmprod.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc10&vwa=0"
  URLCATUP11="http://edmprod.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc11&vwa=0"
  URLCATUP12="http://edmprod.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc12&vwa=0"
  URLCATUP13="http://edmprod.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc13&vwa=0"
  URLCATUP14="http://edmprod.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc14&vwa=0"
  URLCATUP15="http://edmprod.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc15&vwa=0"
  URLCATUP16="http://edmprod.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc16&vwa=0"
  URLCATUP17="http://edmprod.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc17&vwa=0"
  URLCATUP18="http://edmprod.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc18&vwa=0"
  URLCATUP19="http://edmprod.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc19&vwa=0"
  URLCATUP20="http://edmprod.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc20&vwa=0"
  
#Check the exit status
error_exit()
{
        echo "$1" 1>&2
        exit 1
}

# Creating directories needed if they are not there. 
# This is the PID directory
if [ -d $LOCKDIR ]
then 
    echo "JavaCore exists"
	else 
	mkdir -p -m 777 $LOCKDIR
	chown tomcat:tomcat $LOCKDIR
	echo "JavaCore created"
fi
# Deployment directory
if [ -d $DEPLOY_DIR ]
then 
    echo "Deployment directory exists"
	else 
	mkdir -p -m 777 $DEPLOY_DIR
	echo "Deployment directory created"
fi
# Back up directory
if [ -d $WARBACK ]
then 
    echo "Warback directory exists"
	else 
	mkdir -p -m 775 $WARBACK
	chown tomcat:tomcat $WARBACK
	echo "Warback directory created"
fi

# Lock file so that only one copy can be run. 
# remove lock file during exit
trap 'rm -f $PIDFILE; exit' INT TERM EXIT
 
if [ -f $PIDFILE ] ; then                      
    # lock is already held
    echo >&2 "lock not acquired, giving up: $PIDFILE"
    exit 1
else                      
    # nobody owns the lock
    echo $$ > "$PIDFILE"         # create the lock file
    
    # ... commands executed under lock / single instance ...
    echo "lock acquired: $PIDFILE"
fi

# Ask the question.  Where are we getting this from?
read -p "URL of deployment package: " docpkg

# get the package
cd $DEPLOY_DIR
su tomcat -c "wget $docpkg -O $DN_FILE"

# Variable for the files. 
DEPLOY_FILE=$(ls $DEPLOY_DIR/* |tail -1)

# Checking to see if we got the file or not.  
if [ -z $DEPLOY_FILE ]; then
   error_exit "Directory is empty.  Aborting!"
elif  [ -s $DEPLOY_FILE ]; then
             for i in $DEPLOY_FILE
             do 
                 clear
   
  # Starting in deploying package to the first Tomcat
  echo "Disabling the DocSoap 1 Tomcat.  Waiting 180 seconds to stop."
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN1" &> /dev/null
  sleep 180
  echo "Docsoap 1 Tomcat is UP.  Stopping Tomcat."
  su - tomcat -c "/tomcat/lkw_doc1/bin/shutdown.sh"
  sleep 10
  echo "backing up deployment Docsoap"
  su - tomcat -c "cp $deploy_file /tomcat/deployed/docsoap/docsoap.war.$(date +%m-%d-%Y)"
  echo "Backing up old DocSoap"
  su - tomcat -c "rm /home/tomcat/warback/docsoap.old"
  sleep 10
  su - tomcat -c "mv /tomcat/lkw_doc1/webapps/docsoap.old /home/tomcat/warback/docsoap.old"
  sleep 10
  su - tomcat -c "mv /tomcat/lkw_doc1/webapps/docsoap.war /tomcat/lkw_doc1//webapps/docsoap.old"
  sleep 10
  echo "Removing old version of DocSoap"
  su - tomcat -c "rm -rf /tomcat/lkw_doc1/webapps/docsoap/*"
  sleep 20
  su - tomcat -c "rmdir /tomcat/lkw_doc1/webapps/docsoap/" 
  sleep 10
  echo "Moving new version of Docsoap in place"
  cp -p $i /tomcat/lkw_doc1/webapps/
  if [ "$?" != "0" ]; then
    error_exit "Copy Failed.  Aborting!"
  fi
  sleep 10
  echo "Starting Tomcat"
  su - tomcat -c "/tomcat/lkw_doc1/bin/startup.sh"
  sleep 10
  echo "enabling Worker."
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP1" &> /dev/null
  
  # Starting in deploying package to the second Tomcat
echo "Disabling the DocSoap 2 tomcat.  Waiting 180 seconds to stop."
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN2" &> /dev/null
  sleep 180
  echo "Docsoap 1 Tomcat is UP.  Stopping Tomcat."
  su - tomcat -c "/tomcat/lkw_doc2/bin/shutdown.sh"
  sleep 10
  echo "Backing up old DocSoap"
  su - tomcat -c "mv /tomcat/lkw_doc2/webapps/docsoap.war /tomcat/lkw_doc2/webapps/docsoap.old"
  sleep 10
  echo "Removing old version of DocSoap"
  su - tomcat -c "rm -rf /tomcat/lkw_doc2/webapps/docsoap/*"
  sleep 20
  su - tomcat -c "rmdir /tomcat/lkw_doc2/webapps/docsoap/" 
  sleep 10
  echo "Moving new version of Docsoap in place"
  cp -p $i /tomcat/lkw_doc2/webapps/
  if [ "$?" != "0" ]; then
    error_exit "Copy Failed.  Aborting!"
  fi
  sleep 10
  echo "Starting Tomcat"
  su - tomcat -c "/tomcat/lkw_doc2/bin/startup.sh"
  sleep 10
  echo "enabling Worker."
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP2" &> /dev/null
  
  # Starting in deploying package to the second Tomcat
echo "Disabling the DocSoap 3 tomcat.  Waiting 180 seconds to stop."
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN3" &> /dev/null
  sleep 180
  echo "Docsoap 2 Tomcat is UP.  Stopping Tomcat."
  su - tomcat -c "/tomcat/lkw_doc3/bin/shutdown.sh"
  sleep 10
  echo "Backing up old DocSoap"
  su - tomcat -c "mv /tomcat/lkw_doc3/webapps/docsoap.war /tomcat/lkw_doc3/webapps/docsoap.old"
  sleep 10
  echo "Removing old version of DocSoap"
  su - tomcat -c "rm -rf /tomcat/lkw_doc3/webapps/docsoap/*"
  sleep 20
  su - tomcat -c "rmdir /tomcat/lkw_doc3/webapps/docsoap/" 
  sleep 10
  echo "Moving new version of Docsoap in place"
  cp -p $i /tomcat/lkw_doc3/webapps/
  if [ "$?" != "0" ]; then
    error_exit "Copy Failed.  Aborting!"
  fi
  sleep 10
  echo "Starting Tomcat"
  su - tomcat -c "/tomcat/lkw_doc3/bin/startup.sh"
  sleep 10
  echo "enabling Worker."
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP3" &> /dev/null

  # Starting in deploying package to the second Tomcat
echo "Disabling the DocSoap 4 tomcat.  Waiting 180 seconds to stop."
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN4" &> /dev/null
  sleep 180
  echo "Docsoap 3 Tomcat is UP.  Stopping Tomcat."
  su - tomcat -c "/tomcat/lkw_doc4/bin/shutdown.sh"
  sleep 10
  echo "Backing up old DocSoap"
  su - tomcat -c "mv /tomcat/lkw_doc4/webapps/docsoap.war /tomcat/lkw_doc4/webapps/docsoap.old"
  sleep 10
  echo "Removing old version of DocSoap"
  su - tomcat -c "rm -rf /tomcat/lkw_doc4/webapps/docsoap/*"
  sleep 20
  su - tomcat -c "rmdir /tomcat/lkw_doc4/webapps/docsoap/" 
  sleep 10
  echo "Moving new version of Docsoap in place"
  cp -p $i /tomcat/lkw_doc4/webapps/
  if [ "$?" != "0" ]; then
    error_exit "Copy Failed.  Aborting!"
  fi
  sleep 10
  echo "Starting Tomcat"
  su - tomcat -c "/tomcat/lkw_doc4/bin/startup.sh"
  sleep 10
  echo "enabling Worker."
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP4" &> /dev/null

  # Starting in deploying package to the second Tomcat
echo "Disabling the DocSoap 7 tomcat.  Waiting 180 seconds to stop."
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN7" &> /dev/null
  sleep 180
  echo "Docsoap 4 Tomcat is UP.  Stopping Tomcat."
  su - tomcat -c "/tomcat/lkw_doc7/bin/shutdown.sh"
  sleep 10
  echo "Backing up old DocSoap"
  su - tomcat -c "mv /tomcat/lkw_doc7/webapps/docsoap.war /tomcat/lkw_doc7/webapps/docsoap.old"
  sleep 10
  echo "Removing old version of DocSoap"
  su - tomcat -c "rm -rf /tomcat/lkw_doc7/webapps/docsoap/*"
  sleep 20
  su - tomcat -c "rmdir /tomcat/lkw_doc7/webapps/docsoap/" 
  sleep 10
  echo "Moving new version of Docsoap in place"
  cp -p $i /tomcat/lkw_doc7/webapps/
  if [ "$?" != "0" ]; then
    error_exit "Copy Failed.  Aborting!"
  fi
  sleep 10
  echo "Starting Tomcat"
  su - tomcat -c "/tomcat/lkw_doc7/bin/startup.sh"
  sleep 10
  echo "enabling Worker."
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP7" &> /dev/null

  # Starting in deploying package to the second Tomcat
echo "Disabling the DocSoap 8 tomcat.  Waiting 180 seconds to stop."
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN8" &> /dev/null
  sleep 180
  echo "Docsoap 7 Tomcat is UP.  Stopping Tomcat."
  su - tomcat -c "/tomcat/lkw_doc8/bin/shutdown.sh"
  sleep 10
  echo "Backing up old DocSoap"
  su - tomcat -c "mv /tomcat/lkw_doc8/webapps/docsoap.war /tomcat/lkw_doc8/webapps/docsoap.old"
  sleep 10
  echo "Removing old version of DocSoap"
  su - tomcat -c "rm -rf /tomcat/lkw_doc8/webapps/docsoap/*"
  sleep 20
  su - tomcat -c "rmdir /tomcat/lkw_doc8/webapps/docsoap/" 
  sleep 10
  echo "Moving new version of Docsoap in place"
  cp -p $i /tomcat/lkw_doc8/webapps/
  if [ "$?" != "0" ]; then
    error_exit "Copy Failed.  Aborting!"
  fi
  sleep 10
  echo "Starting Tomcat"
  su - tomcat -c "/tomcat/lkw_doc8/bin/startup.sh"
  sleep 10
  echo "enabling Worker."
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP8" &> /dev/null

  # Starting in deploying package to the second Tomcat
echo "Disabling the DocSoap 9 tomcat.  Waiting 180 seconds to stop."
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN9" &> /dev/null
  sleep 180
  echo "Docsoap 8 Tomcat is UP.  Stopping Tomcat."
  su - tomcat -c "/tomcat/lkw_doc9/bin/shutdown.sh"
  sleep 10
  echo "Backing up old DocSoap"
  su - tomcat -c "mv /tomcat/lkw_doc9/webapps/docsoap.war /tomcat/lkw_doc9/webapps/docsoap.old"
  sleep 10
  echo "Removing old version of DocSoap"
  su - tomcat -c "rm -rf /tomcat/lkw_doc9/webapps/docsoap/*"
  sleep 20
  su - tomcat -c "rmdir /tomcat/lkw_doc9/webapps/docsoap/" 
  sleep 10
  echo "Moving new version of Docsoap in place"
  cp -p $i /tomcat/lkw_doc9/webapps/
  if [ "$?" != "0" ]; then
    error_exit "Copy Failed.  Aborting!"
  fi
  sleep 10
  echo "Starting Tomcat"
  su - tomcat -c "/tomcat/lkw_doc9/bin/startup.sh"
  sleep 10
  echo "enabling Worker."
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP9" &> /dev/null

  # Starting in deploying package to the second Tomcat
echo "Disabling the DocSoap 10 tomcat.  Waiting 180 seconds to stop."
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN10" &> /dev/null
  sleep 180
  echo "Docsoap 9 Tomcat is UP.  Stopping Tomcat."
  su - tomcat -c "/tomcat/lkw_doc10/bin/shutdown.sh"
  sleep 10
  echo "Backing up old DocSoap"
  su - tomcat -c "mv /tomcat/lkw_doc10/webapps/docsoap.war /tomcat/lkw_doc10/webapps/docsoap.old"
  sleep 10
  echo "Removing old version of DocSoap"
  su - tomcat -c "rm -rf /tomcat/lkw_doc10/webapps/docsoap/*"
  sleep 20
  su - tomcat -c "rmdir /tomcat/lkw_doc10/webapps/docsoap/" 
  sleep 10
  echo "Moving new version of Docsoap in place"
  cp -p $i /tomcat/lkw_doc10/webapps/
  if [ "$?" != "0" ]; then
    error_exit "Copy Failed.  Aborting!"
  fi
  sleep 10
  echo "Starting Tomcat"
  su - tomcat -c "/tomcat/lkw_doc10/bin/startup.sh"
  sleep 10
  echo "enabling Worker."
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP10" &> /dev/null

  # Starting in deploying package to the second Tomcat
echo "Disabling the DocSoap 11 tomcat.  Waiting 180 seconds to stop."
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN11" &> /dev/null
  sleep 180
  echo "Docsoap 10 Tomcat is UP.  Stopping Tomcat."
  su - tomcat -c "/tomcat/lkw_doc11/bin/shutdown.sh"
  sleep 10
  echo "Backing up old DocSoap"
  su - tomcat -c "mv /tomcat/lkw_doc11/webapps/docsoap.war /tomcat/lkw_doc11/webapps/docsoap.old"
  sleep 10
  echo "Removing old version of DocSoap"
  su - tomcat -c "rm -rf /tomcat/lkw_doc11/webapps/docsoap/*"
  sleep 20
  su - tomcat -c "rmdir /tomcat/lkw_doc11/webapps/docsoap/" 
  sleep 10
  echo "Moving new version of Docsoap in place"
  cp -p $i /tomcat/lkw_doc11/webapps/
  if [ "$?" != "0" ]; then
    error_exit "Copy Failed.  Aborting!"
  fi
  sleep 10
  echo "Starting Tomcat"
  su - tomcat -c "/tomcat/lkw_doc11/bin/startup.sh"
  sleep 10
  echo "enabling Worker."
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP11" &> /dev/null

  # Starting in deploying package to the second Tomcat
echo "Disabling the DocSoap 12 tomcat.  Waiting 180 seconds to stop."
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN12" &> /dev/null
  sleep 180
  echo "Docsoap 11 Tomcat is UP.  Stopping Tomcat."
  su - tomcat -c "/tomcat/lkw_doc12/bin/shutdown.sh"
  sleep 10
  echo "Backing up old DocSoap"
  su - tomcat -c "mv /tomcat/lkw_doc12/webapps/docsoap.war /tomcat/lkw_doc12/webapps/docsoap.old"
  sleep 10
  echo "Removing old version of DocSoap"
  su - tomcat -c "rm -rf /tomcat/lkw_doc12/webapps/docsoap/*"
  sleep 20
  su - tomcat -c "rmdir /tomcat/lkw_doc12/webapps/docsoap/" 
  sleep 10
  echo "Moving new version of Docsoap in place"
  cp -p $i /tomcat/lkw_doc12/webapps/
  if [ "$?" != "0" ]; then
    error_exit "Copy Failed.  Aborting!"
  fi
  sleep 10
  echo "Starting Tomcat"
  su - tomcat -c "/tomcat/lkw_doc12/bin/startup.sh"
  sleep 10
  echo "enabling Worker."
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP12" &> /dev/null

  # Starting in deploying package to the second Tomcat
echo "Disabling the DocSoap 14 tomcat.  Waiting 180 seconds to stop."
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN13" &> /dev/null
  sleep 180
  echo "Docsoap 12 Tomcat is UP.  Stopping Tomcat."
  su - tomcat -c "/tomcat/lkw_doc13/bin/shutdown.sh"
  sleep 10
  echo "Backing up old DocSoap"
  su - tomcat -c "mv /tomcat/lkw_doc13/webapps/docsoap.war /tomcat/lkw_doc13/webapps/docsoap.old"
  sleep 10
  echo "Removing old version of DocSoap"
  su - tomcat -c "rm -rf /tomcat/lkw_doc13/webapps/docsoap/*"
  sleep 20
  su - tomcat -c "rmdir /tomcat/lkw_doc13/webapps/docsoap/" 
  sleep 10
  echo "Moving new version of Docsoap in place"
  cp -p $i /tomcat/lkw_doc13/webapps/
  if [ "$?" != "0" ]; then
    error_exit "Copy Failed.  Aborting!"
  fi
  sleep 10
  echo "Starting Tomcat"
  su - tomcat -c "/tomcat/lkw_doc13/bin/startup.sh"
  sleep 10
  echo "enabling Worker."
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP13" &> /dev/null

  # Starting in deploying package to the second Tomcat
echo "Disabling the DocSoap 14 tomcat.  Waiting 180 seconds to stop."
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN14" &> /dev/null
  sleep 180
  echo "Docsoap 13 Tomcat is UP.  Stopping Tomcat."
  su - tomcat -c "/tomcat/lkw_doc14/bin/shutdown.sh"
  sleep 10
  echo "Backing up old DocSoap"
  su - tomcat -c "mv /tomcat/lkw_doc14/webapps/docsoap.war /tomcat/lkw_doc14/webapps/docsoap.old"
  sleep 10
  echo "Removing old version of DocSoap"
  su - tomcat -c "rm -rf /tomcat/lkw_doc14/webapps/docsoap/*"
  sleep 20
  su - tomcat -c "rmdir /tomcat/lkw_doc14/webapps/docsoap/" 
  sleep 10
  echo "Moving new version of Docsoap in place"
  cp -p $i /tomcat/lkw_doc14/webapps/
  if [ "$?" != "0" ]; then
    error_exit "Copy Failed.  Aborting!"
  fi
  sleep 10
  echo "Starting Tomcat"
  su - tomcat -c "/tomcat/lkw_doc14/bin/startup.sh"
  sleep 10
  echo "enabling Worker."
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP14" &> /dev/null

  # Starting in deploying package to the second Tomcat
echo "Disabling the DocSoap 15 tomcat.  Waiting 180 seconds to stop."
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN15" &> /dev/null
  sleep 180
  echo "Docsoap 14 Tomcat is UP.  Stopping Tomcat."
  su - tomcat -c "/tomcat/lkw_doc15/bin/shutdown.sh"
  sleep 10
  echo "Backing up old DocSoap"
  su - tomcat -c "mv /tomcat/lkw_doc15/webapps/docsoap.war /tomcat/lkw_doc15/webapps/docsoap.old"
  sleep 10
  echo "Removing old version of DocSoap"
  su - tomcat -c "rm -rf /tomcat/lkw_doc15/webapps/docsoap/*"
  sleep 20
  su - tomcat -c "rmdir /tomcat/lkw_doc15/webapps/docsoap/" 
  sleep 10
  echo "Moving new version of Docsoap in place"
  cp -p $i /tomcat/lkw_doc15/webapps/
  if [ "$?" != "0" ]; then
    error_exit "Copy Failed.  Aborting!"
  fi
  sleep 10
  echo "Starting Tomcat"
  su - tomcat -c "/tomcat/lkw_doc15/bin/startup.sh"
  sleep 10
  echo "enabling Worker."
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP15" &> /dev/null

  # Starting in deploying package to the second Tomcat
echo "Disabling the DocSoap 17 tomcat.  Waiting 180 seconds to stop."
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN16" &> /dev/null
  sleep 180
  echo "Docsoap 15 Tomcat is UP.  Stopping Tomcat."
  su - tomcat -c "/tomcat/lkw_doc16/bin/shutdown.sh"
  sleep 10
  echo "Backing up old DocSoap"
  su - tomcat -c "mv /tomcat/lkw_doc16/webapps/docsoap.war /tomcat/lkw_doc16/webapps/docsoap.old"
  sleep 10
  echo "Removing old version of DocSoap"
  su - tomcat -c "rm -rf /tomcat/lkw_doc16/webapps/docsoap/*"
  sleep 20
  su - tomcat -c "rmdir /tomcat/lkw_doc16/webapps/docsoap/" 
  sleep 10
  echo "Moving new version of Docsoap in place"
  cp -p $i /tomcat/lkw_doc16/webapps/
  if [ "$?" != "0" ]; then
    error_exit "Copy Failed.  Aborting!"
  fi
  sleep 10
  echo "Starting Tomcat"
  su - tomcat -c "/tomcat/lkw_doc16/bin/startup.sh"
  sleep 10
  echo "enabling Worker."
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP16" &> /dev/null

  # Starting in deploying package to the second Tomcat
echo "Disabling the DocSoap 18 tomcat.  Waiting 180 seconds to stop."
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN17" &> /dev/null
  sleep 180
  echo "Docsoap 16 Tomcat is UP.  Stopping Tomcat."
  su - tomcat -c "/tomcat/lkw_doc17/bin/shutdown.sh"
  sleep 10
  echo "Backing up old DocSoap"
  su - tomcat -c "mv /tomcat/lkw_doc17/webapps/docsoap.war /tomcat/lkw_doc17/webapps/docsoap.old"
  sleep 10
  echo "Removing old version of DocSoap"
  su - tomcat -c "rm -rf /tomcat/lkw_doc17/webapps/docsoap/*"
  sleep 20
  su - tomcat -c "rmdir /tomcat/lkw_doc17/webapps/docsoap/" 
  sleep 10
  echo "Moving new version of Docsoap in place"
  cp -p $i /tomcat/lkw_doc17/webapps/
  if [ "$?" != "0" ]; then
    error_exit "Copy Failed.  Aborting!"
  fi
  sleep 10
  echo "Starting Tomcat"
  su - tomcat -c "/tomcat/lkw_doc17/bin/startup.sh"
  sleep 10
  echo "enabling Worker."
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP17" &> /dev/null

  # Starting in deploying package to the second Tomcat
echo "Disabling the DocSoap 19 tomcat.  Waiting 180 seconds to stop."
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN18" &> /dev/null
  sleep 180
  echo "Docsoap 17 Tomcat is UP.  Stopping Tomcat."
  su - tomcat -c "/tomcat/lkw_doc18/bin/shutdown.sh"
  sleep 10
  echo "Backing up old DocSoap"
  su - tomcat -c "mv /tomcat/lkw_doc18/webapps/docsoap.war /tomcat/lkw_doc18/webapps/docsoap.old"
  sleep 10
  echo "Removing old version of DocSoap"
  su - tomcat -c "rm -rf /tomcat/lkw_doc18/webapps/docsoap/*"
  sleep 20
  su - tomcat -c "rmdir /tomcat/lkw_doc18/webapps/docsoap/" 
  sleep 10
  echo "Moving new version of Docsoap in place"
  cp -p $i /tomcat/lkw_doc18/webapps/
  if [ "$?" != "0" ]; then
    error_exit "Copy Failed.  Aborting!"
  fi
  sleep 10
  echo "Starting Tomcat"
  su - tomcat -c "/tomcat/lkw_doc18/bin/startup.sh"
  sleep 10
  echo "enabling Worker."
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP18" &> /dev/null

  # Starting in deploying package to the second Tomcat
echo "Disabling the DocSoap 20 tomcat.  Waiting 180 seconds to stop."
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN19" &> /dev/null
  sleep 180
  echo "Docsoap 18 Tomcat is UP.  Stopping Tomcat."
  su - tomcat -c "/tomcat/lkw_doc19/bin/shutdown.sh"
  sleep 10
  echo "Backing up old DocSoap"
  su - tomcat -c "mv /tomcat/lkw_doc19/webapps/docsoap.war /tomcat/lkw_doc19/webapps/docsoap.old"
  sleep 10
  echo "Removing old version of DocSoap"
  su - tomcat -c "rm -rf /tomcat/lkw_doc19/webapps/docsoap/*"
  sleep 20
  su - tomcat -c "rmdir /tomcat/lkw_doc19/webapps/docsoap/" 
  sleep 10
  echo "Moving new version of Docsoap in place"
  cp -p $i /tomcat/lkw_doc19/webapps/
  if [ "$?" != "0" ]; then
    error_exit "Copy Failed.  Aborting!"
  fi
  sleep 10
  echo "Starting Tomcat"
  su - tomcat -c "/tomcat/lkw_doc19/bin/startup.sh"
  sleep 10
  echo "enabling Worker."
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP19" &> /dev/null

  # Starting in deploying package to the second Tomcat
echo "Disabling the DocSoap 20 tomcat.  Waiting 180 seconds to stop."
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN20" &> /dev/null
  sleep 180
  echo "Docsoap 19 Tomcat is UP.  Stopping Tomcat."
  su - tomcat -c "/tomcat/lkw_doc20/bin/shutdown.sh"
  sleep 10
  echo "Backing up old DocSoap"
  su - tomcat -c "mv /tomcat/lkw_doc20/webapps/docsoap.war /tomcat/lkw_doc20/webapps/docsoap.old"
  sleep 10
  echo "Removing old version of DocSoap"
  su - tomcat -c "rm -rf /tomcat/lkw_doc20/webapps/docsoap/*"
  sleep 20
  su - tomcat -c "rmdir /tomcat/lkw_doc20/webapps/docsoap/" 
  sleep 10
  echo "Moving new version of Docsoap in place"
  cp -p $i /tomcat/lkw_doc20/webapps/
  if [ "$?" != "0" ]; then
    error_exit "Copy Failed.  Aborting!"
  fi
  sleep 10
  echo "Starting Tomcat"
  su - tomcat -c "/tomcat/lkw_doc20/bin/startup.sh"
  sleep 10
  echo "enabling Worker."
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP20" &> /dev/null

echo "New Docsoaps deployed."
echo "Removing deployment file. "
	rm $i 
done
	rm -rf "$LOCKDIR"
trap - INT TERM EXIT
fi
read -p "Press any key to continue... " -n1 -s
