#!/usr/bin/bash
# UAT Lakewood EDM UI Tomcat User deployment script
# Version 1.1.3
# Added directory checking to make sure we have our needed directories. Changed lock menthodology, moved variables around to fix errors.  
# Written badly by Drew. 

# Deploy directory
DEPLOY_DIR=/deployment/hubsoap

# Deployment file
DN_FILE=tomcatUserSoap.war

# War file Backup directory
WARBACK=/home/tomcat/warback

# Set Lock files so this can only be run once (I think)
LOCKDIR=/var/tmp/deploytcuser/
PIDFILE=/var/tmp/deploytcuser/javacore.pid

# URLS for disabling and enabling the tomcat in the load balancer
URLCATDN1="http://edmtomcat1.fhmc.local/jkmanager/?cmd=update&from=list&w=edmx-balancer&sw=edm18&vwa=1"
URLCATDN2="http://edmtomcat1.fhmc.local/jkmanager/?cmd=update&from=list&w=edmx-balancer&sw=edm19&vwa=1"
URLCATUP1="http://edmtomcat1.fhmc.local/jkmanager/?cmd=update&from=list&w=edmx-balancer&sw=edm18&vwa=0"
URLCATUP2="http://edmtomcat1.fhmc.local/jkmanager/?cmd=update&from=list&w=edmx-balancer&sw=edm19&vwa=0"

#Check the exit status
error_exit()
{
        echo "$1" 1>&2
        exit 1
}

# Creating directories needed if they are not there. 
# This is the PID directory
if [ -d $LOCKDIR ]
then 
    echo "JavaCore exists"
	else 
	mkdir -p -m 777 $LOCKDIR
	chown tomcat:tomcat $LOCKDIR
	echo "JavaCore created"
fi
# Deployment directory
if [ -d $DEPLOY_DIR ]
then 
    echo "Deployment directory exists"
	else 
	mkdir -p -m 777 $DEPLOY_DIR
	echo "Deployment directory created"
fi
# Back up directory
if [ -d $WARBACK ]
then 
    echo "Warback directory exists"
	else 
	mkdir -p -m 775 $WARBACK
	chown tomcat:tomcat $WARBACK
	echo "Warback directory created"
fi

# Lock file so that only one copy can be run. 
# remove lock file during exit
trap 'rm -f $PIDFILE; exit' INT TERM EXIT
 
if [ -f $PIDFILE ] ; then                      
    # lock is already held
    echo >&2 "lock not acquired, giving up: $PIDFILE"
    exit 1
else                      
    # nobody owns the lock
    echo $$ > "$PIDFILE"         # create the lock file
    
    # ... commands executed under lock / single instance ...
    echo "lock acquired: $PIDFILE"
fi

# Ask the question.  Where are we getting this from?
read -p "URL of deployment package: " docpkg

# get the package
cd $DEPLOY_DIR
su tomcat -c "wget $docpkg -O $DN_FILE"

# Variable for the files. 
DEPLOY_FILE=$(ls $DEPLOY_DIR/* |tail -1)

# Checking to see if we got the file or not.  
if [ -z $DEPLOY_FILE ]; then
   error_exit "Directory is empty.  Aborting!"
elif  [ -s $DEPLOY_FILE ]; then
             for i in $DEPLOY_FILE
             do 
                 clear
    
# Staring in on deploying package to the first Tomcat.    
echo "Disabling the edmui 8 Tomcat.  Waiting 180 seconds to stop."
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN1" &> /dev/null
  sleep 180
  echo "edmui 1 Tomcat is UP.  Stopping Tomcat."
  su - tomcat -c "/tomcat/inst8/bin/shutdown.sh"
  sleep 10
  echo "Backing up old edmui"
  su - tomcat -c "rm /home/tomcat/warback/tomcatUserSoap.old"
  sleep 10
  su - tomcat -c "mv /tomcat/inst8/webapps/tomcatUserSoap.old /home/tomcat/warback/tomcatUserSoap.old"
  sleep 10
  su - tomcat -c "mv /tomcat/inst8/webapps/tomcatUserSoap.war /tomcat/inst8/webapps/tomcatUserSoap.old"
  sleep 10
  echo "Removing old version of edmui"
  su - tomcat -c "rm -rf /tomcat/inst8/webapps/tomcatUserSoap/*"
  sleep 20
  su - tomcat -c "rmdir /tomcat/inst8/webapps/tomcatUserSoap/" 
  sleep 10
  echo "Moving new version of edmui in place"
  cp -p $i /tomcat/inst8/webapps/
  if [ "$?" != "0" ]; then
    error_exit "Copy Failed.  Aborting!"
    fi
  sleep 10
  echo "Starting Tomcat"
  su - tomcat -c "/tomcat/inst8/bin/startup.sh"
  sleep 10
  echo "enabling Worker."
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP1" &> /dev/null
  
  # Starting in deploying package to the second Tomcat
echo "Disabling the edmui 9 tomcat.  Waiting 180 seconds to stop."
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN2" &> /dev/null
  sleep 180
  echo "edmui 1 Tomcat is UP.  Stopping Tomcat."
  su - tomcat -c "/tomcat/inst9/bin/shutdown.sh"
  sleep 10
  echo "Backing up old edmui"
  su - tomcat -c "rm /home/tomcat/warback/tomcatUserSoap2.old"
  sleep 10
  su - tomcat -c "mv /tomcat/inst9/webapps/tomcatUserSoap.old /home/tomcat/warback/tomcatUserSoap2.old"
  sleep 10
  su - tomcat -c "mv /tomcat/inst9/webapps/tomcatUserSoap.war /tomcat/inst9/webapps/tomcatUserSoap.old"
  sleep 10
  echo "Removing old version of edmui"
  su - tomcat -c "rm -rf /tomcat/inst9/webapps/tomcatUserSoap/*"
  sleep 20
  su - tomcat -c "rmdir /tomcat/inst9/webapps/tomcatUserSoap/" 
  sleep 10
  echo "Moving new version of edmui in place"
  cp -p $i /tomcat/inst9/webapps/
  if [ "$?" != "0" ]; then
    error_exit "Copy Failed.  Aborting!"
  fi
  sleep 10
  echo "Starting Tomcat"
  su - tomcat -c "/tomcat/inst9/bin/startup.sh"
  sleep 10
  echo "enabling Worker."
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP2" &> /dev/null
  
echo "New edmuis deployed."
echo "Removing deployment file. "
	# Remove the downloaded file and exit. 
	rm $i 
done
	rm -rf "$LOCKDIR"
trap - INT TERM EXIT
fi
read -p "Press any key to continue... " -n1 -s
