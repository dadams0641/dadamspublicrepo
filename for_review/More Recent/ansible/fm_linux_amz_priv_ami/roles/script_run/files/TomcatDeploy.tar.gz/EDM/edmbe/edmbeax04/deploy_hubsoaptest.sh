#!/usr/bin/bash
# UAT Lakewood hubsoap deployment script
# Version 1.2.3
# Added a backup of the downloaded file.  
# Added color coding to messages.  The bottom half of the script is now using variables.  The whole of the script is now using paramiters instead of being hard coded. 
# Added directory checking to make sure we have our needed directories. 
# Written badly by Drew.

# Variable for which deployment war file this script is going to deploy.  Change this with each script. 
# Below are the variables that change with each individual script.   
# Deployment file
DN_FILE=hubsoap

# Set Lock files so this can only be run once (I think)
LOCKDIR=/var/tmp/deployhubsoap/
PIDFILE=/var/tmp/deployhubsoap/javacore.pid

# Tomcat Home Directory
# Tomcat Home Directory
TCHOME=/tomcat/
TCHOME_1=/tomcat/tomcat01
TCHOME_2=/tomcat/tomcat02
TCHOME_3=/tomcat/tomcat03

# URLS for disabling the tomcat in the Apache load balancer
URLCATDN1="http://in-pedmbeax04.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat1&vwa=1"
URLCATDN2="http://in-pedmbeax04.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat2&vwa=1"
URLCATDN3="http://in-pedmbeax04.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat3&vwa=1"

# URLS for enabling the tomcat in the Apache load balancer    
URLCATUP1="http://in-pedmbeax04.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat1&vwa=0" 
URLCATUP2="http://in-pedmbeax04.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat2&vwa=0"
URLCATUP3="http://in-pedmbeax04.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat3&vwa=0"

# Variables that are the same in every script.  
# Deploy directory
DEPLOY_DIR=/deployment/$DN_FILE

# War file Backup directory
WARBACK=/home/tomcat/warback

# Date variable
DDATE=`date +%F.%T`

# Add some color to the messages. 
RED='\033[0;41;30m'
STD='\033[0;0;39m'
GRN='\033[30;48;5;82m'
BLU='\033[0;44;97m'

#Check the exit status
error_exit()
{
        echo -e "$1" 1>&2
        exit 1
}

# Creating directories needed if they are not there. 
# This is the PID directory
if [ -d $LOCKDIR ]
then 
    echo -e "${BLU} Java Deployment PID Directory exists ${STD}"
	else 
	mkdir -p -m 777 $LOCKDIR
	chown tomcat:tomcat $LOCKDIR
	echo -e "${GRN} Java Deployment PID Directory created ${STD}"
fi
# Deployment directory
if [ -d $DEPLOY_DIR ]
then 
    echo -e "${BLU} Deployment directory exists ${STD}"
	else 
	mkdir -p -m 777 $DEPLOY_DIR
	echo -e "${GRN} $DN_FILE Deployment directory created ${STD}"
fi
# Back up directory
if [ -d $WARBACK ]
then 
    echo -e "${BLU} Warback directory exists ${STD}"
	else 
	mkdir -p -m 775 $WARBACK
	chown tomcat:tomcat $WARBACK
	echo -e "${GRN} Warback directory created ${STD}"
fi

# Back up deployment directory
if [ -d $TCHOME/deployed/ ]
then 
    echo -e "${BLU} Deployment Backup directory exists ${STD}"
	else 
	mkdir -p -m 775 $TCHOME/deployed/
	chown tomcat:tomcat $TCHOME/deployed/
	echo -e "${GRN} Deployment Backup directory created ${STD}"
fi

# Lock file so that only one copy can be run. 
# remove lock file during exit
trap 'rm -f $PIDFILE; exit' INT TERM EXIT
 
if [ -f $PIDFILE ] ; then                      
    # lock is already held
    echo >&2 -e "${RED} lock not acquired, giving up: $PIDFILE ${STD}"
    exit 1
else                      
    # nobody owns the lock
    echo $$ > "$PIDFILE"         # create the lock file
    
    # ... commands executed under lock / single instance ...
    echo -e "${BLU} lock acquired: $PIDFILE ${STD}"
fi

# Ask the question.  Where are we getting this from?
read -p "URL of $DN_FILE deployment package: " docpkg

# get the package
cd $DEPLOY_DIR
su tomcat -c "wget $docpkg -O $DN_FILE.war"

# Variable for the files. 
DEPLOY_FILE=$(ls $DEPLOY_DIR/* |tail -1)

# Checking to see if we got the file or not.  
if [ -z $DEPLOY_FILE ]; then
   error_exit "${RED} Directory is empty.  Aborting! ${STD}"
elif  [ -s $DEPLOY_FILE ]; then

# Make a backup of the new Deployment file.  
echo -e "${BLU} Making a backup of the deployment file (just in case). ${STD}"
cp $DEPLOY_FILE $TCHOME/deployed/edm.war.${DDATE}  				 
				 
# Starting in deploying package to the first Tomcat
echo -e "${GRN} Disabling the $DN_FILE 1 Tomcat.  Waiting 180 seconds to stop. ${STD}"
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN1" &> /dev/null
  sleep 180
  echo -e "${GRN} $DN_FILE 1 Tomcat is UP.  Stopping Tomcat. ${STD}"
  su - tomcat -c "$TCHOME_1/bin/shutdown.sh"
  sleep 10
  echo -e "${GRN} Backing up old $DN_FILE ${STD}"  
  su - tomcat -c "rm $WARBACK/$DN_FILE.old"
  sleep 10
  su - tomcat -c "mv $TCHOME_1/webapps/$DN_FILE.old $WARBACK/$DN_FILE.old"
  sleep 10
  su - tomcat -c "mv $TCHOME_1/webapps/$DN_FILE.war $TCHOME_1/webapps/$DN_FILE.old"
  sleep 10
  echo -e "${GRN} Removing old version of $DN_FILE ${STD}"  
  su - tomcat -c "rm -rf $TCHOME_1/webapps/$DN_FILE/*"
  sleep 20
  su - tomcat -c "rmdir $TCHOME_1/webapps/$DN_FILE/" 
  sleep 10
  echo -e "${GRN} Moving new version of $DN_FILE in place ${STD}"  
  cp -p $DEPLOY_FILE $TCHOME_1/webapps/$DN_FILE
  if [ "$?" != "0" ]; then
    error_exit "${RED} Copy Failed.  Aborting! ${STD}"  
  fi
  sleep 10
  echo -e "${GRN} Starting Tomcat ${STD}"
  su - tomcat -c "$TCHOME_1/bin/startup.sh"
  sleep 10
  echo -e "${GRN} enabling Worker. ${STD}"
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP1" &> /dev/null
  
# Starting in deploying package to the second Tomcat
echo -e "${GRN} Disabling the $DN_FILE 2 tomcat.  Waiting 180 seconds to stop. ${STD}"
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN2" &> /dev/null
  sleep 180
  echo -e "${GRN} $DN_FILE 2 Tomcat is UP.  Stopping Tomcat. ${STD}"  
  su - tomcat -c "$TCHOME_2/bin/shutdown.sh"
  sleep 10
  echo -e "${GRN} Backing up old $DN_FILE ${STD}"  
  su - tomcat -c "mv $TCHOME_2/webapps/$DN_FILE.war $TCHOME_2/webapps/$DN_FILE.old"
  sleep 10
  echo -e "${GRN} Removing old version of $DN_FILE ${STD}"  
  su - tomcat -c "rm -rf $TCHOME_2/webapps/$DN_FILE/*"
  sleep 20
  su - tomcat -c "rmdir $TCHOME_2/webapps/$DN_FILE/" 
  sleep 10
  echo -e "${GRN} Moving new version of $DN_FILE in place ${STD}"  
  cp -p $DEPLOY_FILE $TCHOME_2/webapps/$DN_FILE.war
  if [ "$?" != "0" ]; then
    error_exit "${RED} Copy Failed.  Aborting! ${STD}"  
  fi
  sleep 10
  echo -e "${GRN} Starting Tomcat ${STD}"
  su - tomcat -c "$TCHOME_2/bin/startup.sh"
  sleep 10
  echo -e "${GRN} enabling Worker. ${STD}"
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP2" &> /dev/null

# Starting in deploying package to the second Tomcat
echo -e "${GRN} Disabling the $DN_FILE 3 tomcat.  Waiting 180 seconds to stop. ${STD}"
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN3" &> /dev/null
  sleep 180
  echo -e "${GRN} $DN_FILE 3 Tomcat is UP.  Stopping Tomcat. ${STD}"  
  su - tomcat -c "$TCHOME_3/bin/shutdown.sh"
  sleep 10
  echo -e "${GRN} Backing up old $DN_FILE ${STD}"  
  su - tomcat -c "mv $TCHOME_3/webapps/$DN_FILE.war $TCHOME_3/webapps/$DN_FILE.old"
  sleep 10
  echo -e "${GRN} Removing old version of $DN_FILE ${STD}"  
  su - tomcat -c "rm -rf $TCHOME_3/webapps/$DN_FILE/*"
  sleep 20
  su - tomcat -c "rmdir $TCHOME_3/webapps/$DN_FILE/" 
  sleep 10
  echo -e "${GRN} Moving new version of $DN_FILE in place ${STD}"  
  cp -p $DEPLOY_FILE $TCHOME_3/webapps/$DN_FILE.war
  if [ "$?" != "0" ]; then
    error_exit "${RED} Copy Failed.  Aborting! ${STD}"  
  fi
  sleep 10
  echo -e "${GRN} Starting Tomcat ${STD}"
  su - tomcat -c "$TCHOME_3/bin/startup.sh"
  sleep 10
  echo -e "${GRN} enabling Worker. ${STD}"
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP3" &> /dev/null
fi

# Complete the deployment and clean up after ourselves.    
echo -e "${GRN} New $(DN_FILE)s deployed. ${STD}"
echo -e "${GRN} Removing deployment file. ${STD}"
	rm $DEPLOY_FILE 
	rm -rf "$LOCKDIR"
trap - INT TERM EXIT
# Final Checks to make sure we get the correct number of war files after we are done. 
find $TCHOME -name $DN_FILE.war -ls 
TC_DP=$(find $TCHOME -name $DN_FILE.war -ls |wc -l)
if (($TC_DP != 2)); then 
	echo -e "${BLU} Expected 2 Hubsoap War Files, ${RED}found $TC_DP Something went wrong! ${STD}Please check the screen output!"  
	else
	echo -e "${GRN} Checking $DN_FILE war files, looking for 2 found $TC_DP.  Deployment sucessful ${STD}" 
fi
echo "${RED}T${WHT}h${BLU}e ${RED}p${WHT}r${BLU}i${RED}c${WHT}e ${BLU}i${RED}s ${WHT}w${BLU}r${RED}o${WHT}n${BLU}g ${RED}B${WHT}o${BLU}b!" ${STD}
read -p  "Press any key to continue... " -n1 -s
