#!/bin/bash
######################################################################################
# Script to deploy new war files to Tomcats in AWS                                   #
# v1.0.0 - Drew Happli, Karl Schulz - 10/31/2019                                     #
# v2.0.0 - Karl Schulz, Drew Happli - 2/21/2020                                      #
#   Added lists so it will work on servers with other tomcats installed              #
#   Added more verbose output with colors                                            #
######################################################################################

# Variables needed for the script to work. 
# What file are we deploying
DN_FILE=imgsoap

instanceName=("imgsoap1" "imgsoap2")
ports=("8090" "8091")
sys_scripts=("instance10" "instance11")

# Tomcat directories
TCHOME=/tomcat

# These are load balancer IDs needed to drain, shutdown, and start back up the load balancer
# ec2id is the Instance ID of the server (THIS PROBABLY SHOULD NOT CHANGE)
ec2id="$(curl -s http://169.254.169.254/latest/dynamic/instance-identity/document |jq -r '.instanceId')"
# target is the load balancer target (this NEEDS to be changed)
target="arn:aws:elasticloadbalancing:us-east-1:598747928121:targetgroup/pedmdblb03-imgsoap/843d3a50da692c67"


######################################################################################
#                            NO EDITS BELOW HERE                                     #
######################################################################################

max=${#instanceName[@]}

# Set Lock files so this can only be run one at a time (I think)
LOCKDIR=/var/tmp/$DN_FILE/
PIDFILE=$LOCKDIR/$DN_FILE.pid
# Deploy directory
DEPLOY_DIR=$TCHOME/deployment/$DN_FILE
# War file Backup directory
WARBACK=$TCHOME/warback
# Date variable
DDATE=$(date +%m%d%Y)

# Add some color to the messages. 
RED='\033[0;41;30m'
RED_TXT='\e[31m'
STD='\033[0;0;39m'
GRN='\033[30;48;5;82m'
GRN_TXT='\e[32m'
BLU='\033[0;44;97m'
BLU_TXT='\e[94m'
BOLD='\e[1m'

clear
echo -e "${GRN}>>>Beginning $DN_FILE Deployment<<<${STD}" 
echo -e ${BLU}$max instances to update${STD}

#Check the exit status - This allows us to print custom error messages when something goes wrong.  
error_exit() {
    echo -e "$1" 1>&2
    exit 1
}

TCRUN() {
    ps -ef |grep -v grep |grep $1 |wc -l
}

TCRUN2() {
    running=0
    for (( counter = 0; counter < $max; ++counter )); do
        if [[ $(TCRUN ${sys_scripts[$counter]}) -eq 1 ]]
        then
           echo -e ${sys_scripts[$counter]} is ${GRN_TXT}running${STD}
           ((running++))
        else
           echo -e ${sys_scripts[$counter]} is ${RED_TXT}stopped${STD}
        fi
    done
}

# pass in how many instances should be running
validate_running_tomcats() {
    TCRUN2
    if [[ $1 -eq $running ]]; then
        echo -e "Checking Tomcats, looking for $running found $1."        
    else
        echo -e "Expected $1 Tomcats, but ${RED}found $running running! ${STD}Please check the screen output!"
        error_exit "Wrong number of Tomcats! Check Screen output."            
    fi
}

update_file() {
    echo -e "Backing up old $DN_FILE"
    su - tomcat -c "mv $TCHOME/${instanceName[$c]}/webapps/$DN_FILE.war $TCHOME/${instanceName[$c]}/webapps/$DN_FILE.old"
        su - tomcat -c "rm -rf $TCHOME/${instanceName[$c]}/webapps/$DN_FILE/*"
    sleep 10
    su - tomcat -c "rmdir $TCHOME/${instanceName[$c]}/webapps/$DN_FILE/"
    sleep 10
    # Copy in new file in to each directory. 
    echo -e "Moving new version of $DN_FILE in place"  
    cp -p $DEPLOY_FILE $TCHOME/${instanceName[$c]}/webapps/$DN_FILE.war
    if [ "$?" != "0" ]; then
       error_exit "${RED} Copy Failed.  Aborting! ${STD}"  
    fi
}

# Checking to make sure we are running this as Root.  
if [ $(id -u) != "0" ]; then
   echo -e "${RED}You must be the superuser to run this script ${STD}" >&2
   error_exit "You are not Root.  Please run this script with sudo" 1
fi

create_dir()
{
    # Creating directories needed if they are not there.
    # This is the PID directory. So that we only run the script once.
    if [ -d $1 ]
        then
            echo -e "$1 Directory exists"
        else
        mkdir -p -m $2 $1
        chown tomcat:tomcat $1
        echo -e "${GRN} $1 Directory created ${STD}"
    fi
}

create_dir $LOCKDIR 777
create_dir $DEPLOY_DIR 777
create_dir $WARBACK 775
create_dir $TCHOME/deployed/ 775

# Lock file so that only one copy can be run. 
# remove lock file during exit
trap 'rm -f $PIDFILE; exit' INT TERM EXIT

# this is the section that creates the lock file, or exits if there is already a lock file.   
if [ -f $PIDFILE ] ; then                      
    # lock is already held
    echo >&2 -e "${RED} lock not acquired, Is the script already running?  Giving up: $PIDFILE ${STD}"
    exit 1
else                      
    # nobody owns the lock
    echo $$ > "$PIDFILE"         # create the lock file
    
    # ... commands executed under lock / single instance ...
    echo -e "${BLU} lock acquired: $PIDFILE ${STD}"
fi

# Ask the question.  Where are we getting the war file from?
read -p "URL of $DN_FILE deployment package: " docpkg

# get the package
cd $DEPLOY_DIR
su tomcat -c "wget $docpkg -O $DN_FILE.war"

# Variable for the files. 
DEPLOY_FILE=$(ls $DEPLOY_DIR/* |tail -1)

# Checking to see if we got the file or not.  
if [ -z $DEPLOY_FILE ]; then
   error_exit "${RED} Directory is empty.  Aborting! ${STD}"
fi

# Make a backup of the new Deployment file.  
echo -e "${BLU} Making a backup of the deployment file (just in case). ${STD}"
cp $DEPLOY_FILE $TCHOME/deployed/$DN_FILE.war.$DDATE  
su - tomcat -c "rm $WARBACK/$DN_FILE.old"
su - tomcat -c "mv $TCHOME/${instanceName[$c]}/webapps/$DN_FILE.old $WARBACK/$DN_FILE.old"

iteration_count=$([ $max -eq 1 ] && echo 0 || echo 1)
echo iteration_count: $iteration_count

# There are 2 iterations, odds and evens
for (( iteration = 0; iteration <= $iteration_count; ++iteration )); do

    # used to store how many instances are updated in this Set
    affected_instances=0

    targets=""
    for (( c = $iteration; c < $max; c+=2 )); do
        ((affected_instances++))
        targets+=" Id=$ec2id,Port=${ports[$c]}"
    done

    echo -e "\n${BLU}Updating ${affected_instances} instances${STD}"

    # remove from load balancer target group
    echo draining targets: $targets
    aws elbv2 deregister-targets --region us-east-1 --target-group-arn $target --targets$targets

    # sleep 5 mins
    sleep 300
    # sleep 3

    # stop tomcats
    for (( c = $iteration; c < $max; c+=2 )); do
        echo stopping ${sys_scripts[$c]}
        sudo systemctl stop tomcat@${sys_scripts[$c]}
    done
    sleep 1

        # Checks to make sure we have the right number of tomcats running. 
        validate_running_tomcats $((max - affected_instances))

    echo -e "${BLU_TXT}Instances drained and stopped. Deploying files.${STD}"

    # Making a backup of the new oldest file
    for (( c = $iteration; c < $max; c+=2 )); do
        update_file $c
    done

    echo -e "${BLU_TXT}Files updated. Starting instances.${STD}"

    # start tomcats
    for (( c = $iteration; c < $max; c+=2 )); do
        echo starting ${sys_scripts[$c]}
            sudo systemctl start tomcat@${sys_scripts[$c]}
    done
    sleep 1

        # Checks to make sure we have the correct number of tomcats running
        validate_running_tomcats $max

        # add to load balancer target group
    echo adding targets: $targets
    aws elbv2 register-targets --region us-east-1 --target-group-arn $target --targets$targets

        # Notification that that instance was updated.  
    echo -e "${BLU}$affected_instances instances updated successfully${STD}"
done

# Final Checks to make sure we get the correct number of war files after we are done. 
TC_DF=$(find $TCHOME -name $DN_FILE.war -ls |grep -v deployment |wc -l)
if (($TC_DF != $max)); then 
        echo -e "\nExpected $max $DN_FILE War Files, ${RED}found $TC_DF Something went wrong! ${STD}Please check the screen output!"  
else
        echo -e "\nChecking $DN_FILE war files, looking for $max found $TC_DF."
    echo -e "${GRN}Deployment sucessful ${STD}" 
fi

read -p  "Press any key to continue... " -n1 -s