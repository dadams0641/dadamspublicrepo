#!/usr/bin/bash
# context.xml deployment script
# Version 2.0.0
# 1.0.0 Initial script. 
# 2.0.0 Complete Rewrite
# Written badly by Drew.

# What file are we downloading
# Deployment file
DN_FILE=context

# Set Lock files so this can only be run once (I think)
LOCKDIR=/var/tmp/$DN_FILE/
PIDFILE=$LOCKDIR/context.pid

# Variable for the URLS
TCSERVER=$(uname -n)

# Date variable
DDATE=$(date +%Y%m%d)

# Variable for the total number of Tomcats Running
TCR=18

# Variable for Tomcats running when shutting down some of them. 
TCD=9

# War file Backup directory
WARBACK=/home/tomcat/context/backup/$DDATE

# The location of the files to be deployed.
DTCHOME=/home/tomcat/deployment/$DDATE

# Instance names
INST1=lkw_doc1
INST2=lkw_doc2
INST3=lkw_doc3
INST4=lkw_doc4
INST7=lkw_doc7
INST8=lkw_doc8
INST9=lkw_doc9
INST10=lkw_doc10
INST11=lkw_doc11
INST12=lkw_doc12
INST13=lkw_doc13
INST14=lkw_doc14
INST15=lkw_doc15
INST16=lkw_doc16
INST17=lkw_doc17
INST18=lkw_doc18
INST19=lkw_doc19
INST20=lkw_doc20


# Tomcat Home Directory - These are the directories where Tomcat resides and is run out of.   The base directory is first, then the individual directories.  
TCHOME=/tomcat/
TCHOME_1=$TCHOME/$INST1
TCHOME_2=$TCHOME/$INST2
TCHOME_3=$TCHOME/$INST3
TCHOME_4=$TCHOME/$INST4
TCHOME_7=$TCHOME/$INST7
TCHOME_8=$TCHOME/$INST8
TCHOME_9=$TCHOME/$INST9
TCHOME_10=$TCHOME/$INST10
TCHOME_11=$TCHOME/$INST11
TCHOME_12=$TCHOME/$INST12
TCHOME_13=$TCHOME/$INST13
TCHOME_14=$TCHOME/$INST14
TCHOME_15=$TCHOME/$INST15
TCHOME_16=$TCHOME/$INST16
TCHOME_17=$TCHOME/$INST17
TCHOME_18=$TCHOME/$INST18
TCHOME_19=$TCHOME/$INST19
TCHOME_20=$TCHOME/$INST20

# Add some color to the messages. 
RED='\033[0;41;30m'
STD='\033[0;0;39m'
GRN='\033[30;48;5;82m'
BLU='\033[0;44;97m'

# URLS for disabling the tomcat in the Apache load balancer
  URLCATDN1="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc1&vwa=1"
  URLCATDN2="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc2&vwa=1"
  URLCATDN3="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc3&vwa=1"
  URLCATDN4="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc4&vwa=1"
  URLCATDN7="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc7&vwa=1"
  URLCATDN8="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc8&vwa=1"
  URLCATDN9="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc9&vwa=1"
  URLCATDN10="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc10&vwa=1"
  URLCATDN11="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc11&vwa=1"
  URLCATDN12="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc12&vwa=1"
  URLCATDN13="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc13&vwa=1"
  URLCATDN14="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc14&vwa=1"
  URLCATDN15="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc15&vwa=1"
  URLCATDN16="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc16&vwa=1"
  URLCATDN17="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc17&vwa=1"
  URLCATDN18="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc18&vwa=1"
  URLCATDN19="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc19&vwa=1"  
  URLCATDN20="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc20&vwa=1"  

# URLS for enabling the tomcat in the Apache load balancer.    
  URLCATUP1="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc1&vwa=0"
  URLCATUP2="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc2&vwa=0"
  URLCATUP3="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc3&vwa=0"
  URLCATUP4="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc4&vwa=0"
  URLCATUP7="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc7&vwa=0"
  URLCATUP8="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc8&vwa=0"
  URLCATUP9="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc9&vwa=0"
  URLCATUP10="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc10&vwa=0"
  URLCATUP11="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc11&vwa=0"
  URLCATUP12="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc12&vwa=0"
  URLCATUP13="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc13&vwa=0"
  URLCATUP14="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc14&vwa=0"
  URLCATUP15="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc15&vwa=0"
  URLCATUP16="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc16&vwa=0"
  URLCATUP17="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc17&vwa=0"
  URLCATUP18="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc18&vwa=0"
  URLCATUP19="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc19&vwa=0"
  URLCATUP20="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w=docbalancer&sw=tomcat_doc20&vwa=0"
  
#Check the exit status - This allows us to print custom error messages when something goes wrong.  
error_exit()
{
        echo -e "$1" 1>&2
        exit 1
}

TCRUN()
{
		ps -ef |grep tomcat |grep doc |grep -v grep |grep -v hub |grep -v img |wc -l
}

# Checking to make sure we are running this as Root.  
if [ $(id -u) != "0" ]; then
    echo "You must be the superuser to run this script" >&2
    error_exit "You are not Root.  Please run this script with sudo" 1
fi
# Creating directories needed if they are not there. 
# This is the PID directory. So that we only run the script once. 
if [ -d $LOCKDIR ]
then 
    echo -e "${BLU} Java Deployment PID Directory exists ${STD}"
	else 
	mkdir -p -m 777 $LOCKDIR
	chown tomcat:tomcat $LOCKDIR
	echo -e "${GRN} Java Deployment PID Directory created ${STD}"
fi

# Back up directory - This is where we back up the oldest version of the deployment war file.  
if [ -d $WARBACK ]
then 
    echo -e "${BLU} Warback directory exists ${STD}"
	else 
	mkdir -p -m 775 $WARBACK
	mkdir -p -m 775 $WARBACK/$INST1
	mkdir -p -m 775 $WARBACK/$INST2
	mkdir -p -m 775 $WARBACK/$INST3
	mkdir -p -m 775 $WARBACK/$INST4
	mkdir -p -m 775 $WARBACK/$INST7
	mkdir -p -m 775 $WARBACK/$INST8
	mkdir -p -m 775 $WARBACK/$INST9
	mkdir -p -m 775 $WARBACK/$INST10
	mkdir -p -m 775 $WARBACK/$INST11
	mkdir -p -m 775 $WARBACK/$INST12
	mkdir -p -m 775 $WARBACK/$INST13
	mkdir -p -m 775 $WARBACK/$INST14
	mkdir -p -m 775 $WARBACK/$INST15
	mkdir -p -m 775 $WARBACK/$INST16
	mkdir -p -m 775 $WARBACK/$INST17
	mkdir -p -m 775 $WARBACK/$INST18
	mkdir -p -m 775 $WARBACK/$INST19
	mkdir -p -m 775 $WARBACK/$INST20
	chown -R tomcat:tomcat $WARBACK
	echo -e "${GRN} Warback directory created ${STD}"

fi

# Lock file so that only one copy can be run. 
# remove lock file during exit
trap 'rm -f $PIDFILE; exit' INT TERM EXIT
 
if [ -f $PIDFILE ] ; then                      
    # lock is already held
    echo >&2 -e "${RED} lock not acquired, Is the script already running?  Giving up: $PIDFILE ${STD}"
    exit 1
else                      
    # nobody owns the lock
    echo $$ > "$PIDFILE"         # create the lock file
    
    # ... commands executed under lock / single instance ...
    echo -e "${BLU} lock acquired: $PIDFILE ${STD}"
fi

# Disabling Tomcats in the Apache Load Balancer
echo -e "${GRN} Disabling the Odd Tomcats.  Waiting 180 seconds to stop. ${STD}"
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN1" &> /dev/null
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN3" &> /dev/null
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN7" &> /dev/null
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN9" &> /dev/null
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN11" &> /dev/null
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN13" &> /dev/null
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN15" &> /dev/null
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN17" &> /dev/null
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN19" &> /dev/null
sleep 180

# Shutting down the Tomcats
echo -e "${GRN} Stopping Odd Tomcats. ${STD}"
  su - tomcat -c "$TCHOME_1/bin/shutdown.sh"
  su - tomcat -c "$TCHOME_3/bin/shutdown.sh"
  su - tomcat -c "$TCHOME_7/bin/shutdown.sh"
  su - tomcat -c "$TCHOME_9/bin/shutdown.sh"
  su - tomcat -c "$TCHOME_11/bin/shutdown.sh"
  su - tomcat -c "$TCHOME_13/bin/shutdown.sh"
  su - tomcat -c "$TCHOME_15/bin/shutdown.sh"
  su - tomcat -c "$TCHOME_17/bin/shutdown.sh"
  su - tomcat -c "$TCHOME_19/bin/shutdown.sh"
sleep 30

# Checks to make sure we have the right number of tomcats running. 
TC_DP=$( TCRUN )
if (($TC_DP != $TCD)); then 
	echo -e "Expected $TCD Tocmats, ${RED}found $TC_DP Something went wrong! ${STD}Please check the screen output!"
    error_exit "Too many Tomcats!  Check Screen output."	
	else
	echo -e "${GRN} Checking Tomcats, looking for $TCD found $TC_DP.  Shutdown sucessful ${STD}" 
fi

# Backup the current XML files
su - tomcat -c "mv $TCHOME_1/conf/context.xml $WARBACK/$INST1/context.xml.$DDATE"
su - tomcat -c "mv $TCHOME_3/conf/context.xml $WARBACK/$INST3/context.xml.$DDATE"
su - tomcat -c "mv $TCHOME_7/conf/context.xml $WARBACK/$INST7/context.xml.$DDATE"
su - tomcat -c "mv $TCHOME_9/conf/context.xml $WARBACK/$INST9/context.xml.$DDATE"
su - tomcat -c "mv $TCHOME_11/conf/context.xml $WARBACK/$INST11/context.xml.$DDATE"
su - tomcat -c "mv $TCHOME_13/conf/context.xml $WARBACK/$INST13/context.xml.$DDATE"
su - tomcat -c "mv $TCHOME_15/conf/context.xml $WARBACK/$INST15/context.xml.$DDATE"
su - tomcat -c "mv $TCHOME_17/conf/context.xml $WARBACK/$INST17/context.xml.$DDATE"
su - tomcat -c "mv $TCHOME_19/conf/context.xml $WARBACK/$INST19/context.xml.$DDATE"

# Copy the new XML file
su - tomcat -c "cp $DTCHOME/$INST1/conf/context.xml $TCHOME_1/conf/"
su - tomcat -c "cp $DTCHOME/$INST3/conf/context.xml $TCHOME_3/conf/"
su - tomcat -c "cp $DTCHOME/$INST7/conf/context.xml $TCHOME_7/conf/"
su - tomcat -c "cp $DTCHOME/$INST9/conf/context.xml $TCHOME_9/conf/"
su - tomcat -c "cp $DTCHOME/$INST11/conf/context.xml $TCHOME_11/conf/"
su - tomcat -c "cp $DTCHOME/$INST13/conf/context.xml $TCHOME_13/conf/"
su - tomcat -c "cp $DTCHOME/$INST15/conf/context.xml $TCHOME_15/conf/"
su - tomcat -c "cp $DTCHOME/$INST17/conf/context.xml $TCHOME_17/conf/"
su - tomcat -c "cp $DTCHOME/$INST19/conf/context.xml $TCHOME_19/conf/"

# Starting up the Tomcats
echo -e "${GRN} Starting the Odd Tomcats. ${STD}"
  su - tomcat -c "$TCHOME_1/bin/startup.sh"
  su - tomcat -c "$TCHOME_3/bin/startup.sh"
  su - tomcat -c "$TCHOME_7/bin/startup.sh"
  su - tomcat -c "$TCHOME_9/bin/startup.sh"
  su - tomcat -c "$TCHOME_11/bin/startup.sh"
  su - tomcat -c "$TCHOME_13/bin/startup.sh"
  su - tomcat -c "$TCHOME_15/bin/startup.sh"
  su - tomcat -c "$TCHOME_17/bin/startup.sh"
  su - tomcat -c "$TCHOME_19/bin/startup.sh"
sleep 30

# Enabling Tomcats in the Apache Load Balancer
echo -e "${GRN} Enabling the Odd Tomcats.  Waiting 180 seconds to stop. ${STD}"
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP1" &> /dev/null
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP3" &> /dev/null
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP7" &> /dev/null
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP9" &> /dev/null
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP11" &> /dev/null
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP13" &> /dev/null
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP15" &> /dev/null
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP17" &> /dev/null
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP19" &> /dev/null
sleep 30

# Checks to make sure we have the right number of tomcats running. 
TC_DP=$( TCRUN )
if (($TC_DP != $TCR)); then 
	echo -e "Expected $TCR Tocmats, ${RED}found $TC_DP Something went wrong! ${STD}Please check the screen output!"
    error_exit "Too many Tomcats!  Check Screen output."	
	else
	echo -e "${GRN} Checking Tomcats, looking for $TCR found $TC_DP.  Shutdown sucessful ${STD}" 
fi

# Disabling Tomcats in the Apache Load Balancer
echo -e "${GRN} Disabling the Even Tomcats.  Waiting 180 seconds to stop. ${STD}"
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN2" &> /dev/null
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN4" &> /dev/null
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN8" &> /dev/null
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN10" &> /dev/null
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN12" &> /dev/null
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN14" &> /dev/null
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN16" &> /dev/null
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN18" &> /dev/null
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN20" &> /dev/null
sleep 180

# Shutting down the Tomcats
echo -e "${GRN} Stopping Even Tomcats. ${STD}"
  su - tomcat -c "$TCHOME_2/bin/shutdown.sh"
  su - tomcat -c "$TCHOME_4/bin/shutdown.sh"
  su - tomcat -c "$TCHOME_8/bin/shutdown.sh"
  su - tomcat -c "$TCHOME_10/bin/shutdown.sh"
  su - tomcat -c "$TCHOME_12/bin/shutdown.sh"
  su - tomcat -c "$TCHOME_14/bin/shutdown.sh"
  su - tomcat -c "$TCHOME_16/bin/shutdown.sh"
  su - tomcat -c "$TCHOME_18/bin/shutdown.sh"
  su - tomcat -c "$TCHOME_20/bin/shutdown.sh"
sleep 30

# Checks to make sure we have the right number of tomcats running. 
TC_DP=$( TCRUN )
if (($TC_DP != $TCD)); then 
	echo -e "Expected $TCD Tocmats, ${RED}found $TC_DP Something went wrong! ${STD}Please check the screen output!"
    error_exit "Too many Tomcats!  Check Screen output."	
	else
	echo -e "${GRN} Checking Tomcats, looking for $TCD found $TC_DP.  Shutdown sucessful ${STD}" 
fi

# Backup the current XML files
su - tomcat -c "mv $TCHOME_2/conf/context.xml $WARBACK/$INST2/context.xml.$DDATE"
su - tomcat -c "mv $TCHOME_4/conf/context.xml $WARBACK/$INST4/context.xml.$DDATE"
su - tomcat -c "mv $TCHOME_8/conf/context.xml $WARBACK/$INST8/context.xml.$DDATE"
su - tomcat -c "mv $TCHOME_10/conf/context.xml $WARBACK/$INST10/context.xml.$DDATE"
su - tomcat -c "mv $TCHOME_12/conf/context.xml $WARBACK/$INST12/context.xml.$DDATE"
su - tomcat -c "mv $TCHOME_14/conf/context.xml $WARBACK/$INST14/context.xml.$DDATE"
su - tomcat -c "mv $TCHOME_16/conf/context.xml $WARBACK/$INST16/context.xml.$DDATE"
su - tomcat -c "mv $TCHOME_18/conf/context.xml $WARBACK/$INST18/context.xml.$DDATE"
su - tomcat -c "mv $TCHOME_20/conf/context.xml $WARBACK/$INST20/context.xml.$DDATE"

# Copy the new XML file
su - tomcat -c "cp $DTCHOME/$INST/conf/context.xml $TCHOME_2/conf/"
su - tomcat -c "cp $DTCHOME/$INST4/conf/context.xml $TCHOME_4/conf/"
su - tomcat -c "cp $DTCHOME/$INST6/conf/context.xml $TCHOME_6/conf/"
su - tomcat -c "cp $DTCHOME/$INST8/conf/context.xml $TCHOME_8/conf/"
su - tomcat -c "cp $DTCHOME/$INST10/conf/context.xml $TCHOME_10/conf/"
su - tomcat -c "cp $DTCHOME/$INST12/conf/context.xml $TCHOME_12/conf/"
su - tomcat -c "cp $DTCHOME/$INST14/conf/context.xml $TCHOME_14/conf/"
su - tomcat -c "cp $DTCHOME/$INST16/conf/context.xml $TCHOME_16/conf/"
su - tomcat -c "cp $DTCHOME/$INST18/conf/context.xml $TCHOME_18/conf/"
su - tomcat -c "cp $DTCHOME/$INST20/conf/context.xml $TCHOME_20/conf/"

# Starting up the Tomcats
echo -e "${GRN} Starting the Odd Tomcats. ${STD}"
  su - tomcat -c "$TCHOME_2/bin/startup.sh"
  su - tomcat -c "$TCHOME_4/bin/startup.sh"
  su - tomcat -c "$TCHOME_8/bin/startup.sh"
  su - tomcat -c "$TCHOME_10/bin/startup.sh"
  su - tomcat -c "$TCHOME_12/bin/startup.sh"
  su - tomcat -c "$TCHOME_14/bin/startup.sh"
  su - tomcat -c "$TCHOME_16/bin/startup.sh"
  su - tomcat -c "$TCHOME_18/bin/startup.sh"
  su - tomcat -c "$TCHOME_20/bin/startup.sh"
sleep 30

# Enabling Tomcats in the Apache Load Balancer
echo -e "${GRN} Enabling the Odd Tomcats.  Waiting 180 seconds to stop. ${STD}"
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP2" &> /dev/null
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP4" &> /dev/null
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP8" &> /dev/null
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP10" &> /dev/null
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP12" &> /dev/null
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP14" &> /dev/null
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP16" &> /dev/null
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP18" &> /dev/null
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP20" &> /dev/null
sleep 30

# Checks to make sure we have the right number of tomcats running. 
TC_DP=$( TCRUN )
if (($TC_DP != $TCR)); then 
	echo -e "Expected $TCR Tocmats, ${RED}found $TC_DP Something went wrong! ${STD}Please check the screen output!"
    error_exit "Too many Tomcats!  Check Screen output."	
	else
	echo -e "${GRN} Checking Tomcats, looking for $TCR found $TC_DP.  Shutdown sucessful ${STD}" 
fi

# Deployment complete, now to start the clean up.    
	echo -e "${GRN} New $DN_FILE deployed. ${STD}"
	rm -rf "$LOCKDIR"
	trap - INT TERM EXIT









