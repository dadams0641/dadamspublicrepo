#!/usr/bin/bash
# Production EDMS BE $DN_FILE deployment script
# Version 1.2.3
# Added a backup of the downloaded file.  
# Added color coding to messages.  The bottom half of the script is now using variables.  The whole of the script is now using paramiters instead of being hard coded. 
# Added directory checking to make sure we have our needed directories. 
# Written badly by Drew.

# Variable for which deployment war file this script is going to deploy.  Change this with each script.  
# Deployment file
DN_FILE=hubsoap

#Below are the variables that change with each individual script.  
# Set Lock files so this can only be run once (I think)
LOCKDIR=/var/tmp/deployhub/
PIDFILE=/var/tmp/deployhub/javacore.pid

# Tomcat Home Directory
TCHOME=/tomcat/
TCHOME_1=/tomcat/tomcat01
TCHOME_2=/tomcat/tomcat02
TCHOME_3=/tomcat/tomcat03
TCHOME_4=/tomcat/tomcat04
TCHOME_5=/tomcat/tomcat05
TCHOME_6=/tomcat/tomcat06
TCHOME_7=/tomcat/tomcat07
TCHOME_8=/tomcat/tomcat08
TCHOME_9=/tomcat/tomcat09
TCHOME_10=/tomcat/tomcat10
TCHOME_11=/tomcat/tomcat11
TCHOME_12=/tomcat/tomcat12
TCHOME_13=/tomcat/tomcat13
TCHOME_14=/tomcat/tomcat14
TCHOME_15=/tomcat/tomcat15
TCHOME_16=/tomcat/tomcat16
TCHOME_17=/tomcat/tomcat17
TCHOME_18=/tomcat/tomcat18
TCHOME_19=/tomcat/tomcat19
TCHOME_20=/tomcat/tomcat20

# URLS for disabling the tomcat in the Apache load balancer
URLCATDN1="http://in-pedmbeax04.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat1&vwa=1"
URLCATDN2="http://in-pedmbeax04.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat2&vwa=1"
URLCATDN3="http://in-pedmbeax04.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat3&vwa=1"
URLCATDN4="http://in-pedmbeax04.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat4&vwa=1"
URLCATDN5="http://in-pedmbeax04.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat5&vwa=1"
URLCATDN6="http://in-pedmbeax04.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat6&vwa=1"
URLCATDN7="http://in-pedmbeax04.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat7&vwa=1"
URLCATDN8="http://in-pedmbeax04.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat8&vwa=1"
URLCATDN9="http://in-pedmbeax04.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat9&vwa=1"
URLCATDN10="http://in-pedmbeax04.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat10&vwa=1"
URLCATDN11="http://in-pedmbeax04.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat11&vwa=1"
URLCATDN12="http://in-pedmbeax04.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat12&vwa=1"
URLCATDN13="http://in-pedmbeax04.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat13&vwa=1"
URLCATDN14="http://in-pedmbeax04.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat14&vwa=1"
URLCATDN15="http://in-pedmbeax04.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat15&vwa=1"
URLCATDN16="http://in-pedmbeax04.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat16&vwa=1"
URLCATDN17="http://in-pedmbeax04.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat17&vwa=1"
URLCATDN18="http://in-pedmbeax04.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat18&vwa=1"
URLCATDN19="http://in-pedmbeax04.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat19&vwa=1"
URLCATDN20="http://in-pedmbeax04.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat20&vwa=1"

# URLS for enabling the tomcat in the Apache load balancer    
URLCATUP1="http://in-pedmbeax04.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat1&vwa=0" 
URLCATUP2="http://in-pedmbeax04.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat2&vwa=0"
URLCATUP3="http://in-pedmbeax04.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat3&vwa=0"
URLCATUP4="http://in-pedmbeax04.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat4&vwa=0"
URLCATUP5="http://in-pedmbeax04.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat5&vwa=0"
URLCATUP6="http://in-pedmbeax04.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat6&vwa=0"
URLCATUP7="http://in-pedmbeax04.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat7&vwa=0"
URLCATUP8="http://in-pedmbeax04.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat8&vwa=0"
URLCATUP9="http://in-pedmbeax04.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat9&vwa=0"
URLCATUP10="http://in-pedmbeax04.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat10&vwa=0"
URLCATUP11="http://in-pedmbeax04.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat11&vwa=0"
URLCATUP12="http://in-pedmbeax04.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat12&vwa=0"
URLCATUP13="http://in-pedmbeax04.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat13&vwa=0"
URLCATUP14="http://in-pedmbeax04.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat14&vwa=0"
URLCATUP15="http://in-pedmbeax04.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat15&vwa=0"
URLCATUP16="http://in-pedmbeax04.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat16&vwa=0"
URLCATUP17="http://in-pedmbeax04.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat17&vwa=0"
URLCATUP18="http://in-pedmbeax04.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat18&vwa=0"
URLCATUP19="http://in-pedmbeax04.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat19&vwa=0"
URLCATUP20="http://in-pedmbeax04.fhmc.local:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat20&vwa=0"

# Variables that are the same in every script.  
# Deploy directory
DEPLOY_DIR=/deployment/$DN_FILE

# War file Backup directory
WARBACK=/home/tomcat/warback

# Date variable
DDATE=`date +%F.%T`

# Add some color to the messages. 
RED='\033[0;41;30m'
STD='\033[0;0;39m'
GRN='\033[30;48;5;82m'
BLU='\033[0;44;97m'

#Check the exit status
error_exit()
{
        echo -e "$1" 1>&2
        exit 1
}

# Creating directories needed if they are not there. 
# This is the PID directory
if [ -d $LOCKDIR ]
then 
    echo -e "${BLU} Java Deployment PID Directory exists ${STD}"
	else 
	mkdir -p -m 777 $LOCKDIR
	chown tomcat:tomcat $LOCKDIR
	echo -e "${GRN} Java Deployment PID Directory created ${STD}"
fi
# Deployment directory
if [ -d $DEPLOY_DIR ]
then 
    echo -e "${BLU} Deployment directory exists ${STD}"
	else 
	mkdir -p -m 777 $DEPLOY_DIR
	echo -e "${GRN} $DN_FILE Deployment directory created ${STD}"
fi
# Back up directory
if [ -d $WARBACK ]
then 
    echo -e "${BLU} Warback directory exists ${STD}"
	else 
	mkdir -p -m 775 $WARBACK
	chown tomcat:tomcat $WARBACK
	echo -e "${GRN} Warback directory created ${STD}"
fi

# Back up deployment directory
if [ -d $TCHOME/deployed/ ]
then 
    echo -e "${BLU} Deployment Backup directory exists ${STD}"
	else 
	mkdir -p -m 775 $TCHOME/deployed/
	chown tomcat:tomcat $TCHOME/deployed/
	echo -e "${GRN} Deployment Backup directory created ${STD}"
fi

# Lock file so that only one copy can be run. 
# remove lock file during exit
trap 'rm -f $PIDFILE; exit' INT TERM EXIT
 
if [ -f $PIDFILE ] ; then                      
    # lock is already held
    echo >&2 -e "${RED} lock not acquired, giving up: $PIDFILE ${STD}"
    exit 1
else                      
    # nobody owns the lock
    echo $$ > "$PIDFILE"         # create the lock file
    
    # ... commands executed under lock / single instance ...
    echo -e "${BLU} lock acquired: $PIDFILE ${STD}"
fi

# Ask the question.  Where are we getting this from?
read -p "URL of HUBSOAP deployment package: " docpkg

# get the package
cd $DEPLOY_DIR
su tomcat -c "wget $docpkg -O $DN_FILE.war"

# Variable for the files. 
DEPLOY_FILE=$(ls $DEPLOY_DIR/* |tail -1)

# Checking to see if we got the file or not.  
if [ -z $DEPLOY_FILE ]; then
   error_exit "${RED} Directory is empty.  Aborting! ${STD}"
elif  [ -s $DEPLOY_FILE ]; then

# Make a backup of the new Deployment file.  
echo -e "${BLU} Making a backup of the deployment file (just in case). ${STD}"
cp $DEPLOY_FILE $TCHOME/deployed/edm.war.${DDATE}  				 
				 
# Starting in deploying package to the first Tomcat
echo -e "${GRN} Disabling the $DN_FILE 1 Tomcat.  Waiting 180 seconds to stop. ${STD}"
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN1" &> /dev/null
  sleep 180
  echo -e "${GRN} $DN_FILE 1 Tomcat is UP.  Stopping Tomcat. ${STD}"
  su - tomcat -c "$TCHOME_1/bin/shutdown.sh"
  sleep 10
  echo -e "${GRN} Backing up old $DN_FILE ${STD}"  
  su - tomcat -c "rm $WARBACK/$DN_FILE.old"
  sleep 10
  su - tomcat -c "mv $TCHOME_1/webapps/$DN_FILE.old $WARBACK/$DN_FILE.old"
  sleep 10
  su - tomcat -c "mv $TCHOME_1/webapps/$DN_FILE.war $TCHOME_1/webapps/$DN_FILE.old"
  sleep 10
  echo -e "${GRN} Removing old version of $DN_FILE ${STD}"  
  su - tomcat -c "rm -rf $TCHOME_1/webapps/$DN_FILE/*"
  sleep 20
  su - tomcat -c "rmdir $TCHOME_1/webapps/$DN_FILE/" 
  sleep 10
  echo -e "${GRN} Moving new version of $DN_FILE in place ${STD}"  
  cp -p $DEPLOY_FILE $TCHOME_1/webapps/$DN_FILE
  if [ "$?" != "0" ]; then
    error_exit "${RED} Copy Failed.  Aborting! ${STD}"  
  fi
  sleep 10
  echo -e "${GRN} Starting Tomcat"
  su - tomcat -c "$TCHOME_1/bin/startup.sh"
  sleep 10
  echo -e "${GRN} enabling Worker."
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP1" &> /dev/null
  
# Starting in deploying package to the second Tomcat
echo -e "${GRN} Disabling the $DN_FILE 2 tomcat.  Waiting 180 seconds to stop."
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN2" &> /dev/null
  sleep 180
  echo -e "${GRN} $DN_FILE 2 Tomcat is UP.  Stopping Tomcat. ${STD}"  
  su - tomcat -c "$TCHOME_2/bin/shutdown.sh"
  sleep 10
  echo -e "${GRN} Backing up old $DN_FILE ${STD}"  
  su - tomcat -c "mv $TCHOME_2/webapps/$DN_FILE.war $TCHOME_2/webapps/$DN_FILE.old"
  sleep 10
  echo -e "${GRN} Removing old version of $DN_FILE ${STD}"  
  su - tomcat -c "rm -rf $TCHOME_2/webapps/$DN_FILE/*"
  sleep 20
  su - tomcat -c "rmdir $TCHOME_2/webapps/$DN_FILE/" 
  sleep 10
  echo -e "${GRN} Moving new version of $DN_FILE in place ${STD}"  
  cp -p $DEPLOY_FILE $TCHOME_2/webapps/$DN_FILE.war
  if [ "$?" != "0" ]; then
    error_exit "${RED} Copy Failed.  Aborting! ${STD}"  
  fi
  sleep 10
  echo -e "${GRN} Starting Tomcat ${STD}"
  su - tomcat -c "$TCHOME_2/bin/startup.sh"
  sleep 10
  echo -e "${GRN} enabling Worker. ${STD}"
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP2" &> /dev/null
  
  # Starting in deploying package to the third Tomcat
echo -e "${GRN} Disabling the $DN_FILE 3 tomcat.  Waiting 180 seconds to stop. ${STD}"
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN3" &> /dev/null
  sleep 180
  echo -e "${GRN} $DN_FILE 2 Tomcat is UP.  Stopping Tomcat. ${STD}"
  su - tomcat -c "$TCHOME_3/bin/shutdown.sh"
  sleep 10
  echo -e "${GRN} Backing up old $DN_FILE ${STD}"  
  su - tomcat -c "mv $TCHOME_3/webapps/$DN_FILE.war $TCHOME_3/webapps/$DN_FILE.old"
  sleep 10
  echo -e "${GRN} Removing old version of $DN_FILE ${STD}"  
  su - tomcat -c "rm -rf $TCHOME_3/webapps/$DN_FILE/*"
  sleep 20
  su - tomcat -c "rmdir $TCHOME_3/webapps/$DN_FILE/" 
  sleep 10
  echo -e "${GRN} Moving new version of $DN_FILE in place ${STD}"  
  cp -p $DEPLOY_FILE $TCHOME_3/webapps/$DN_FILE.war
  if [ "$?" != "0" ]; then
    error_exit "${RED} Copy Failed.  Aborting! ${STD}"  
  fi
  sleep 10
  echo -e "${GRN} Starting Tomcat ${STD}"
  su - tomcat -c "$TCHOME_3/bin/startup.sh"
  sleep 10
  echo -e "${GRN} enabling Worker. ${STD}"
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP3" &> /dev/null
  
  # Starting in deploying package to the fourth Tomcat
echo -e "${GRN} Disabling the $DN_FILE 4 tomcat.  Waiting 180 seconds to stop. ${STD}"
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN4" &> /dev/null
  sleep 180
  echo -e "${GRN} $DN_FILE 3 Tomcat is UP.  Stopping Tomcat. ${STD}"  
  su - tomcat -c "$TCHOME_4/bin/shutdown.sh"
  sleep 10
  echo -e "${GRN} Backing up old $DN_FILE ${STD}"
  su - tomcat -c "mv $TCHOME_4/webapps/$DN_FILE.war $TCHOME_4/webapps/$DN_FILE.old"
  sleep 10
  echo -e "${GRN} Removing old version of $DN_FILE ${STD}"
  su - tomcat -c "rm -rf $TCHOME_4/webapps/$DN_FILE/*"
  sleep 20
  su - tomcat -c "rmdir $TCHOME_4/webapps/$DN_FILE/" 
  sleep 10
  echo -e "${GRN} Moving new version of $DN_FILE in place ${STD}"
  cp -p $DEPLOY_FILE $TCHOME_4/webapps/$DN_FILE.war
  if [ "$?" != "0" ]; then
    error_exit "${RED} Copy Failed.  Aborting! ${STD}"  
  fi
  sleep 10
  echo -e "${GRN} Starting Tomcat ${STD}"
  su - tomcat -c "$TCHOME_4/bin/startup.sh"
  sleep 10
  echo -e "${GRN} enabling Worker. ${STD}"
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP4" &> /dev/null

# Starting in deploying package to the Fifth Tomcat
echo -e "${GRN} Disabling the $DN_FILE 5 tomcat.  Waiting 180 seconds to stop. ${STD}"
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN5" &> /dev/null
  sleep 180
  echo -e "${GRN} $DN_FILE 3 Tomcat is UP.  Stopping Tomcat. ${STD}"
  su - tomcat -c "$TCHOME_5/bin/shutdown.sh"
  sleep 10
  echo -e "${GRN} Backing up old $DN_FILE ${STD}"
  su - tomcat -c "mv $TCHOME_5/webapps/$DN_FILE.war $TCHOME_5/webapps/$DN_FILE.old"
  sleep 10
  echo -e "${GRN} Removing old version of $DN_FILE ${STD}"
  su - tomcat -c "rm -rf $TCHOME_5/webapps/$DN_FILE/*"
  sleep 20
  su - tomcat -c "rmdir $TCHOME_5/webapps/$DN_FILE/" 
  sleep 10
  echo -e "${GRN} Moving new version of $DN_FILE in place ${STD}"
  cp -p $DEPLOY_FILE $TCHOME_5/webapps/$DN_FILE.war
  if [ "$?" != "0" ]; then
    error_exit "${RED} Copy Failed.  Aborting! ${STD}"  
  fi
  sleep 10
  echo -e "${GRN} Starting Tomcat ${STD}"
  su - tomcat -c "$TCHOME_5/bin/startup.sh"
  sleep 10
  echo -e "${GRN} enabling Worker. ${STD}"
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP5" &> /dev/null

# Starting in deploying package to the Sixth Tomcat
echo -e "${GRN} Disabling the $DN_FILE 6 tomcat.  Waiting 180 seconds to stop. ${STD}"
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN6" &> /dev/null
  sleep 180
  echo -e "${GRN} $DN_FILE 3 Tomcat is UP.  Stopping Tomcat. ${STD}"
  su - tomcat -c "$TCHOME_6/bin/shutdown.sh"
  sleep 10
  echo -e "${GRN} Backing up old $DN_FILE ${STD}"
  su - tomcat -c "mv $TCHOME_6/webapps/$DN_FILE.war $TCHOME_6/webapps/$DN_FILE.old"
  sleep 10
  echo -e "${GRN} Removing old version of $DN_FILE ${STD}"
  su - tomcat -c "rm -rf $TCHOME_6/webapps/$DN_FILE/*"
  sleep 20
  su - tomcat -c "rmdir $TCHOME_6/webapps/$DN_FILE/" 
  sleep 10
  echo -e "${GRN} Moving new version of $DN_FILE in place ${STD}"
  cp -p $DEPLOY_FILE $TCHOME_6/webapps/$DN_FILE.war
  if [ "$?" != "0" ]; then
    error_exit "${RED} Copy Failed.  Aborting! ${STD}"
  fi
  sleep 10
  echo -e "${GRN} Starting Tomcat ${STD}"
  su - tomcat -c "$TCHOME_6/bin/startup.sh"
  sleep 10
  echo -e "${GRN} enabling Worker. ${STD}"
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP6" &> /dev/null
  
  # Starting in deploying package to the Seventh Tomcat
echo -e "${GRN} Disabling the $DN_FILE 7 tomcat.  Waiting 180 seconds to stop. ${STD}"
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN7" &> /dev/null
  sleep 180
  echo -e "${GRN} $DN_FILE 7 Tomcat is UP.  Stopping Tomcat. ${STD}"
  su - tomcat -c "$TCHOME_7/bin/shutdown.sh"
  sleep 10
  echo -e "${GRN} Backing up old $DN_FILE ${STD} ${STD}"
  su - tomcat -c "mv $TCHOME_7/webapps/$DN_FILE.war $TCHOME_7/webapps/$DN_FILE.old"
  sleep 10
  echo -e "${GRN} Removing old version of $DN_FILE ${STD}"
  su - tomcat -c "rm -rf $TCHOME_7/webapps/$DN_FILE/*"
  sleep 20
  su - tomcat -c "rmdir $TCHOME_7/webapps/$DN_FILE/" 
  sleep 10
  echo -e "${GRN} Moving new version of $DN_FILE in place ${STD}"
  cp -p $DEPLOY_FILE $TCHOME_7/webapps/$DN_FILE.war
  if [ "$?" != "0" ]; then
    error_exit "${RED} Copy Failed.  Aborting! ${STD}"
  fi
  sleep 10
  echo -e "${GRN} Starting Tomcat ${STD}"
  su - tomcat -c "$TCHOME_7/bin/startup.sh"
  sleep 10
  echo -e "${GRN} enabling Worker."
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP7" &> /dev/null
  
  # Starting in deploying package to the eighth Tomcat
echo -e "${GRN} Disabling the $DN_FILE 8 tomcat.  Waiting 180 seconds to stop. ${STD}"
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN8" &> /dev/null
  sleep 180
  echo -e "${GRN} $DN_FILE 8 Tomcat is UP.  Stopping Tomcat. ${STD}"
  su - tomcat -c "$TCHOME_8/bin/shutdown.sh"
  sleep 10
  echo -e "${GRN} Backing up old $DN_FILE ${STD}"
  su - tomcat -c "mv $TCHOME_8/webapps/$DN_FILE.war $TCHOME_8/webapps/$DN_FILE.old"
  sleep 10
  echo -e "${GRN} Removing old version of $DN_FILE ${STD}"
  su - tomcat -c "rm -rf $TCHOME_8/webapps/$DN_FILE/*"
  sleep 20
  su - tomcat -c "rmdir $TCHOME_8/webapps/$DN_FILE/" 
  sleep 10
  echo -e "${GRN} Moving new version of $DN_FILE in place ${STD}"
  cp -p $DEPLOY_FILE $TCHOME_8/webapps/$DN_FILE.war
  if [ "$?" != "0" ]; then
    error_exit "${RED} Copy Failed.  Aborting! ${STD}"
  fi
  sleep 10
  echo -e "${GRN} Starting Tomcat ${STD}"
  su - tomcat -c "$TCHOME_8/bin/startup.sh"
  sleep 10
  echo -e "${GRN} enabling Worker. ${STD}"
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP8" &> /dev/null
  
  # Starting in deploying package to the nineth Tomcat
echo -e "${GRN} Disabling the $DN_FILE 9 tomcat.  Waiting 180 seconds to stop. ${STD}"
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN9" &> /dev/null
  sleep 180
  echo -e "${GRN} $DN_FILE 9 Tomcat is UP.  Stopping Tomcat. ${STD}"
  su - tomcat -c "$TCHOME_9/bin/shutdown.sh"
  sleep 10
  echo -e "${GRN} Backing up old $DN_FILE ${STD}"
  su - tomcat -c "mv $TCHOME_9/webapps/$DN_FILE.war $TCHOME_9/webapps/$DN_FILE.old"
  sleep 10
  echo -e "${GRN} Removing old version of $DN_FILE ${STD}"
  su - tomcat -c "rm -rf $TCHOME_9/webapps/$DN_FILE/*"
  sleep 20
  su - tomcat -c "rmdir $TCHOME_9/webapps/$DN_FILE/" 
  sleep 10
  echo -e "${GRN} Moving new version of $DN_FILE in place ${STD}"
  cp -p $DEPLOY_FILE $TCHOME_9/webapps/$DN_FILE.war
  if [ "$?" != "0" ]; then
    error_exit "${RED} Copy Failed.  Aborting! ${STD}"
  fi
  sleep 10
  echo -e "${GRN} Starting Tomcat ${STD}"
  su - tomcat -c "$TCHOME_9/bin/startup.sh"
  sleep 10
  echo -e "${GRN} enabling Worker. ${STD}"
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP9" &> /dev/null
  
  # Starting in deploying package to the tenth Tomcat
echo -e "${GRN} Disabling the $DN_FILE 10 tomcat.  Waiting 180 seconds to stop. ${STD}"
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN10" &> /dev/null
  sleep 180
  echo -e "${GRN} $DN_FILE 10 Tomcat is UP.  Stopping Tomcat. ${STD}"
  su - tomcat -c "$TCHOME_10/bin/shutdown.sh"
  sleep 10
  echo -e "${GRN} Backing up old $DN_FILE ${STD}"
  su - tomcat -c "mv $TCHOME_10/webapps/$DN_FILE.war $TCHOME_10/webapps/$DN_FILE.old"
  sleep 10
  echo -e "${GRN} Removing old version of $DN_FILE ${STD}"
  su - tomcat -c "rm -rf $TCHOME_10/webapps/$DN_FILE/*"
  sleep 20
  su - tomcat -c "rmdir $TCHOME_10/webapps/$DN_FILE/" 
  sleep 10
  echo -e "${GRN} Moving new version of $DN_FILE in place ${STD}"
  cp -p $DEPLOY_FILE $TCHOME_10/webapps/$DN_FILE.war
  if [ "$?" != "0" ]; then
    error_exit "${RED} Copy Failed.  Aborting! ${STD}"
  fi
  sleep 10
  echo -e "${GRN} Starting Tomcat ${STD}"
  su - tomcat -c "$TCHOME_10/bin/startup.sh"
  sleep 10
  echo -e "${GRN} enabling Worker. ${STD}"
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP10" &> /dev/null
  
  # Starting in deploying package to the eleventh Tomcat
echo -e "${GRN} Disabling the $DN_FILE 11 tomcat.  Waiting 180 seconds to stop. ${STD}"
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN11" &> /dev/null
  sleep 180
  echo -e "${GRN} $DN_FILE 11 Tomcat is UP.  Stopping Tomcat. ${STD}"
  su - tomcat -c "$TCHOME_11/bin/shutdown.sh"
  sleep 10
  echo -e "${GRN} Backing up old $DN_FILE ${STD}"
  su - tomcat -c "mv $TCHOME_11/webapps/$DN_FILE.war $TCHOME_11/webapps/$DN_FILE.old"
  sleep 10
  echo -e "${GRN} Removing old version of $DN_FILE ${STD}"
  su - tomcat -c "rm -rf $TCHOME_11/webapps/$DN_FILE/*"
  sleep 20
  su - tomcat -c "rmdir $TCHOME_11/webapps/$DN_FILE/" 
  sleep 10
  echo -e "${GRN} Moving new version of $DN_FILE in place ${STD}"
  cp -p $DEPLOY_FILE $TCHOME_11/webapps/$DN_FILE.war
  if [ "$?" != "0" ]; then
    error_exit "${RED} Copy Failed.  Aborting! ${STD}"
  fi
  sleep 10
  echo -e "${GRN} Starting Tomcat ${STD}"
  su - tomcat -c "$TCHOME_11/bin/startup.sh"
  sleep 10
  echo -e "${GRN} enabling Worker. ${STD}"
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP11" &> /dev/null
  
  # Starting in deploying package to the twelveth Tomcat
echo -e "${GRN} Disabling the $DN_FILE 12 tomcat.  Waiting 180 seconds to stop. ${STD}"
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN12" &> /dev/null
  sleep 180
  echo -e "${GRN} $DN_FILE 3 Tomcat is UP.  Stopping Tomcat. ${STD}"
  su - tomcat -c "$TCHOME_12/bin/shutdown.sh"
  sleep 10
  echo -e "${GRN} Backing up old $DN_FILE ${STD}"
  su - tomcat -c "mv $TCHOME_12/webapps/$DN_FILE.war $TCHOME_12/webapps/$DN_FILE.old"
  sleep 10
  echo -e "${GRN} Removing old version of $DN_FILE ${STD}"
  su - tomcat -c "rm -rf $TCHOME_12/webapps/$DN_FILE/*"
  sleep 20
  su - tomcat -c "rmdir $TCHOME_12/webapps/$DN_FILE/" 
  sleep 10
  echo -e "${GRN} Moving new version of $DN_FILE in place ${STD}"
  cp -p $DEPLOY_FILE $TCHOME_12/webapps/$DN_FILE.war
  if [ "$?" != "0" ]; then
    error_exit "${RED} Copy Failed.  Aborting! ${STD}"
  fi
  sleep 10
  echo -e "${GRN} Starting Tomcat ${STD}"
  su - tomcat -c "$TCHOME_12/bin/startup.sh"
  sleep 10
  echo -e "${GRN} enabling Worker. ${STD}"
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP12" &> /dev/null
  
  # Starting in deploying package to the thirteenth Tomcat
echo -e "${GRN} Disabling the $DN_FILE 13 tomcat.  Waiting 180 seconds to stop. ${STD}"
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN13" &> /dev/null
  sleep 180
  echo -e "${GRN} $DN_FILE 13 Tomcat is UP.  Stopping Tomcat. ${STD}"
  su - tomcat -c "$TCHOME_13/bin/shutdown.sh"
  sleep 10
  echo -e "${GRN} Backing up old $DN_FILE ${STD}"
  su - tomcat -c "mv $TCHOME_13/webapps/$DN_FILE.war $TCHOME_13/webapps/$DN_FILE.old"
  sleep 10
  echo -e "${GRN} Removing old version of $DN_FILE ${STD}"
  su - tomcat -c "rm -rf $TCHOME_13/webapps/$DN_FILE/*"
  sleep 20
  su - tomcat -c "rmdir $TCHOME_13/webapps/$DN_FILE/" 
  sleep 10
  echo -e "${GRN} Moving new version of $DN_FILE in place ${STD}"
  cp -p $DEPLOY_FILE $TCHOME_13/webapps/$DN_FILE.war
  if [ "$?" != "0" ]; then
    error_exit "${RED} Copy Failed.  Aborting! ${STD}"
  fi
  sleep 10
  echo -e "${GRN} Starting Tomcat ${STD}"
  su - tomcat -c "$TCHOME_13/bin/startup.sh"
  sleep 10
  echo -e "${GRN} enabling Worker. ${STD}"
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP13" &> /dev/null
  # Starting in deploying package to the fourth Tomcat
echo -e "${GRN} Disabling the $DN_FILE 14 tomcat.  Waiting 180 seconds to stop. ${STD}"
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN14" &> /dev/null
  sleep 180
  echo -e "${GRN} $DN_FILE 3 Tomcat is UP.  Stopping Tomcat. ${STD}"
  su - tomcat -c "$TCHOME_14/bin/shutdown.sh"
  sleep 10
  echo -e "${GRN} Backing up old $DN_FILE ${STD}"
  su - tomcat -c "mv $TCHOME_14/webapps/$DN_FILE.war $TCHOME_14/webapps/$DN_FILE.old"
  sleep 10
  echo -e "${GRN} Removing old version of $DN_FILE ${STD}"
  su - tomcat -c "rm -rf $TCHOME_14/webapps/$DN_FILE/*"
  sleep 20
  su - tomcat -c "rmdir $TCHOME_14/webapps/$DN_FILE/" 
  sleep 10
  echo -e "${GRN} Moving new version of $DN_FILE in place ${STD}"
  cp -p $DEPLOY_FILE $TCHOME_14/webapps/$DN_FILE.war
  if [ "$?" != "0" ]; then
    error_exit "${RED} Copy Failed.  Aborting! ${STD}"
  fi
  sleep 10
  echo -e "${GRN} Starting Tomcat ${STD}"
  su - tomcat -c "$TCHOME_14/bin/startup.sh"
  sleep 10
  echo -e "${GRN} enabling Worker. ${STD}"
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP14" &> /dev/null
  
  # Starting in deploying package to the fourth Tomcat
echo -e "${GRN} Disabling the $DN_FILE 15 tomcat.  Waiting 180 seconds to stop. ${STD}"
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN15" &> /dev/null
  sleep 180
  echo -e "${GRN} $DN_FILE 3 Tomcat is UP.  Stopping Tomcat. ${STD}"
  su - tomcat -c "$TCHOME_15/bin/shutdown.sh"
  sleep 10
  echo -e "${GRN} Backing up old $DN_FILE ${STD}"
  su - tomcat -c "mv $TCHOME_15/webapps/$DN_FILE.war $TCHOME_15/webapps/$DN_FILE.old"
  sleep 10
  echo -e "${GRN} Removing old version of $DN_FILE ${STD}"
  su - tomcat -c "rm -rf $TCHOME_15/webapps/$DN_FILE/*"
  sleep 20
  su - tomcat -c "rmdir $TCHOME_15/webapps/$DN_FILE/" 
  sleep 10
  echo -e "${GRN} Moving new version of $DN_FILE in place ${STD}"
  cp -p $DEPLOY_FILE $TCHOME_15/webapps/$DN_FILE.war
  if [ "$?" != "0" ]; then
    error_exit "${RED} Copy Failed.  Aborting! ${STD}"
  fi
  sleep 10
  echo -e "${GRN} Starting Tomcat ${STD}"
  su - tomcat -c "$TCHOME_15/bin/startup.sh"
  sleep 10
  echo -e "${GRN} enabling Worker. ${STD}"
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP15" &> /dev/null
  
  # Starting in deploying package to the fourth Tomcat
echo -e "${GRN} Disabling the $DN_FILE 16 tomcat.  Waiting 180 seconds to stop. ${STD}"
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN16" &> /dev/null
  sleep 180
  echo -e "${GRN} $DN_FILE 3 Tomcat is UP.  Stopping Tomcat. ${STD}"
  su - tomcat -c "$TCHOME_16/bin/shutdown.sh"
  sleep 10
  echo -e "${GRN} Backing up old $DN_FILE ${STD}"
  su - tomcat -c "mv $TCHOME_16/webapps/$DN_FILE.war $TCHOME_16/webapps/$DN_FILE.old"
  sleep 10
  echo -e "${GRN} Removing old version of $DN_FILE ${STD}"
  su - tomcat -c "rm -rf $TCHOME_16/webapps/$DN_FILE/*"
  sleep 20
  su - tomcat -c "rmdir $TCHOME_16/webapps/$DN_FILE/" 
  sleep 10
  echo -e "${GRN} Moving new version of $DN_FILE in place ${STD}"
  cp -p $DEPLOY_FILE $TCHOME_16/webapps/$DN_FILE.war
  if [ "$?" != "0" ]; then
    error_exit "${RED} Copy Failed.  Aborting! ${STD}"
  fi
  sleep 10
  echo -e "${GRN} Starting Tomcat ${STD}"
  su - tomcat -c "$TCHOME_16/bin/startup.sh"
  sleep 10
  echo -e "${GRN} enabling Worker. ${STD}"
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP16" &> /dev/null
  
  # Starting in deploying package to the fourth Tomcat
echo -e "${GRN} Disabling the $DN_FILE 17 tomcat.  Waiting 180 seconds to stop. ${STD}"
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN17" &> /dev/null
  sleep 180
  echo -e "${GRN} $DN_FILE 3 Tomcat is UP.  Stopping Tomcat. ${STD}"
  su - tomcat -c "$TCHOME_17/bin/shutdown.sh"
  sleep 10
  echo -e "${GRN} Backing up old $DN_FILE ${STD}"
  su - tomcat -c "mv $TCHOME_17/webapps/$DN_FILE.war $TCHOME_17/webapps/$DN_FILE.old"
  sleep 10
  echo -e "${GRN} Removing old version of $DN_FILE ${STD}"
  su - tomcat -c "rm -rf $TCHOME_17/webapps/$DN_FILE/*"
  sleep 20
  su - tomcat -c "rmdir $TCHOME_17/webapps/$DN_FILE/" 
  sleep 10
  echo -e "${GRN} Moving new version of $DN_FILE in place ${STD}"
  cp -p $DEPLOY_FILE $TCHOME_17/webapps/$DN_FILE.war
  if [ "$?" != "0" ]; then
    error_exit "${RED} Copy Failed.  Aborting! ${STD}"
  fi
  sleep 10
  echo -e "${GRN} Starting Tomcat ${STD}"
  su - tomcat -c "$TCHOME_17/bin/startup.sh"
  sleep 10
  echo -e "${GRN} enabling Worker. ${STD}"
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP17" &> /dev/null
  
  # Starting in deploying package to the fourth Tomcat
echo -e "${GRN} Disabling the $DN_FILE 18 tomcat.  Waiting 180 seconds to stop. ${STD}"
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN18" &> /dev/null
  sleep 180
  echo -e "${GRN} $DN_FILE 3 Tomcat is UP.  Stopping Tomcat. ${STD}"
  su - tomcat -c "$TCHOME_18/bin/shutdown.sh"
  sleep 10
  echo -e "${GRN} Backing up old $DN_FILE ${STD}"
  su - tomcat -c "mv $TCHOME_18/webapps/$DN_FILE.war $TCHOME_18/webapps/$DN_FILE.old"
  sleep 10
  echo -e "${GRN} Removing old version of $DN_FILE ${STD}"
  su - tomcat -c "rm -rf $TCHOME_18/webapps/$DN_FILE/*"
  sleep 20
  su - tomcat -c "rmdir $TCHOME_18/webapps/$DN_FILE/" 
  sleep 10
  echo -e "${GRN} Moving new version of $DN_FILE in place ${STD}"
  cp -p $DEPLOY_FILE $TCHOME_18/webapps/$DN_FILE.war
  if [ "$?" != "0" ]; then
    error_exit "${RED} Copy Failed.  Aborting! ${STD}"
  fi
  sleep 10
  echo -e "${GRN} Starting Tomcat ${STD}"
  su - tomcat -c "$TCHOME_18/bin/startup.sh"
  sleep 10
  echo -e "${GRN} enabling Worker. ${STD}"
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP18" &> /dev/null
  
  # Starting in deploying package to the fourth Tomcat
echo -e "${GRN} Disabling the $DN_FILE 19 tomcat.  Waiting 180 seconds to stop. ${STD}"
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN19" &> /dev/null
  sleep 180
  echo -e "${GRN} $DN_FILE 3 Tomcat is UP.  Stopping Tomcat. ${STD}"
  su - tomcat -c "$TCHOME_19/bin/shutdown.sh"
  sleep 10
  echo -e "${GRN} Backing up old $DN_FILE ${STD}"
  su - tomcat -c "mv $TCHOME_19/webapps/$DN_FILE.war $TCHOME_19/webapps/$DN_FILE.old"
  sleep 10
  echo -e "${GRN} Removing old version of $DN_FILE ${STD}"
  su - tomcat -c "rm -rf $TCHOME_19/webapps/$DN_FILE/*"
  sleep 20
  su - tomcat -c "rmdir $TCHOME_19/webapps/$DN_FILE/" 
  sleep 10
  echo -e "${GRN} Moving new version of $DN_FILE in place ${STD}"
  cp -p $DEPLOY_FILE $TCHOME_19/webapps/$DN_FILE.war
  if [ "$?" != "0" ]; then
    error_exit "${RED} Copy Failed.  Aborting! ${STD}"
  fi
  sleep 10
  echo -e "${GRN} Starting Tomcat ${STD}"
  su - tomcat -c "$TCHOME_19/bin/startup.sh"
  sleep 10
  echo -e "${GRN} enabling Worker. ${STD}"
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP19" &> /dev/null
 
  # Starting in deploying package to the fourth Tomcat
echo -e "${GRN} Disabling the $DN_FILE 20 tomcat.  Waiting 180 seconds to stop. ${STD}"
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN20" &> /dev/null
  sleep 180
  echo -e "${GRN} $DN_FILE 3 Tomcat is UP.  Stopping Tomcat. ${STD}"
  su - tomcat -c "$TCHOME_20/bin/shutdown.sh"
  sleep 10
  echo -e "${GRN} Backing up old $DN_FILE ${STD}"
  su - tomcat -c "mv $TCHOME_20/webapps/$DN_FILE.war $TCHOME_20/webapps/$DN_FILE.old"
  sleep 10
  echo -e "${GRN} Removing old version of $DN_FILE ${STD}"
  su - tomcat -c "rm -rf $TCHOME_20/webapps/$DN_FILE/*"
  sleep 20
  su - tomcat -c "rmdir $TCHOME_20/webapps/$DN_FILE/" 
  sleep 10
  echo -e "${GRN} Moving new version of $DN_FILE in place ${STD}"
  cp -p $DEPLOY_FILE $TCHOME_20/webapps/$DN_FILE.war
  if [ "$?" != "0" ]; then
    error_exit "${RED} Copy Failed.  Aborting! ${STD}"
  fi
  sleep 10
  echo -e "${GRN} Starting Tomcat ${STD}"
  su - tomcat -c "$TCHOME_20/bin/startup.sh"
  sleep 10
  echo -e "${GRN} enabling Worker. ${STD}"
  wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP20" &> /dev/null
fi
  
 echo -e "${GRN} New $(DN_FILE)s deployed. ${STD}"
 echo -e "${GRN} Removing deployment file. ${STD}"
	rm $DEPLOY_FILE 
	rm -rf "$LOCKDIR"
trap - INT TERM EXIT

# Final Checks to make sure we get the correct number of war files after we are done. 
find $TCHOME -name $DN_FILE.war -ls 
TC_DP=$(find $TCHOME -name $(DN_FILE).war -ls |wc -l)
if (($TC_DP != 20)); then 
	echo -e "Expected 20 Hubsoap War Files, ${RED}found $TC_DP Something went wrong! ${STD}Please check the screen output!"  
	else
	echo -e "${GRN} Checking $DN_FILE war files, looking for 20 found $TC_DP.  Deployment sucessful ${STD}" 
fi
read -p  "Press any key to continue... " -n1 -s
