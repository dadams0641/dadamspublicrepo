#!/usr/bin/bash
# EDM BEAX01 $DN_FILE Deployment script
# Version 1.1.7
# 1.1.6 Standardizing variables
# 1.1.7 Fixed root checking 
# Written badly by Drew.

# Variable for which deployment files this script is going to deploy.  Change this with each script.  
# Deployment file
DN_FILE=context

# This variable needs to be changed for where you are unzipping the context files for deployment.  
# Deploy directory
DEPLOY_DIR=/deployment/$DN_FILE

# War file Backup directory
WARBACK=/home/tomcat/warback

# Date variable
DDATE=$(date +%F.%T)

# Set Lock files so this can only be run once (I think)
LOCKDIR=/var/tmp/$DN_FILE/
PIDFILE=/var/tmp/$DN_FILE/javacore.pid

# Variable for the URLS
TCSERVER=$(uname -n)

# Date variable
DDATE=$(date +%F.%T)

# Variable for the total number of Tomcats Running
TCR=20

# Variable for Tomcats running when shutting down some of them. 
TCD=10

# Variable for the Number of Tomcat files deployed
TCF=20

# Add some color to the messages. 
RED='\033[0;41;30m'
STD='\033[0;0;39m'
GRN='\033[30;48;5;82m'
BLU='\033[0;44;97m'

# Tomcat Home Directory
TCHOME=/tomcat/
TCHOME_1=/tomcat/tomcat01
TCHOME_2=/tomcat/tomcat02
TCHOME_3=/tomcat/tomcat03
TCHOME_4=/tomcat/tomcat04
TCHOME_5=/tomcat/tomcat05
TCHOME_6=/tomcat/tomcat06
TCHOME_7=/tomcat/tomcat07
TCHOME_8=/tomcat/tomcat08
TCHOME_9=/tomcat/tomcat09
TCHOME_10=/tomcat/tomcat10
TCHOME_11=/tomcat/tomcat11
TCHOME_12=/tomcat/tomcat12
TCHOME_13=/tomcat/tomcat13
TCHOME_14=/tomcat/tomcat14
TCHOME_15=/tomcat/tomcat15
TCHOME_16=/tomcat/tomcat16
TCHOME_17=/tomcat/tomcat17
TCHOME_18=/tomcat/tomcat18
TCHOME_19=/tomcat/tomcat19
TCHOME_20=/tomcat/tomcat20

# URLS for disabling the tomcat in the Apache load balancer
URLCATDN1="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat01&vwa=1"
URLCATDN2="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat02&vwa=1"
URLCATDN3="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat03&vwa=1"
URLCATDN4="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat04&vwa=1"
URLCATDN5="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat05&vwa=1"
URLCATDN6="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat06&vwa=1"
URLCATDN7="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat07&vwa=1"
URLCATDN8="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat08&vwa=1"
URLCATDN9="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat09&vwa=1"
URLCATDN10="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat10&vwa=1"
URLCATDN11="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat11&vwa=1"
URLCATDN12="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat12&vwa=1"
URLCATDN13="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat13&vwa=1"
URLCATDN14="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat14&vwa=1"
URLCATDN15="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat15&vwa=1"
URLCATDN16="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat16&vwa=1"
URLCATDN17="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat17&vwa=1"
URLCATDN18="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat18&vwa=1"
URLCATDN19="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat19&vwa=1"
URLCATDN20="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat20&vwa=1"

# URLS for enabling the tomcat in the Apache load balancer
URLCATUP1="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat01&vwa=0"
URLCATUP2="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat02&vwa=0"
URLCATUP3="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat03&vwa=0"
URLCATUP4="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat04&vwa=0"
URLCATUP5="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat05&vwa=0"
URLCATUP6="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat06&vwa=0"
URLCATUP7="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat07&vwa=0"
URLCATUP8="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat08&vwa=0"
URLCATUP9="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat09&vwa=0"
URLCATUP10="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat10&vwa=0"
URLCATUP11="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat11&vwa=0"
URLCATUP12="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat12&vwa=0"
URLCATUP13="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat13&vwa=0"
URLCATUP14="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat14&vwa=0"
URLCATUP15="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat15&vwa=0"
URLCATUP16="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat16&vwa=0"
URLCATUP17="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat17&vwa=0"
URLCATUP18="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat18&vwa=0"
URLCATUP19="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat19&vwa=0"
URLCATUP20="http://$TCSERVER:8081/jkmanager/?cmd=update&from=list&w=hubbalancer&sw=tomcat20&vwa=0"


#Check the exit status
error_exit()
{
        echo -e "$1" 1>&2
        exit 1
}

# Check the number of running Tomcats
TCRUN()
{
		ps -ef |grep tomcat |grep conf |wc -l
}

if [ $(id -u) != "0" ]; then
    error_exit "You are not Root.  Please run this script with sudo" 
fi

# Creating directories needed if they are not there. 
# This is the PID directory
if [ -d $LOCKDIR ]
then 
    echo -e "${BLU} Java Deployment PID Directory exists ${STD}"
	else 
	mkdir -p -m 777 $LOCKDIR
	chown tomcat:tomcat $LOCKDIR
	echo -e "${GRN} Java Deployment PID Directory created ${STD}"
fi
# Deployment directory
if [ -d $DEPLOY_DIR ]
then 
    echo -e "${BLU} Deployment directory exists ${STD}"
	else 
	mkdir -p -m 777 $DEPLOY_DIR
	echo -e "${GRN} $DN_FILE Deployment directory created ${STD}"
fi

# Lock file so that only one copy can be run. 
# remove lock file during exit
trap 'rm -f $PIDFILE; exit' INT TERM EXIT
 
if [ -f $PIDFILE ] ; then                      
    # lock is already held
    echo >&2 -e "${RED} lock not acquired, is there another copy running? Giving up: $PIDFILE ${STD}"
    exit 1
else                      
    # nobody owns the lock
    echo $$ > "$PIDFILE"         # create the lock file
    
    # ... commands executed under lock / single instance ...
    echo -e "${BLU} lock acquired: $PIDFILE ${STD}"
fi

# Disabling Tomcats in the Apache Load Balancer
echo -e "${GRN} Disabling the Odd Tomcats.  Waiting 180 seconds to stop. ${STD}"
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN1" &> /dev/null
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN3" &> /dev/null
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN5" &> /dev/null
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN7" &> /dev/null
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN9" &> /dev/null
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN11" &> /dev/null
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN13" &> /dev/null
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN15" &> /dev/null
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN17" &> /dev/null
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN19" &> /dev/null
sleep 180

# Shutting down the Tomcats
echo -e "${GRN} Stopping Odd Tomcats. ${STD}"
  su - tomcat -c "$TCHOME_1/bin/shutdown.sh"
  su - tomcat -c "$TCHOME_3/bin/shutdown.sh"
  su - tomcat -c "$TCHOME_5/bin/shutdown.sh"  
  su - tomcat -c "$TCHOME_7/bin/shutdown.sh"
  su - tomcat -c "$TCHOME_9/bin/shutdown.sh"
  su - tomcat -c "$TCHOME_11/bin/shutdown.sh"
  su - tomcat -c "$TCHOME_13/bin/shutdown.sh"
  su - tomcat -c "$TCHOME_15/bin/shutdown.sh"
  su - tomcat -c "$TCHOME_17/bin/shutdown.sh"
  su - tomcat -c "$TCHOME_19/bin/shutdown.sh"
sleep 30

# Checks to make sure we have the right number of tomcats running. 
TC_DP=$( TCRUN )
if (($TC_DP != $TCD)); then 
	echo -e "Expected $TCD Tocmats, ${RED}found $TC_DP Something went wrong! ${STD}Please check the screen output!"
    error_exit "Too many Tomcats!  Check Screen output."	
	else
	echo -e "${GRN} Checking Tomcats, looking for $TCD found $TC_DP.  Shutdown sucessful ${STD}" 
fi

# Backup the current file
mv $TCHOME_1/conf/$DN_FILE.xml $TCHOME_1/conf/$DN_FILE.$DDATE

# Checks to make sure we have the correct backup file, and no context.xml. 
find $TCHOME_1/* -name $DN_FILE.$DDATE -ls 
TC_DP1=$(find $TCHOME_1/conf/* -name $DN_FILE.$DDATE -ls |wc -l)
if (($TC_DP1 != 1)); then 
	echo -e "Expected 1 $DN_FILE backup Files, ${RED}found $TC_DP1 Something went wrong! ${STD}Please check the screen output!"  
	error_exit "No backup file!"
	else
	echo -e "${GRN} Checking $DN_FILE backup files, looking for 1 found $TC_DP1.  Backup sucessful ${STD}" 
fi

find $TCHOME_1/* -name $DN_FILE.$DDATE -ls 
TC_XML1=$(find $TCHOME_1/conf/* -name $DN_FILE.xml -ls |wc -l)
if (($TC_XML1 != 0)); then 
	echo -e "Expected 0 $DN_FILE XML Files, ${RED}found $TC_XML1 Something went wrong! ${STD}Please check the screen output!"  
	error_exit "Found XML file!"
	else
	echo -e "${GRN} Checking $DN_FILE xml files, looking for 0 found $TC_XML1.  Backup sucessful ${STD}" 
fi

# Copy the new file in place
su - tomcat -c "cp $DEPLOY_DIR/tomcat01/conf/$DN_FILE.xml $TCHOME_1/conf/$DN_FILE.xml"

# Checking to make sure that we have our context.xml now
TC_XML1=$(find $TCHOME_1/conf/* -name $DN_FILE.xml -ls |wc -l)
if (($TC_XML1 != 1)); then 
	echo -e "Expected 1 $DN_FILE XML Files, ${RED}found $TC_XML1 Something went wrong! ${STD}Please check the screen output!"  
	error_exit "Found XML file!"
	else
	echo -e "${GRN} Checking $DN_FILE xml files, looking for 1 found $TC_XML1.  Deployment sucessful ${STD}" 
fi

# Backup the current file
mv $TCHOME_3/conf/$DN_FILE.xml $TCHOME_3/conf/$DN_FILE.$DDATE

# Checks to make sure we have the correct backup file, and no context.xml. 
find $TCHOME_3/* -name $DN_FILE.$DDATE -ls 
TC_DP3=$(find $TCHOME_3/conf/* -name $DN_FILE.$DDATE -ls |wc -l)
if (($TC_DP3 != 1)); then 
	echo -e "Expected 1 $DN_FILE backup Files, ${RED}found $TC_DP3 Something went wrong! ${STD}Please check the screen output!"  
	error_exit "No backup file!"
	else
	echo -e "${GRN} Checking $DN_FILE backup files, looking for 1 found $TC_DP3.  Backup sucessful ${STD}" 
fi

find $TCHOME_3/* -name $DN_FILE.$DDATE -ls 
TC_XML3=$(find $TCHOME_3/conf/* -name $DN_FILE.xml -ls |wc -l)
if (($TC_XML3 != 0)); then 
	echo -e "Expected 0 $DN_FILE XML Files, ${RED}found $TC_XML3 Something went wrong! ${STD}Please check the screen output!"  
	error_exit "Found XML file!"
	else
	echo -e "${GRN} Checking $DN_FILE xml files, looking for 0 found $TC_XML3.  Backup sucessful ${STD}" 
fi

# Copy the new file in place
su - tomcat -c "cp $DEPLOY_DIR/tomcat03/conf/$DN_FILE.xml $TCHOME_3/conf/$DN_FILE.xml"

# Checking to make sure that we have our context.xml now
TC_XML3=$(find $TCHOME_3/conf/* -name $DN_FILE.xml -ls |wc -l)
if (($TC_XML3 != 1)); then 
	echo -e "Expected 1 $DN_FILE XML Files, ${RED}found $TC_XML3 Something went wrong! ${STD}Please check the screen output!"  
	error_exit "Found XML file!"
	else
	echo -e "${GRN} Checking $DN_FILE xml files, looking for 1 found $TC_XML3.  Deployment sucessful ${STD}" 
fi

# Backup the current file
mv $TCHOME_5/conf/$DN_FILE.xml $TCHOME_5/conf/$DN_FILE.$DDATE

# Checks to make sure we have the correct backup file, and no context.xml. 
find $TCHOME_5/* -name $DN_FILE.$DDATE -ls 
TC_DP5=$(find $TCHOME_5/conf/* -name $DN_FILE.$DDATE -ls |wc -l)
if (($TC_DP5 != 1)); then 
	echo -e "Expected 1 $DN_FILE backup Files, ${RED}found $TC_DP5 Something went wrong! ${STD}Please check the screen output!"  
	error_exit "No backup file!"
	else
	echo -e "${GRN} Checking $DN_FILE backup files, looking for 1 found $TC_DP5.  Backup sucessful ${STD}" 
fi

find $TCHOME_5/* -name $DN_FILE.$DDATE -ls 
TC_XML5=$(find $TCHOME_5/conf/* -name $DN_FILE.xml -ls |wc -l)
if (($TC_XML5 != 0)); then 
	echo -e "Expected 0 $DN_FILE XML Files, ${RED}found $TC_XML5 Something went wrong! ${STD}Please check the screen output!"  
	error_exit "Found XML file!"
	else
	echo -e "${GRN} Checking $DN_FILE xml files, looking for 0 found $TC_XML5.  Backup sucessful ${STD}" 
fi

# Copy the new file in place
su - tomcat -c "cp $DEPLOY_DIR/tomcat05/conf/$DN_FILE.xml $TCHOME_5/conf/$DN_FILE.xml"

# Checking to make sure that we have our context.xml now
TC_XML5=$(find $TCHOME_5/conf/* -name $DN_FILE.xml -ls |wc -l)
if (($TC_XML5 != 1)); then 
	echo -e "Expected 1 $DN_FILE XML Files, ${RED}found $TC_XML5 Something went wrong! ${STD}Please check the screen output!"  
	error_exit "Found XML file!"
	else
	echo -e "${GRN} Checking $DN_FILE xml files, looking for 1 found $TC_XML5.  Deployment sucessful ${STD}" 
fi

# Backup the current file
mv $TCHOME_7/conf/$DN_FILE.xml $TCHOME_7/conf/$DN_FILE.$DDATE

# Checks to make sure we have the correct backup file, and no context.xml. 
find $TCHOME_7/* -name $DN_FILE.$DDATE -ls 
TC_DP7=$(find $TCHOME_7/conf/* -name $DN_FILE.$DDATE -ls |wc -l)
if (($TC_DP7 != 1)); then 
	echo -e "Expected 1 $DN_FILE backup Files, ${RED}found $TC_DP7 Something went wrong! ${STD}Please check the screen output!"  
	error_exit "No backup file!"
	else
	echo -e "${GRN} Checking $DN_FILE backup files, looking for 1 found $TC_DP7.  Backup sucessful ${STD}" 
fi

find $TCHOME_7/* -name $DN_FILE.$DDATE -ls 
TC_XML7=$(find $TCHOME_7/conf/* -name $DN_FILE.xml -ls |wc -l)
if (($TC_XML7 != 0)); then 
	echo -e "Expected 0 $DN_FILE XML Files, ${RED}found $TC_XML7 Something went wrong! ${STD}Please check the screen output!"  
	error_exit "Found XML file!"
	else
	echo -e "${GRN} Checking $DN_FILE xml files, looking for 0 found $TC_XML7.  Backup sucessful ${STD}" 
fi

# Copy the new file in place
su - tomcat -c "cp $DEPLOY_DIR/tomcat07/conf/$DN_FILE.xml $TCHOME_7/conf/$DN_FILE.xml"

# Checking to make sure that we have our context.xml now
TC_XML7=$(find $TCHOME_7/conf/* -name $DN_FILE.xml -ls |wc -l)
if (($TC_XML7 != 1)); then 
	echo -e "Expected 1 $DN_FILE XML Files, ${RED}found $TC_XML7 Something went wrong! ${STD}Please check the screen output!"  
	error_exit "Found XML file!"
	else
	echo -e "${GRN} Checking $DN_FILE xml files, looking for 1 found $TC_XML7.  Deployment sucessful ${STD}" 
fi

# Backup the current file
mv $TCHOME_9/conf/$DN_FILE.xml $TCHOME_9/conf/$DN_FILE.$DDATE

# Checks to make sure we have the correct backup file, and no context.xml. 
find $TCHOME_9/* -name $DN_FILE.$DDATE -ls 
TC_DP9=$(find $TCHOME_9/conf/* -name $DN_FILE.$DDATE -ls |wc -l)
if (($TC_DP9 != 1)); then 
	echo -e "Expected 1 $DN_FILE backup Files, ${RED}found $TC_DP9 Something went wrong! ${STD}Please check the screen output!"  
	error_exit "No backup file!"
	else
	echo -e "${GRN} Checking $DN_FILE backup files, looking for 1 found $TC_DP9.  Backup sucessful ${STD}" 
fi

find $TCHOME_9/* -name $DN_FILE.$DDATE -ls 
TC_XML9=$(find $TCHOME_9/conf/* -name $DN_FILE.xml -ls |wc -l)
if (($TC_XML9 != 0)); then 
	echo -e "Expected 0 $DN_FILE XML Files, ${RED}found $TC_XML9 Something went wrong! ${STD}Please check the screen output!"  
	error_exit "Found XML file!"
	else
	echo -e "${GRN} Checking $DN_FILE xml files, looking for 0 found $TC_XML9.  Backup sucessful ${STD}" 
fi

# Copy the new file in place
su - tomcat -c "cp $DEPLOY_DIR/tomcat09/conf/$DN_FILE.xml $TCHOME_9/conf/$DN_FILE.xml"

# Checking to make sure that we have our context.xml now
TC_XML9=$(find $TCHOME_9/conf/* -name $DN_FILE.xml -ls |wc -l)
if (($TC_XML9 != 1)); then 
	echo -e "Expected 1 $DN_FILE XML Files, ${RED}found $TC_XML9 Something went wrong! ${STD}Please check the screen output!"  
	error_exit "Found XML file!"
	else
	echo -e "${GRN} Checking $DN_FILE xml files, looking for 1 found $TC_XML9.  Deployment sucessful ${STD}" 
fi

# Backup the current file
mv $TCHOME_11/conf/$DN_FILE.xml $TCHOME_11/conf/$DN_FILE.$DDATE

# Checks to make sure we have the correct backup file, and no context.xml. 
find $TCHOME_11/* -name $DN_FILE.$DDATE -ls 
TC_DP11=$(find $TCHOME_11/conf/* -name $DN_FILE.$DDATE -ls |wc -l)
if (($TC_DP11 != 1)); then 
	echo -e "Expected 1 $DN_FILE backup Files, ${RED}found $TC_DP11 Something went wrong! ${STD}Please check the screen output!"  
	error_exit "No backup file!"
	else
	echo -e "${GRN} Checking $DN_FILE backup files, looking for 1 found $TC_DP11.  Backup sucessful ${STD}" 
fi

find $TCHOME_11/* -name $DN_FILE.$DDATE -ls 
TC_XML11=$(find $TCHOME_11/conf/* -name $DN_FILE.xml -ls |wc -l)
if (($TC_XML11 != 0)); then 
	echo -e "Expected 0 $DN_FILE XML Files, ${RED}found $TC_XML11 Something went wrong! ${STD}Please check the screen output!"  
	error_exit "Found XML file!"
	else
	echo -e "${GRN} Checking $DN_FILE xml files, looking for 0 found $TC_XML11.  Backup sucessful ${STD}" 
fi

# Copy the new file in place
su - tomcat -c "cp $DEPLOY_DIR/tomcat11/conf/$DN_FILE.xml $TCHOME_11/conf/$DN_FILE.xml"

# Checking to make sure that we have our context.xml now
TC_XML11=$(find $TCHOME_11/conf/* -name $DN_FILE.xml -ls |wc -l)
if (($TC_XML11 != 1)); then 
	echo -e "Expected 1 $DN_FILE XML Files, ${RED}found $TC_XML11 Something went wrong! ${STD}Please check the screen output!"  
	error_exit "Found XML file!"
	else
	echo -e "${GRN} Checking $DN_FILE xml files, looking for 1 found $TC_XML11.  Deployment sucessful ${STD}" 
fi

# Backup the current file
mv $TCHOME_13/conf/$DN_FILE.xml $TCHOME_13/conf/$DN_FILE.$DDATE

# Checks to make sure we have the correct backup file, and no context.xml. 
find $TCHOME_13/* -name $DN_FILE.$DDATE -ls 
TC_DP13=$(find $TCHOME_13/conf/* -name $DN_FILE.$DDATE -ls |wc -l)
if (($TC_DP13 != 1)); then 
	echo -e "Expected 1 $DN_FILE backup Files, ${RED}found $TC_DP13 Something went wrong! ${STD}Please check the screen output!"  
	error_exit "No backup file!"
	else
	echo -e "${GRN} Checking $DN_FILE backup files, looking for 1 found $TC_DP13.  Backup sucessful ${STD}" 
fi

find $TCHOME_13/* -name $DN_FILE.$DDATE -ls 
TC_XML13=$(find $TCHOME_13/conf/* -name $DN_FILE.xml -ls |wc -l)
if (($TC_XML13 != 0)); then 
	echo -e "Expected 0 $DN_FILE XML Files, ${RED}found $TC_XML13 Something went wrong! ${STD}Please check the screen output!"  
	error_exit "Found XML file!"
	else
	echo -e "${GRN} Checking $DN_FILE xml files, looking for 0 found $TC_XML13.  Backup sucessful ${STD}" 
fi

# Copy the new file in place
su - tomcat -c "cp $DEPLOY_DIR/tomcat13/conf/$DN_FILE.xml $TCHOME_13/conf/$DN_FILE.xml"

# Checking to make sure that we have our context.xml now
TC_XML13=$(find $TCHOME_13/conf/* -name $DN_FILE.xml -ls |wc -l)
if (($TC_XML13 != 1)); then 
	echo -e "Expected 1 $DN_FILE XML Files, ${RED}found $TC_XML13 Something went wrong! ${STD}Please check the screen output!"  
	error_exit "Found XML file!"
	else
	echo -e "${GRN} Checking $DN_FILE xml files, looking for 1 found $TC_XML13.  Deployment sucessful ${STD}" 
fi

# Backup the current file
mv $TCHOME_15/conf/$DN_FILE.xml $TCHOME_15/conf/$DN_FILE.$DDATE

# Checks to make sure we have the correct backup file, and no context.xml. 
find $TCHOME_15/* -name $DN_FILE.$DDATE -ls 
TC_DP15=$(find $TCHOME_15/conf/* -name $DN_FILE.$DDATE -ls |wc -l)
if (($TC_DP15 != 1)); then 
	echo -e "Expected 1 $DN_FILE backup Files, ${RED}found $TC_DP15 Something went wrong! ${STD}Please check the screen output!"  
	error_exit "No backup file!"
	else
	echo -e "${GRN} Checking $DN_FILE backup files, looking for 1 found $TC_DP15.  Backup sucessful ${STD}" 
fi

find $TCHOME_15/* -name $DN_FILE.$DDATE -ls 
TC_XML15=$(find $TCHOME_15/conf/* -name $DN_FILE.xml -ls |wc -l)
if (($TC_XML15 != 0)); then 
	echo -e "Expected 0 $DN_FILE XML Files, ${RED}found $TC_XML15 Something went wrong! ${STD}Please check the screen output!"  
	error_exit "Found XML file!"
	else
	echo -e "${GRN} Checking $DN_FILE xml files, looking for 0 found $TC_XML15.  Backup sucessful ${STD}" 
fi

# Copy the new file in place
su - tomcat -c "cp $DEPLOY_DIR/tomcat15/conf/$DN_FILE.xml $TCHOME_15/conf/$DN_FILE.xml"

# Checking to make sure that we have our context.xml now
TC_XML15=$(find $TCHOME_15/conf/* -name $DN_FILE.xml -ls |wc -l)
if (($TC_XML15 != 1)); then 
	echo -e "Expected 1 $DN_FILE XML Files, ${RED}found $TC_XML15 Something went wrong! ${STD}Please check the screen output!"  
	error_exit "Found XML file!"
	else
	echo -e "${GRN} Checking $DN_FILE xml files, looking for 1 found $TC_XML15.  Deployment sucessful ${STD}" 
fi

# Backup the current file
mv $TCHOME_17/conf/$DN_FILE.xml $TCHOME_17/conf/$DN_FILE.$DDATE

# Checks to make sure we have the correct backup file, and no context.xml. 
find $TCHOME_17/* -name $DN_FILE.$DDATE -ls 
TC_DP17=$(find $TCHOME_17/conf/* -name $DN_FILE.$DDATE -ls |wc -l)
if (($TC_DP17 != 1)); then 
	echo -e "Expected 1 $DN_FILE backup Files, ${RED}found $TC_DP17 Something went wrong! ${STD}Please check the screen output!"  
	error_exit "No backup file!"
	else
	echo -e "${GRN} Checking $DN_FILE backup files, looking for 1 found $TC_DP17.  Backup sucessful ${STD}" 
fi

find $TCHOME_17/* -name $DN_FILE.$DDATE -ls 
TC_XML17=$(find $TCHOME_17/conf/* -name $DN_FILE.xml -ls |wc -l)
if (($TC_XML17 != 0)); then 
	echo -e "Expected 0 $DN_FILE XML Files, ${RED}found $TC_XML17 Something went wrong! ${STD}Please check the screen output!"  
	error_exit "Found XML file!"
	else
	echo -e "${GRN} Checking $DN_FILE xml files, looking for 0 found $TC_XML17.  Backup sucessful ${STD}" 
fi

# Copy the new file in place
su - tomcat -c "cp $DEPLOY_DIR/tomcat17/conf/$DN_FILE.xml $TCHOME_17/conf/$DN_FILE.xml"

# Checking to make sure that we have our context.xml now
TC_XML17=$(find $TCHOME_17/conf/* -name $DN_FILE.xml -ls |wc -l)
if (($TC_XML17 != 1)); then 
	echo -e "Expected 1 $DN_FILE XML Files, ${RED}found $TC_XML17 Something went wrong! ${STD}Please check the screen output!"  
	error_exit "Found XML file!"
	else
	echo -e "${GRN} Checking $DN_FILE xml files, looking for 1 found $TC_XML17.  Deployment sucessful ${STD}" 
fi

# Backup the current file
mv $TCHOME_19/conf/$DN_FILE.xml $TCHOME_19/conf/$DN_FILE.$DDATE

# Checks to make sure we have the correct backup file, and no context.xml. 
find $TCHOME_19/* -name $DN_FILE.$DDATE -ls 
TC_DP19=$(find $TCHOME_19/conf/* -name $DN_FILE.$DDATE -ls |wc -l)
if (($TC_DP19 != 1)); then 
	echo -e "Expected 1 $DN_FILE backup Files, ${RED}found $TC_DP19 Something went wrong! ${STD}Please check the screen output!"  
	error_exit "No backup file!"
	else
	echo -e "${GRN} Checking $DN_FILE backup files, looking for 1 found $TC_DP19.  Backup sucessful ${STD}" 
fi

find $TCHOME_19/* -name $DN_FILE.$DDATE -ls 
TC_XML19=$(find $TCHOME_19/conf/* -name $DN_FILE.xml -ls |wc -l)
if (($TC_XML19 != 0)); then 
	echo -e "Expected 0 $DN_FILE XML Files, ${RED}found $TC_XML19 Something went wrong! ${STD}Please check the screen output!"  
	error_exit "Found XML file!"
	else
	echo -e "${GRN} Checking $DN_FILE xml files, looking for 0 found $TC_XML19. Backup sucessful ${STD}" 
fi

# Copy the new file in place
su - tomcat -c "cp $DEPLOY_DIR/tomcat19/conf/$DN_FILE.xml $TCHOME_19/conf/$DN_FILE.xml"

# Checking to make sure that we have our context.xml now
TC_XML19=$(find $TCHOME_19/conf/* -name $DN_FILE.xml -ls |wc -l)
if (($TC_XML19 != 1)); then 
	echo -e "Expected 1 $DN_FILE XML Files, ${RED}found $TC_XML19 Something went wrong! ${STD}Please check the screen output!"  
	error_exit "Found XML file!"
	else
	echo -e "${GRN} Checking $DN_FILE xml files, looking for 1 found $TC_XML19. Deployment sucessful ${STD}" 
fi

# bring Up the Tomcats 
echo -e "${GRN} Starting Odd Tomcats. ${STD}"
su tomcat -c "/tomcat/tomcat01/bin/startup.sh"
su tomcat -c "/tomcat/tomcat03/bin/startup.sh"
su tomcat -c "/tomcat/tomcat05/bin/startup.sh"
su tomcat -c "/tomcat/tomcat07/bin/startup.sh"
su tomcat -c "/tomcat/tomcat09/bin/startup.sh"
su tomcat -c "/tomcat/tomcat11/bin/startup.sh"
su tomcat -c "/tomcat/tomcat13/bin/startup.sh"
su tomcat -c "/tomcat/tomcat15/bin/startup.sh"
su tomcat -c "/tomcat/tomcat17/bin/startup.sh"
su tomcat -c "/tomcat/tomcat19/bin/startup.sh"
sleep 60

echo -e "${GRN} Enabling the Odd Tomcats.  Waiting 60 seconds to start. ${STD}"
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP1" &> /dev/null
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP3" &> /dev/null
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP5" &> /dev/null
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP7" &> /dev/null
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP9" &> /dev/null
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP11" &> /dev/null
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP13" &> /dev/null
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP15" &> /dev/null
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP17" &> /dev/null
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP19" &> /dev/null
sleep 60

# Checks to make sure we have the right number of tomcats running. 
TC_DP=$( TCRUN )
if (($TC_DP != $TCR)); then 
	echo -e "Expected $TCR Tocmats, ${RED}found $TC_DP Something went wrong! ${STD}Please check the screen output!"
    error_exit "Too many Tomcats!  Check Screen output."	
	else
	echo -e "${GRN} Checking Tomcats, looking for $TCR found $TC_DP.  Shutdown sucessful ${STD}" 
fi

# Disabling Tomcats in the Apache Load Balancer
echo -e "${GRN} Disabling the Even Tomcats.  Waiting 180 seconds to stop. ${STD}"
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN2" &> /dev/null
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN4" &> /dev/null
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN6" &> /dev/null
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN8" &> /dev/null
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN10" &> /dev/null
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN12" &> /dev/null
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN14" &> /dev/null
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN16" &> /dev/null
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN18" &> /dev/null
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATDN20" &> /dev/null
sleep 180

# Shutting down the Tomcats
echo -e "${GRN} Stopping Even Tomcats. ${STD}"
  su - tomcat -c "$TCHOME_2/bin/shutdown.sh"
  su - tomcat -c "$TCHOME_4/bin/shutdown.sh"
  su - tomcat -c "$TCHOME_6/bin/shutdown.sh"  
  su - tomcat -c "$TCHOME_8/bin/shutdown.sh"
  su - tomcat -c "$TCHOME_10/bin/shutdown.sh"
  su - tomcat -c "$TCHOME_12/bin/shutdown.sh"
  su - tomcat -c "$TCHOME_14/bin/shutdown.sh"
  su - tomcat -c "$TCHOME_16/bin/shutdown.sh"
  su - tomcat -c "$TCHOME_18/bin/shutdown.sh"
  su - tomcat -c "$TCHOME_20/bin/shutdown.sh"
sleep 30

# Checks to make sure we have the right number of tomcats running. 
TC_DP=$( TCRUN )
if (($TC_DP != $TCD)); then 
	echo -e "Expected $TCD Tocmats, ${RED}found $TC_DP Something went wrong! ${STD}Please check the screen output!"
    error_exit "Too many Tomcats!  Check Screen output."	
	else
	echo -e "${GRN} Checking Tomcats, looking for $TCD found $TC_DP.  Shutdown sucessful ${STD}" 
fi

# Backup the current file
mv $TCHOME_2/conf/$DN_FILE.xml $TCHOME_2/conf/$DN_FILE.$DDATE

# Checks to make sure we have the correct backup file, and no context.xml. 
find $TCHOME_2/* -name $DN_FILE.$DDATE -ls 
TC_DP2=$(find $TCHOME_2/conf/* -name $DN_FILE.$DDATE -ls |wc -l)
if (($TC_DP2 != 1)); then 
	echo -e "Expected 1 $DN_FILE backup Files, ${RED}found $TC_DP2 Something went wrong! ${STD}Please check the screen output!"  
	error_exit "No backup file!"
	else
	echo -e "${GRN} Checking $DN_FILE backup files, looking for 1 found $TC_DP2.  Backup sucessful ${STD}" 
fi

find $TCHOME_2/* -name $DN_FILE.$DDATE -ls 
TC_XML2=$(find $TCHOME_2/conf/* -name $DN_FILE.xml -ls |wc -l)
if (($TC_XML2 != 0)); then 
	echo -e "Expected 0 $DN_FILE XML Files, ${RED}found $TC_XML2 Something went wrong! ${STD}Please check the screen output!"  
	error_exit "Found XML file!"
	else
	echo -e "${GRN} Checking $DN_FILE xml files, looking for 0 found $TC_XML2.  Backup sucessful ${STD}" 
fi

# Copy the new file in place
su - tomcat -c "cp $DEPLOY_DIR/tomcat02/conf/$DN_FILE.xml $TCHOME_2/conf/$DN_FILE.xml"

# Checking to make sure that we have our context.xml now
TC_XML2=$(find $TCHOME_2/conf/* -name $DN_FILE.xml -ls |wc -l)
if (($TC_XML2 != 1)); then 
	echo -e "Expected 1 $DN_FILE XML Files, ${RED}found $TC_XML2 Something went wrong! ${STD}Please check the screen output!"  
	error_exit "Found XML file!"
	else
	echo -e "${GRN} Checking $DN_FILE xml files, looking for 1 found $TC_XML2.  Deployment sucessful ${STD}" 
fi

# Backup the current file
mv $TCHOME_4/conf/$DN_FILE.xml $TCHOME_4/conf/$DN_FILE.$DDATE

# Checks to make sure we have the correct backup file, and no context.xml. 
find $TCHOME_4/* -name $DN_FILE.$DDATE -ls 
TC_DP4=$(find $TCHOME_4/conf/* -name $DN_FILE.$DDATE -ls |wc -l)
if (($TC_DP4 != 1)); then 
	echo -e "Expected 1 $DN_FILE backup Files, ${RED}found $TC_DP4 Something went wrong! ${STD}Please check the screen output!"  
	error_exit "No backup file!"
	else
	echo -e "${GRN} Checking $DN_FILE backup files, looking for 1 found $TC_DP4.  Backup sucessful ${STD}" 
fi

find $TCHOME_4/conf/* -name $DN_FILE.$DDATE -ls 
TC_XML4=$(find $TCHOME_4/conf/* -name $DN_FILE.xml -ls |wc -l)
if (($TC_XML4 != 0)); then 
	echo -e "Expected 0 $DN_FILE XML Files, ${RED}found $TC_XML4 Something went wrong! ${STD}Please check the screen output!"  
	error_exit "Found XML file!"
	else
	echo -e "${GRN} Checking $DN_FILE xml files, looking for 0 found $TC_XML4.  Backup sucessful ${STD}" 
fi

# Copy the new file in place
su - tomcat -c "cp $DEPLOY_DIR/tomcat04/conf/$DN_FILE.xml $TCHOME_4/conf/$DN_FILE.xml"

# Checking to make sure that we have our context.xml now
TC_XML4=$(find $TCHOME_4/conf/* -name $DN_FILE.xml -ls |wc -l)
if (($TC_XML4 != 1)); then 
	echo -e "Expected 1 $DN_FILE XML Files, ${RED}found $TC_XML4 Something went wrong! ${STD}Please check the screen output!"  
	error_exit "Found XML file!"
	else
	echo -e "${GRN} Checking $DN_FILE xml files, looking for 1 found $TC_XML4.  Deployment sucessful ${STD}" 
fi

# Backup the current file
mv $TCHOME_6/conf/$DN_FILE.xml $TCHOME_6/conf/$DN_FILE.$DDATE

# Checks to make sure we have the correct backup file, and no context.xml. 
find $TCHOME_6/* -name $DN_FILE.$DDATE -ls 
TC_DP6=$(find $TCHOME_6/conf/* -name $DN_FILE.$DDATE -ls |wc -l)
if (($TC_DP6 != 1)); then 
	echo -e "Expected 1 $DN_FILE backup Files, ${RED}found $TC_DP6 Something went wrong! ${STD}Please check the screen output!"  
	error_exit "No backup file!"
	else
	echo -e "${GRN} Checking $DN_FILE backup files, looking for 1 found $TC_DP6.  Backup sucessful ${STD}" 
fi

find $TCHOME_6/conf/* -name $DN_FILE.$DDATE -ls 
TC_XML6=$(find $TCHOME_6/conf/* -name $DN_FILE.xml -ls |wc -l)
if (($TC_XML6 != 0)); then 
	echo -e "Expected 0 $DN_FILE XML Files, ${RED}found $TC_XML6 Something went wrong! ${STD}Please check the screen output!"  
	error_exit "Found XML file!"
	else
	echo -e "${GRN} Checking $DN_FILE xml files, looking for 0 found $TC_XML6.  Backup sucessful ${STD}" 
fi

# Copy the new file in place
su - tomcat -c "cp $DEPLOY_DIR/tomcat06/conf/$DN_FILE.xml $TCHOME_6/conf/$DN_FILE.xml"

# Checking to make sure that we have our context.xml now
TC_XML6=$(find $TCHOME_6/conf/* -name $DN_FILE.xml -ls |wc -l)
if (($TC_XML6 != 1)); then 
	echo -e "Expected 1 $DN_FILE XML Files, ${RED}found $TC_XML6 Something went wrong! ${STD}Please check the screen output!"  
	error_exit "Found XML file!"
	else
	echo -e "${GRN} Checking $DN_FILE xml files, looking for 1 found $TC_XML6.  Deployment sucessful ${STD}" 
fi

# Backup the current file
mv $TCHOME_8/conf/$DN_FILE.xml $TCHOME_8/conf/$DN_FILE.$DDATE

# Checks to make sure we have the correct backup file, and no context.xml. 
find $TCHOME_8/* -name $DN_FILE.$DDATE -ls 
TC_DP8=$(find $TCHOME_8/conf/* -name $DN_FILE.$DDATE -ls |wc -l)
if (($TC_DP8 != 1)); then 
	echo -e "Expected 1 $DN_FILE backup Files, ${RED}found $TC_DP8 Something went wrong! ${STD}Please check the screen output!"  
	error_exit "No backup file!"
	else
	echo -e "${GRN} Checking $DN_FILE backup files, looking for 1 found $TC_DP8.  Backup sucessful ${STD}" 
fi

find $TCHOME_8/conf/* -name $DN_FILE.$DDATE -ls 
TC_XML8=$(find $TCHOME_8/conf/* -name $DN_FILE.xml -ls |wc -l)
if (($TC_XML8 != 0)); then 
	echo -e "Expected 0 $DN_FILE XML Files, ${RED}found $TC_XML8 Something went wrong! ${STD}Please check the screen output!"  
	error_exit "Found XML file!"
	else
	echo -e "${GRN} Checking $DN_FILE xml files, looking for 0 found $TC_XML8.  Backup sucessful ${STD}" 
fi

# Copy the new file in place
su - tomcat -c "cp $DEPLOY_DIR/tomcat08/conf/$DN_FILE.xml $TCHOME_8/conf/$DN_FILE.xml"

# Checking to make sure that we have our context.xml now
TC_XML8=$(find $TCHOME_8/conf/* -name $DN_FILE.xml -ls |wc -l)
if (($TC_XML8 != 1)); then 
	echo -e "Expected 1 $DN_FILE XML Files, ${RED}found $TC_XML8 Something went wrong! ${STD}Please check the screen output!"  
	error_exit "Found XML file!"
	else
	echo -e "${GRN} Checking $DN_FILE xml files, looking for 1 found $TC_XML8.  Deployment sucessful ${STD}" 
fi

# Backup the current file
mv $TCHOME_10/conf/$DN_FILE.xml $TCHOME_10/conf/$DN_FILE.$DDATE

# Checks to make sure we have the correct backup file, and no context.xml. 
find $TCHOME_10/* -name $DN_FILE.$DDATE -ls 
TC_DP10=$(find $TCHOME_10/conf/* -name $DN_FILE.$DDATE -ls |wc -l)
if (($TC_DP10 != 1)); then 
	echo -e "Expected 1 $DN_FILE backup Files, ${RED}found $TC_DP10 Something went wrong! ${STD}Please check the screen output!"  
	error_exit "No backup file!"
	else
	echo -e "${GRN} Checking $DN_FILE backup files, looking for 1 found $TC_DP10.  Backup sucessful ${STD}" 
fi

find $TCHOME_10/conf/* -name $DN_FILE.$DDATE -ls 
TC_XML10=$(find $TCHOME_10/conf/* -name $DN_FILE.xml -ls |wc -l)
if (($TC_XML10 != 0)); then 
	echo -e "Expected 0 $DN_FILE XML Files, ${RED}found $TC_XML10 Something went wrong! ${STD}Please check the screen output!"  
	error_exit "Found XML file!"
	else
	echo -e "${GRN} Checking $DN_FILE xml files, looking for 0 found $TC_XML10.  Backup sucessful ${STD}" 
fi

# Copy the new file in place
su - tomcat -c "cp $DEPLOY_DIR/tomcat10/conf/$DN_FILE.xml $TCHOME_10/conf/$DN_FILE.xml"

# Checking to make sure that we have our context.xml now
TC_XML10=$(find $TCHOME_10/conf/* -name $DN_FILE.xml -ls |wc -l)
if (($TC_XML10 != 1)); then 
	echo -e "Expected 1 $DN_FILE XML Files, ${RED}found $TC_XML10 Something went wrong! ${STD}Please check the screen output!"  
	error_exit "Found XML file!"
	else
	echo -e "${GRN} Checking $DN_FILE xml files, looking for 1 found $TC_XML10.  Deployment sucessful ${STD}" 
fi

# Backup the current file
mv $TCHOME_12/conf/$DN_FILE.xml $TCHOME_12/conf/$DN_FILE.$DDATE

# Checks to make sure we have the correct backup file, and no context.xml. 
find $TCHOME_12/* -name $DN_FILE.$DDATE -ls 
TC_DP12=$(find $TCHOME_12/conf/* -name $DN_FILE.$DDATE -ls |wc -l)
if (($TC_DP12 != 1)); then 
	echo -e "Expected 1 $DN_FILE backup Files, ${RED}found $TC_DP12 Something went wrong! ${STD}Please check the screen output!"  
	error_exit "No backup file!"
	else
	echo -e "${GRN} Checking $DN_FILE backup files, looking for 1 found $TC_DP12.  Backup sucessful ${STD}" 
fi

find $TCHOME_12/conf/* -name $DN_FILE.$DDATE -ls 
TC_XML12=$(find $TCHOME_12/conf/* -name $DN_FILE.xml -ls |wc -l)
if (($TC_XML12 != 0)); then 
	echo -e "Expected 0 $DN_FILE XML Files, ${RED}found $TC_XML12 Something went wrong! ${STD}Please check the screen output!"  
	error_exit "Found XML file!"
	else
	echo -e "${GRN} Checking $DN_FILE xml files, looking for 0 found $TC_XML12.  Backup sucessful ${STD}" 
fi

# Copy the new file in place
su - tomcat -c "cp $DEPLOY_DIR/tomcat12/conf/$DN_FILE.xml $TCHOME_12/conf/$DN_FILE.xml"

# Checking to make sure that we have our context.xml now
TC_XML12=$(find $TCHOME_12/conf/* -name $DN_FILE.xml -ls |wc -l)
if (($TC_XML12 != 1)); then 
	echo -e "Expected 1 $DN_FILE XML Files, ${RED}found $TC_XML12 Something went wrong! ${STD}Please check the screen output!"  
	error_exit "Found XML file!"
	else
	echo -e "${GRN} Checking $DN_FILE xml files, looking for 1 found $TC_XML12.  Deployment sucessful ${STD}" 
fi

# Backup the current file
mv $TCHOME_14/conf/$DN_FILE.xml $TCHOME_14/conf/$DN_FILE.$DDATE

# Checks to make sure we have the correct backup file, and no context.xml. 
find $TCHOME_14/* -name $DN_FILE.$DDATE -ls 
TC_DP14=$(find $TCHOME_14/conf/* -name $DN_FILE.$DDATE -ls |wc -l)
if (($TC_DP14 != 1)); then 
	echo -e "Expected 1 $DN_FILE backup Files, ${RED}found $TC_DP14 Something went wrong! ${STD}Please check the screen output!"  
	error_exit "No backup file!"
	else
	echo -e "${GRN} Checking $DN_FILE backup files, looking for 1 found $TC_DP14.  Backup sucessful ${STD}" 
fi

find $TCHOME_14/* -name $DN_FILE.$DDATE -ls 
TC_XML14=$(find $TCHOME_14/conf/* -name $DN_FILE.xml -ls |wc -l)
if (($TC_XML14 != 0)); then 
	echo -e "Expected 0 $DN_FILE XML Files, ${RED}found $TC_XML14 Something went wrong! ${STD}Please check the screen output!"  
	error_exit "Found XML file!"
	else
	echo -e "${GRN} Checking $DN_FILE xml files, looking for 0 found $TC_XML14.  Backup sucessful ${STD}" 
fi

# Copy the new file in place
su - tomcat -c "cp $DEPLOY_DIR/tomcat14/conf/$DN_FILE.xml $TCHOME_14/conf/$DN_FILE.xml"

# Checking to make sure that we have our context.xml now
TC_XML14=$(find $TCHOME_14/conf/* -name $DN_FILE.xml -ls |wc -l)
if (($TC_XML14 != 1)); then 
	echo -e "Expected 1 $DN_FILE XML Files, ${RED}found $TC_XML14 Something went wrong! ${STD}Please check the screen output!"  
	error_exit "Found XML file!"
	else
	echo -e "${GRN} Checking $DN_FILE xml files, looking for 1 found $TC_XML14.  Deployment sucessful ${STD}" 
fi

# Backup the current file
mv $TCHOME_16/conf/$DN_FILE.xml $TCHOME_16/conf/$DN_FILE.$DDATE

# Checks to make sure we have the correct backup file, and no context.xml. 
find $TCHOME_16/* -name $DN_FILE.$DDATE -ls 
TC_DP16=$(find $TCHOME_16/conf/* -name $DN_FILE.$DDATE -ls |wc -l)
if (($TC_DP16 != 1)); then 
	echo -e "Expected 1 $DN_FILE backup Files, ${RED}found $TC_DP16 Something went wrong! ${STD}Please check the screen output!"  
	error_exit "No backup file!"
	else
	echo -e "${GRN} Checking $DN_FILE backup files, looking for 1 found $TC_DP16.  Backup sucessful ${STD}" 
fi

find $TCHOME_16/* -name $DN_FILE.$DDATE -ls 
TC_XML16=$(find $TCHOME_16/conf/* -name $DN_FILE.xml -ls |wc -l)
if (($TC_XML16 != 0)); then 
	echo -e "Expected 0 $DN_FILE XML Files, ${RED}found $TC_XML16 Something went wrong! ${STD}Please check the screen output!"  
	error_exit "Found XML file!"
	else
	echo -e "${GRN} Checking $DN_FILE xml files, looking for 0 found $TC_XML16.  Backup sucessful ${STD}" 
fi

# Copy the new file in place
su - tomcat -c "cp $DEPLOY_DIR/tomcat16/conf/$DN_FILE.xml $TCHOME_16/conf/$DN_FILE.xml"

# Checking to make sure that we have our context.xml now
TC_XML16=$(find $TCHOME_16/conf/* -name $DN_FILE.xml -ls |wc -l)
if (($TC_XML16 != 1)); then 
	echo -e "Expected 1 $DN_FILE XML Files, ${RED}found $TC_XML16 Something went wrong! ${STD}Please check the screen output!"  
	error_exit "Found XML file!"
	else
	echo -e "${GRN} Checking $DN_FILE xml files, looking for 1 found $TC_XML16.  Deployment sucessful ${STD}" 
fi

# Backup the current file
mv $TCHOME_18/conf/$DN_FILE.xml $TCHOME_18/conf/$DN_FILE.$DDATE

# Checks to make sure we have the correct backup file, and no context.xml. 
find $TCHOME_18/* -name $DN_FILE.$DDATE -ls 
TC_DP18=$(find $TCHOME_18/conf/* -name $DN_FILE.$DDATE -ls |wc -l)
if (($TC_DP18 != 1)); then 
	echo -e "Expected 1 $DN_FILE backup Files, ${RED}found $TC_DP18 Something went wrong! ${STD}Please check the screen output!"  
	error_exit "No backup file!"
	else
	echo -e "${GRN} Checking $DN_FILE backup files, looking for 1 found $TC_DP18. Backup sucessful ${STD}" 
fi

find $TCHOME_18/* -name $DN_FILE.$DDATE -ls 
TC_XML18=$(find $TCHOME_18/conf/* -name $DN_FILE.xml -ls |wc -l)
if (($TC_XML18 != 0)); then 
	echo -e "Expected 0 $DN_FILE XML Files, ${RED}found $TC_XML18 Something went wrong! ${STD}Please check the screen output!"  
	error_exit "Found XML file!"
	else
	echo -e "${GRN} Checking $DN_FILE xml files, looking for 0 found $TC_XML18. Backup sucessful ${STD}" 
fi

# Copy the new file in place
su - tomcat -c "cp $DEPLOY_DIR/tomcat18/conf/$DN_FILE.xml $TCHOME_18/conf/$DN_FILE.xml"

# Checking to make sure that we have our context.xml now
TC_XML18=$(find $TCHOME_18/conf/* -name $DN_FILE.xml -ls |wc -l)
if (($TC_XML18 != 1)); then 
	echo -e "Expected 1 $DN_FILE XML Files, ${RED}found $TC_XML18 Something went wrong! ${STD}Please check the screen output!"  
	error_exit "Found XML file!"
	else
	echo -e "${GRN} Checking $DN_FILE xml files, looking for 1 found $TC_XML18. Deployment sucessful ${STD}" 
fi

# Backup the current file
mv $TCHOME_20/conf/$DN_FILE.xml $TCHOME_20/conf/$DN_FILE.$DDATE

# Checks to make sure we have the correct backup file, and no context.xml. 
find $TCHOME_20/* -name $DN_FILE.$DDATE -ls 
TC_DP20=$(find $TCHOME_20/conf/* -name $DN_FILE.$DDATE -ls |wc -l)
if (($TC_DP20 != 1)); then 
	echo -e "Expected 1 $DN_FILE backup Files, ${RED}found $TC_DP20 Something went wrong! ${STD}Please check the screen output!"  
	error_exit "No backup file!"
	else
	echo -e "${GRN} Checking $DN_FILE backup files, looking for 1 found $TC_DP20. Backup sucessful ${STD}" 
fi

find $TCHOME_20/* -name $DN_FILE.$DDATE -ls 
TC_XML20=$(find $TCHOME_20/conf/* -name $DN_FILE.xml -ls |wc -l)
if (($TC_XML20 != 0)); then 
	echo -e "Expected 0 $DN_FILE XML Files, ${RED}found $TC_XML20 Something went wrong! ${STD}Please check the screen output!"  
	error_exit "Found XML file!"
	else
	echo -e "${GRN} Checking $DN_FILE xml files, looking for 0 found $TC_XML20. Backup sucessful ${STD}" 
fi

# Copy the new file in place
su - tomcat -c "cp $DEPLOY_DIR/tomcat20/conf/$DN_FILE.xml $TCHOME_20/conf/$DN_FILE.xml"

# Checking to make sure that we have our context.xml now
TC_XML20=$(find $TCHOME_20/conf/* -name $DN_FILE.xml -ls |wc -l)
if (($TC_XML20 != 1)); then 
	echo -e "Expected 1 $DN_FILE XML Files, ${RED}found $TC_XML20 Something went wrong! ${STD}Please check the screen output!"  
	error_exit "Found XML file!"
	else
	echo -e "${GRN} Checking $DN_FILE xml files, looking for 1 found $TC_XML20. Deployment sucessful ${STD}" 
fi

# bring Up the Tomcats 
echo -e "${GRN} Starting Odd Tomcats. ${STD}"
su tomcat -c "/tomcat/tomcat02/bin/startup.sh"
su tomcat -c "/tomcat/tomcat04/bin/startup.sh"
su tomcat -c "/tomcat/tomcat06/bin/startup.sh"
su tomcat -c "/tomcat/tomcat08/bin/startup.sh"
su tomcat -c "/tomcat/tomcat10/bin/startup.sh"
su tomcat -c "/tomcat/tomcat12/bin/startup.sh"
su tomcat -c "/tomcat/tomcat14/bin/startup.sh"
su tomcat -c "/tomcat/tomcat16/bin/startup.sh"
su tomcat -c "/tomcat/tomcat18/bin/startup.sh"
su tomcat -c "/tomcat/tomcat20/bin/startup.sh"
sleep 60

echo -e "${GRN} Enabling the Odd Tomcats.  Waiting 60 seconds to start. ${STD}"
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP2" &> /dev/null
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP4" &> /dev/null
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP6" &> /dev/null
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP8" &> /dev/null
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP10" &> /dev/null
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP12" &> /dev/null
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP14" &> /dev/null
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP16" &> /dev/null
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP18" &> /dev/null
wget -qO- --http-user=apacheadmin --http-passwd=T0mcat*22 "$URLCATUP20" &> /dev/null
sleep 60

# Checks to make sure we have the right number of tomcats running. 
TC_DP=$( TCRUN )
if (($TC_DP != $TCR)); then 
	echo -e "Expected $TCR Tocmats, ${RED}found $TC_DP Something went wrong! ${STD}Please check the screen output!"
    error_exit "Too many Tomcats!  Check Screen output."	
	else
	echo -e "${GRN} Checking Tomcats, looking for $TCR found $TC_DP.  Shutdown sucessful ${STD}" 
fi

# Deployment complete, now to start the clean up.    
echo -e "${GRN} New $DN_FILE deployed. ${STD}"
 echo -e "${GRN} Removing deployment file. ${STD}"
	rm $i 
done
rm -rf "$LOCKDIR"
trap - INT TERM EXIT
fi

# Final Checks to make sure we get the correct number of war files after we are done. 
find $TCHOME -name $DN_FILE.war -ls 
TC_DF=$(find $TCHOME -name $DN_FILE.xml -ls |wc -l)
if (($TC_DF != $TCF)); then 
	echo -e "Expected $TCF $DN_FILE War Files, ${RED}found $TC_DF Something went wrong! ${STD}Please check the screen output!"  
	else
	echo -e "${GRN} Checking $DN_FILE war files, looking for $TCF found $TC_DF.  Deployment sucessful ${STD}" 
fi
read -p  "Press any key to continue... " -n1 -s
