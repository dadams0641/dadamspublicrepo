#!/bin/bash
# Version 1.2.16
# 1.1.0 Added uid to user accounts to remain consistant. 
# 1.2.0 Added the software repo stuff to the script.  Pulling it out of the first run. 
# 1.2.0 added error_exit function
# 1.2.0 added root checking
# 1.2.1 clearified the environment question
# 1.2.2 fixed error_exit function.  
# 1.2.3 added some sleep timers in to make sure packages install. 
# 1.2.3 fixed software repo variables.
# 1.2.4 changed the method for determining if this is prod or non-prod. 
# 1.2.5 added cronolog package per Ronald's request. 
# 1.2.6 Fixed the $ACCOUNTID variable. 
# 1.2.7 Fixed UIDs for accounts.
# 1.2.7 Added creation of the WebSphere directory
# 1.2.8 Added mailx package to the install
# 1.2.9 Added setting up the WebSphere drive
# 1.2.9 Added in copying over Ronald's SSH Key.
# 1.2.10 Added the at package.  
# 1.2.11 Added additional packages required. 
# 1.2.12 Added two more additional packages required. 
# 1.2.13 Added Harry Mottley
# 1.2.14 Changed how we handle the sudoers for WebSphere
# 1.2.15 Made Ronald the owner of his SSH key.  
# 1.2.16 Modified this to be the Apache setup script
# Written by Drew

sftwrepo_prod=/var/local/first/sftwrepo_prod.txt
sftwrepo_nonprod=/var/local/first/sftwrepo_nonprod.txt
hosts=/etc/hosts
instance="$(curl -s http://169.254.169.254/latest/dynamic/instance-identity/document |jq -r '.availabilityZone')"
ACCOUNTID="$(curl -s http://169.254.169.254/latest/dynamic/instance-identity/document |jq -r '.accountId')"

# Add some color to the messages. 
RED='\033[0;41;30m'
STD='\033[0;0;39m'
GRN='\033[30;48;5;82m'
BLU='\033[0;44;97m'

#Check the exit status
error_exit()
{
        echo -e "$1" 1>&2
        exit 1
}

# Check to see if this is being run as Root or not.  
#
if [ $(id -u) != "0" ]; then
    error_exit "${RED}You must be the superuser to run this script ${STD}"
fi

# Enable the optional packages, we need this for compat-libstdc++
echo -e "${GRN}Enabling the Optional packages${STD}"
yum-config-manager --enable rhui-REGION-rhel-server-optional

# Installing all needed packages.  
echo -e "${BLU}Checking and installing dependancies ${STD}"
if ! rpm -qa |grep -qw 'mailx.x86_64'; then
        yum install mailx.x86_64 -y
fi
sleep 10
if ! rpm -qa |grep -qw 'at.x86_64'; then
        yum install at.x86_64 -y
fi
sleep 10
if ! rpm -qa |grep -qw 'gtk2.x86_64 '; then
        yum install gtk2.x86_64  -y
fi
sleep 10
if ! rpm -qa |grep -qw 'httpd '; then
        yum install httpd -y
fi


# Adding the wbsphere group for WebSphere
echo -e "${BLU}Adding wbsphere group ${STD}"
groupadd wbsphere

echo -e "${BLU}Adding WebSphere users ${STD}"
useradd -u 1009 -G wbsphere,apache wpsadmin
useradd -u 1010 -G wbsphere,apache rarguell
useradd -u 1011 -G wbsphere,apache locdang
useradd -u 1012 -G wbsphere,apache whazelwo
useradd -u 1018 -G wbsphere,apache hmottley

# Copy the file so we can setup the ulimits for the wpsadmin account. 
echo -e "${BLU}Setting up ulimits for the wpsadmin account. ${STD}"
cp /var/local/first/limits.conf /etc/security/limits.conf

# Determine which Amazon Account we are in, and add the correct set of Repositories. 
if [ $ACCOUNTID -eq "996190702173" ]
	then 
	# add host names for the Software Repository. 
	echo -e "${BLU}adding the Non-Prod software repo EFS to the hosts file${STD}"
	cat "$sftwrepo_nonprod" >> "$hosts"
	else
	if [ $ACCOUNTID -eq "598747928121" ]
		then 
		# add host names for the Software Repository. 
		echo -e "${BLU}adding the Prod software repo EFS to the hosts file${STD}"
		cat "$sftwrepo_prod" >> "$hosts"
		else
		if [ -z $ACCOUNTID ]; then
			error_exit "${RED}Error: no recognized environment. Exiting. ${STD}"
		fi
	fi
fi

# Add the software Repository to fstab. 
echo -e "${BLU}Adding the software repo EFS NFS to fstab for easy mounting${STD}"
echo -e "$instance-sftwrepo:/\t/sftwr-repo\tnfs\trsize=1048576,wsize=1048576,hard,timeo=600,retrans=2,noauto" >>/etc/fstab 

# Checking for the directory
echo "Checking for Software Repo directory"
if [ -d /sftwr-repo ]
then 
    echo "Software Repo exists"
        else 
        mkdir -p -m 777 /sftwr-repo 
        echo "Software Repo created"
fi

# Checking for the Apache directory
echo -e "${BLU} Checking for the Apache Directory ${STD}"
if [ -d /Apache ]
then
	echo -e "${GRN} Apache directory exists ${STD}"
		else
		mkdir /Apache
		chown apache:apache /Apache
		echo "Apache Directory created"
fi

# Adding the disk for /Apache
echo -e "${BLU} Creating Apache disk ${STD}"
pvcreate  /dev/nvme1n1
vgcreate datavg /dev/nvme1n1
lvcreate -L 10G -n apachelv datavg
lvcreate -L 10G -n apacheloglv datavg
mkfs.xfs /dev/datavg/apachelv
mkfs.xfs /dev/datavg/apacheloglv
mount /dev/datavg/apachelv /Apache/
mount /dev/datavg/apacheloglv /var/log/httpd
echo -e "/dev/mapper/datavg-apachelv\t\t/Apache\t\txfs\t\t\tdefaults\t\t0 0" >>/etc/fstab
echo -e "/dev/mapper/datavg-apacheloglv\t\t/var/log/httpd\t\txfs\t\t\tdefaults\t\t0 0" >>/etc/fstab

# Checking for the Apache directory
echo -e "${BLU} Checking for the Apache WWW Directories ${STD}"
if [ -d /Apache/www ]
then
	echo -e "${GRN} Apache WWW directory exists ${STD}"
		else
		mkdir /Apache/www
		chown apache:apache /Apache/www
		echo "Apache WWW Directory created"
fi
# Checking for the Apache directory
echo -e "${BLU} Checking for the Apache CGI Directory ${STD}"
if [ -d /Apache/cgi-bin ]
then
	echo -e "${GRN} Apache CGI directory exists ${STD}"
		else
		mkdir /Apache/cgi-bin
		chown apache:apache /Apache/cgi-bin
		echo "Apache CGI Directory created"
fi
# Creating symlink for the logs
if [ -L /Apache/logs ] 
then 
	echo -e "${GRN} Apache Log Symnlink exists ${STD}"
	else
	ln -s /var/log/httpd/ /Apache/logs
	echo "Apache Log Symnlink created"
fi

# Enabling Apache to start on boot. 
systemctl enable httpd

# Adding SSH Keys to home directories.
echo -e "${GRN}  ${STD}" 
mount /sftwr-repo
sudo mkdir /home/rarguell/.ssh
cp /sftwr-repo/Unix/rarguell/authorized_keys /home/rarguell/.ssh/
sudo chown -R rarguell:rarguell /home/rarguell/.ssh
sudo chmod 700 /home/rarguell/.ssh/
sudo chmod 600 /home/rarguell/.ssh/authorized_keys
sleep 20
umount /sftwr-repo

# Give the wbsphere group root privileges
cp /var/local/first/sudoers/wbsphere /etc/sudoers.d/


echo -e "${GRN}System updated. ${STD}"

