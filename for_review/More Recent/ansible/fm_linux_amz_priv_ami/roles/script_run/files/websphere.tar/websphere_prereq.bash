#!/bin/bash
# Version 2.0.2
# Rewrote the package install, changed groupings to midadmin, and added Shanice Jordan
# 2.0.1 We need to add the sudoers file to be copied over as well.  
# 2.0.2 Fixed misspelled variables, and other mispellings
# Written by Drew

sftwrepo_prod=/var/local/first/sftwrepo_prod.txt
sftwrepo_nonprod=/var/local/first/sftwrepo_nonprod.txt
hosts=/etc/hosts
instance="$(curl -s http://169.254.169.254/latest/dynamic/instance-identity/document |jq -r '.availabilityZone')"
ACCOUNTID="$(curl -s http://169.254.169.254/latest/dynamic/instance-identity/document |jq -r '.accountId')"

# Sudoers file
MIDADMSU=/var/local/first/sudoers/wbsphere
SUDOERSD=/etc/sudoers.d/

# Packages to install
compatdb=compat-db.x86_64
glibc32=glibc.i686
glibc=glibc.x86_64
gtk32=gtk2-engines.i686
gtk=gtk2-engines.x86_64
libxf32=libXft.i686
libmu32=libXmu.i686
libmu=libXmu.x86_64
libxts32=libXtst.i686
libxts=libXtst.x86_64
libgcc32=libgcc.i686
libgcc=libgcc.x86_64
glibc=glibc.x86_64
glibc32=glibc.i686
nss32=nss-softokn.i686
nss=nss-softokn.x86_64
compat32=compat-libstdc++-33.i686
compat=compat-libstdc++-33.x86_64
cronolog=cronolog.x86_64
mailx=mailx.x86_64
AT=at.x86_64
compatdb32=compat-db47.i686
compatdb=compat-db47.x86_64
gtk232=gtk2.i686
gtk2=gtk2.x86_64 
ksh=ksh.x86_64
gkt332=PackageKit-gtk3-module.i686
libcanb32=libcanberra-gtk2.i686

# Add some color to the messages. 
RED='\033[0;41;30m'
STD='\033[0;0;39m'
GRN='\033[30;48;5;82m'
BLU='\033[0;44;97m'

#Check the exit status
error_exit()
{
        echo -e "$1" 1>&2
        exit 1
}

# Check to see if this is being run as Root or not.  
#
if [ $(id -u) != "0" ]; then
    error_exit "${RED}You must be the superuser to run this script ${STD}"
fi

# Enable the optional packages, we need this for compat-libstdc++
echo -e "${GRN}Enabling the Optional packages${STD}"
yum-config-manager --enable rhui-REGION-rhel-server-optional

echo -e "${BLU}Checking and installing dependancies ${STD}"
install_rpm()
{
	# Install RPM packages if they need to be installed
	echo -e "Checking on package $1"
	if ! rpm -qa |grep -qw $1 ; then
		yum install $1 -y
	fi
	sleep 20
}

install_rpm $compatdb
install_rpm $glibc32
install_rpm $glibc
install_rpm $gtk32
install_rpm $gtk
install_rpm $libxf32
install_rpm $libmu32
install_rpm $libmu
install_rpm $libxts32
install_rpm $libxts
install_rpm $libgcc32
install_rpm $libgcc
install_rpm $glibc
install_rpm $glibc32
install_rpm $nss32
install_rpm $nss
install_rpm $compat32
install_rpm $compat
install_rpm $cronolog
install_rpm $mailx
install_rpm $AT
install_rpm $compatdb32
install_rpm $compatdb
install_rpm $gtk232
install_rpm $gtk2
install_rpm $ksh
install_rpm $gkt332
install_rpm $libcanb32

# Adding the wbsphere group for WebSphere
echo -e "${BLU}Adding wbsphere group ${STD}"
groupadd wbsphere
groupadd midadmin

echo -e "${BLU}Adding WebSphere users ${STD}"
useradd -u 1009 -g wbsphere -G wbsphere wpsadmin
useradd -u 1010 -g wbsphere -G wbsphere,midadmin -c "Ronald Arguello" rarguell
useradd -u 1011 -g wbsphere -G wbsphere,midadmin -c "Loc Dang" locdang
useradd -u 1012 -g wbsphere -G wbsphere,midadmin -c "William Hazelwood" whazelwo
useradd -u 1018 -g wbsphere -G wbsphere,midadmin -c "Harry Mottley" hmottley
useradd -u 1019 -g wbsphere -G wbsphere,midadmin -c "Shaneice Jordan" shjorda2

cp $MIDADMSU $SUDOERSD


# Copy the file so we can setup the ulimits for the wpsadmin account. 
echo -e "${BLU}Setting up ulimits for the wpsadmin account. ${STD}"
cp /var/local/first/limits.conf /etc/security/limits.conf

# Determine which Amazon Account we are in, and add the correct set of Repositories. 
if [ $ACCOUNTID -eq "996190702173" ]
	then 
	# add host names for the Software Repository. 
	echo -e "${BLU}adding the Non-Prod software repo EFS to the hosts file${STD}"
	cat "$sftwrepo_nonprod" >> "$hosts"
	else
	if [ $ACCOUNTID -eq "598747928121" ]
		then 
		# add host names for the Software Repository. 
		echo -e "${BLU}adding the Prod software repo EFS to the hosts file${STD}"
		cat "$sftwrepo_prod" >> "$hosts"
		else
		if [ -z $ACCOUNTID ]; then
			error_exit "${RED}Error: no recognized environment. Exiting. ${STD}"
		fi
	fi
fi

# Add the software Repository to fstab. 
echo -e "${BLU}Adding the software repo EFS NFS to fstab for easy mounting${STD}"
echo -e "$instance-sftwrepo:/\t/sftwr-repo\tnfs\trsize=1048576,wsize=1048576,hard,timeo=600,retrans=2,noauto" >>/etc/fstab 

# Checking for the directory
echo "Checking for Software Repo directory"
if [ -d /sftwr-repo ]
then 
    echo "Software Repo exists"
        else 
        mkdir -p -m 777 /sftwr-repo 
        echo "Software Repo created"
fi

# Checking for the WebSphere directory
echo -e "${BLU} Checking for the WebSphere Directory ${STD}"
if [ -d /WebSphere ]
then
	echo -e "${GRN} WebSphere directory exists ${STD}"
		else
		mkdir /WebSphere
		chown wpsadmin:wbsphere /WebSphere
		echo "WebSphere Directory created"
fi

# Adding the disk for /WebSphere
echo -e "${BLU} Creating WebSphere disk ${STD}"
pvcreate  /dev/nvme1n1 
vgcreate datavg /dev/nvme1n1
lvcreate -L 30G -n webspherelv datavg
mkfs.xfs /dev/datavg/webspherelv
mount /dev/datavg/webspherelv /WebSphere/
echo -e "/dev/mapper/datavg-webspherelv\t\t/WebSphere\t\txfs\t\t\tdefaults\t\t0 0" >>/etc/fstab

# Adding SSH Keys to home directories.
echo -e "${GRN}  ${STD}" 
mount /sftwr-repo
sudo mkdir /home/rarguell/.ssh
cp /sftwr-repo/Unix/rarguell/authorized_keys /home/rarguell/.ssh/
sudo chown rarguell:midadmin /home/rarguell/.ssh
sudo chmod 700 /home/rarguell/.ssh/
sudo chmod 600 /home/rarguell/.ssh/authorized_keys
sleep 20
umount /sftwr-repo

echo -e "${GRN}System updated. ${STD}"

