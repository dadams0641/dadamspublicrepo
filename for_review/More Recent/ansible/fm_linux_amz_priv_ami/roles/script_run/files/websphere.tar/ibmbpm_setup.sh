#!/bin/bash
# Version 1.1
# Script to do what is needed for WebSphere to install WebSphere for IBM BPM
# 1.0.0 Initial edit from the Amazon websphere_prereq.sh
# 1.0.1 Fixed setting permissions for Ronald's ssh key.  
# 1.1.0 Added create directory function

# Written by Drew

# Variables needed for the script to work.
######################################################################################
# These Variables will need to be edited.  
FILEUSER=wpsadmin
FILEGROUP=wbsphere
RETAIL=/BPMRET
WHOLESALE=/BPMWHL
SPG=/BPMSPG
PFS=/BPMPFS
BPMTMP=/BPMTMP
REPODIR=/sftwr-repo
#######################################################################################
# These variables may need to be edited.  

#######################################################################################
# Variables below should not need to be edited. 
sftwrepo_prod=/var/local/first/sftwrepo_prod.txt
sftwrepo_nonprod=/var/local/first/sftwrepo_nonprod.txt
HOSTSFILE=/etc/hosts
LOCALDISKS=/var/local/first/BPM/ibmbpmdisks.txt
FSTAB=/etc/fstab
instance="$(curl -s http://169.254.169.254/latest/dynamic/instance-identity/document |jq -r '.availabilityZone')"
ACCOUNTID="$(curl -s http://169.254.169.254/latest/dynamic/instance-identity/document |jq -r '.accountId')"


# Add some color to the messages. 
RED='\033[0;41;30m'
STD='\033[0;0;39m'
GRN='\033[30;48;5;82m'
BLU='\033[0;44;97m'

#Check the exit status
error_exit()
{
        echo -e "$1" 1>&2
        exit 1
}

create_dir()
{
    # Creating directories needed if they are not there.
    # This is the PID directory. So that we only run the script once.
    if [ -d $1 ]
        then
            echo -e "${BLU} $1 Directory exists ${STD}"
        else
        mkdir -p -m $2 $1
        chown wpsadmin:wbsphere $1
        echo -e "${GRN} $1 Directory created ${STD}"
    fi
}


# Check to see if this is being run as Root or not.  
#
if [ $(id -u) != "0" ]; then
    error_exit "${RED}You must be the superuser to run this script ${STD}"
fi

# Enable the optional packages, we need this for compat-libstdc++
echo -e "${GRN}Enabling the Optional packages${STD}"
yum-config-manager --enable rhui-REGION-rhel-server-optional

# Installing all needed packages.  
echo -e "${BLU}Checking and installing dependancies ${STD}"
if ! rpm -qa |grep -qw 'compat-db.i686'; then
        yum install compat-db.i686 -y
fi
sleep 10
if ! rpm -qa |grep -qw 'compat-db.x86_64'; then
        yum install compat-db.x86_64 -y
fi
sleep 10
if ! rpm -qa |grep -qw 'glibc.i686'; then
        yum install glibc.i686 -y
fi
sleep 10
if ! rpm -qa |grep -qw 'glibc.x86_64'; then
        yum install glibc.x86_64 -y
fi
sleep 10
if ! rpm -qa |grep -qw 'gtk2-engines.i686'; then
        yum install gtk2-engines.i686 -y
fi
sleep 10
if ! rpm -qa |grep -qw 'gtk2-engines.x86_64'; then
        yum install gtk2-engines.x86_64 -y
fi
sleep 10
if ! rpm -qa |grep -qw 'libXft.i686'; then
        yum install libXft.i686 -y
fi
sleep 10
if ! rpm -qa |grep -qw 'libXmu.i686'; then
        yum install libXmu.i686 -y
fi
sleep 10
if ! rpm -qa |grep -qw 'libXmu.x86_64'; then
        yum install libXmu.x86_64 -y
fi
sleep 10
if ! rpm -qa |grep -qw 'libXtst.i686'; then
        yum install libXtst.i686 -y
fi
sleep 10
if ! rpm -qa |grep -qw 'libXtst.x86_64'; then
        yum install libXtst.x86_64 -y
fi
sleep 10
if ! rpm -qa |grep -qw 'libgcc.i686'; then
        yum install libgcc.i686 -y
fi
sleep 10
if ! rpm -qa |grep -qw 'libgcc.x86_64'; then
        yum install libgcc.x86_64 -y
fi
sleep 10
if ! rpm -qa |grep -qw 'glibc.x86_64'; then
        yum install glibc.x86_64 -y
fi
sleep 10
if ! rpm -qa |grep -qw 'glibc.i686'; then
        yum install glibc.i686 -y
fi
sleep 10
if ! rpm -qa |grep -qw 'nss-softokn.i686'; then
        yum install nss-softokn.i686 -y
fi
sleep 10
if ! rpm -qa |grep -qw 'nss-softokn.x86_64'; then
        yum install nss-softokn.x86_64 -y
fi
sleep 10
if ! rpm -qa |grep -qw 'compat-libstdc++-33.i686'; then
        yum install compat-libstdc++-33.i686 -y
fi
sleep 10
if ! rpm -qa |grep -qw 'compat-libstdc++-33.x86_64'; then
        yum install compat-libstdc++-33.x86_64 -y
fi
sleep 10
if ! rpm -qa |grep -qw 'cronolog.x86_64'; then
        yum install cronolog.x86_64 -y
fi
sleep 10
if ! rpm -qa |grep -qw 'mailx.x86_64'; then
        yum install mailx.x86_64 -y
fi
sleep 10
if ! rpm -qa |grep -qw 'at.x86_64'; then
        yum install at.x86_64 -y
fi
sleep 10
if ! rpm -qa |grep -qw 'compat-db47.i686'; then
        yum install compat-db47.i686 -y
fi
sleep 10
if ! rpm -qa |grep -qw 'compat-db47.x86_64 '; then
        yum install compat-db47.x86_64  -y
fi
sleep 10
if ! rpm -qa |grep -qw 'gtk2.i686 '; then
        yum install gtk2.i686  -y
fi
sleep 10
if ! rpm -qa |grep -qw 'gtk2.x86_64 '; then
        yum install gtk2.x86_64  -y
fi
sleep 10
if ! rpm -qa |grep -qw 'ksh.x86_64 '; then
        yum install ksh.x86_64  -y
fi
sleep 10
if ! rpm -qa |grep -qw 'PackageKit-gtk3-module.i686 '; then
        yum install PackageKit-gtk3-module.i686  -y
fi
sleep 10
if ! rpm -qa |grep -qw 'libcanberra-gtk2.i686 '; then
        yum install libcanberra-gtk2.i686 -y
fi
sleep 10
if ! rpm -aq |grep -qw 'java-1.8.0-openjdk.x86_64 '; then
		yum install java-1.8.0-openjdk.x86_64 -y 
fi
sleep 10

# Adding the wbsphere group for WebSphere
echo -e "${BLU}Adding wbsphere group ${STD}"
groupadd wbsphere

echo -e "${BLU}Adding WebSphere users ${STD}"
useradd -u 1009 -G wbsphere wpsadmin
useradd -u 1010 -G wbsphere rarguell
useradd -u 1011 -G wbsphere locdang
useradd -u 1012 -G wbsphere whazelwo
useradd -u 1018 -G wbsphere hmottley

# Copy the file so we can setup the ulimits for the wpsadmin account. 
echo -e "${BLU}Setting up ulimits for the wpsadmin account. ${STD}"
cp /var/local/first/limits.conf /etc/security/limits.conf


# Determine which Amazon Account we are in, and add the correct set of Repositories. 
if [ $ACCOUNTID -eq "996190702173" ]
	then 
	# add host names for the Software Repository. 
	echo -e "${BLU}adding the Non-Prod software repo EFS to the hosts file${STD}"
	cat "$sftwrepo_nonprod" >> "$HOSTSFILE"
	else
	if [ $ACCOUNTID -eq "598747928121" ]
		then 
		# add host names for the Software Repository. 
		echo -e "${BLU}adding the Prod software repo EFS to the hosts file${STD}"
		cat "$sftwrepo_prod" >> "$HOSTSFILE"
		else
		if [ -z $ACCOUNTID ]; then
			error_exit "${RED}Error: no recognized environment. Exiting. ${STD}"
		fi
	fi
fi

# Add the software Repository to fstab. 
echo -e "${BLU}Adding the software repo EFS NFS to fstab for easy mounting${STD}"
echo -e "$instance-sftwrepo:/\t/sftwr-repo\tnfs\trsize=1048576,wsize=1048576,hard,timeo=600,retrans=2,noauto" >>/etc/fstab 

create_dir $REPODIR 777

# setup the disks
# Setup the Physical disks
pvcreate /dev/xvdc /dev/xvdd /dev/xvde /dev/xvdf /dev/xvdg

# Setup the Volume Groups
vgcreate retdatavg /dev/xvdc
vgcreate whldatavg /dev/xvdd
vgcreate spgdatavg /dev/xvde
vgcreate tmpdatavg /dev/xvdf
vgcreate pfsdatavg /dev/xvdg
sleep 20

# Create Logical volumes
lvcreate -L 40G -n bpmretlv retdatavg
lvcreate -L 40G -n bpmwhllv whldatavg
lvcreate -L 40G -n bpmspglv spgdatavg 
lvcreate -L 40G -n bpmtmplv tmpdatavg
lvcreate -L 40G -n bpmpfslv pfsdatavg
sleep 20

# Format the disks
mkfs.xfs /dev/retdatavg/bpmretlv
sleep 20
mkfs.xfs /dev/whldatavg/bpmwhllv
sleep 20
mkfs.xfs /dev/spgdatavg/bpmspglv
sleep 20
mkfs.xfs /dev/tmpdatavg/bpmtmplv
sleep 20
mkfs.xfs /dev/pfsdatavg/bpmpfslv
sleep 20

create_dir $RETAIL 775
create_dir $WHOLESALE 775
create_dir $SPG 775
create_dir $PFS 775
create_dir $BPMTMP 775

# echo -e "${BLU}adding the EDM EFS mount servers to the Hosts file ${STD}"
echo -e "${BLU}Adding Mount Points to the FSTAB ${STD}"
cat "$LOCALDISKS" >> "$FSTAB"
sleep 10 

# Adding SSH Keys to home directories.
echo -e "${GRN}  ${STD}" 
mount /sftwr-repo 
mkdir /home/rarguell/.ssh
cp /sftwr-repo/Unix/rarguell/authorized_keys /home/rarguell/.ssh/
chown -R rarguell:rarguell /home/rarguell/.ssh
chmod 700 /home/rarguell/.ssh/
chmod 600 /home/rarguell/.ssh/authorized_keys
sleep 20
umount /sftwr-repo

# Give the wbsphere group root privileges
cp /var/local/first/sudoers/wbsphere /etc/sudoers.d/

# Mounting all mount points
mount -a












