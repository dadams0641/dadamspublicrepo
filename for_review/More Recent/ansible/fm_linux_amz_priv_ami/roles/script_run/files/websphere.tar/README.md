# websphere_prereq
Script to install the needed packages, accounts, and mount point
