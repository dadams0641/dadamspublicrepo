#!/bin/bash
# Version 1.2.9
# This version works on RedHat 7, but not on RedHat 6. 
# 1.2.4 added prod & non-prod Software Repos. 
# 1.2.5 changed wording on some status messages
# 1.2.5 Fixed the Software Repo variables. 
# 1.2.6 Pulled Software Repo section out to move it to the WebSphere script.
# 1.2.7 Added where we update the system as well to this script. 
# 1.2.7 Added Color messages
# 1.2.8 fixed color messages
# 1.2.9 fixed some coding that was lost between versions.  
# Written by Drew. 
#
# Variables
#
hosts=/etc/hosts
instance="$(curl -s http://169.254.169.254/latest/dynamic/instance-identity/document |jq -r '.availabilityZone')"

# Check to see if this is being run as Root or not.  
#
if [ $(id -u) != "0" ]; then
    echo "You must be the superuser to run this script" >&2
    exit 1
fi

# The below script was found on the CentOS blog written by Curtis K
# URL: https://www.centosblog.com/script-update-centos-linux-servers-hostname

OLD_HOSTNAME="$( hostname )"
NEW_HOSTNAME="$1"

if [ -z "$NEW_HOSTNAME" ]; then
 echo -n "Please enter new hostname: "
 read NEW_HOSTNAME < /dev/tty
fi

if [ -z "$NEW_HOSTNAME" ]; then
 echo "Error: no hostname entered. Exiting."
 exit 1
fi

echo "Changing hostname from $OLD_HOSTNAME to $NEW_HOSTNAME..."

hostnamectl set-hostname "$NEW_HOSTNAME".fhmc.local --static

# hostname "$NEW_HOSTNAME"
# sed -i "s/HOSTNAME=.*/HOSTNAME=$NEW_HOSTNAME/g" /etc/sysconfig/network

if [ -n "$( grep "$OLD_HOSTNAME" /etc/hosts )" ]; then
 sed -i "s/$OLD_HOSTNAME/$NEW_HOSTNAME/g" /etc/hosts
else
 echo -e "$( hostname -I | awk '{ print $1 }' )\t$NEW_HOSTNAME" >> /etc/hosts
fi

# Back to the stuff I wrote - Drew.
# Copy an SSHD config file over that is setup like we need
echo "Overwriting the SSHD Config with a corrected config"
cp /var/local/first/sshd_config /etc/ssh/sshd_config

# Starting Xymon service
echo "setting Xymon to start on boot"
# chkconfig xymon-client on 
# systemctl enable xymon-client.service
systemctl start xymon-client.service

# Restart Xymon Service
echo "Restarting Xymon"
# service xymon-client restart
systemctl restart xymon-client.service


# restart the SSHD service after we have the corrected sshd_config file in place
echo "Restarting SSHD to make the new config take effect"
# service sshd restart
systemctl restart sshd.service


# Locking the ec2-user account, and setting shell to nologin
echo " locking ec2-user "
usermod -s /sbin/nologin ec2-user

# Updating the system to current
echo -e "${BLU} Updating all packages to current ${STD}"
sleep 10
yum update -y 

echo "Done."