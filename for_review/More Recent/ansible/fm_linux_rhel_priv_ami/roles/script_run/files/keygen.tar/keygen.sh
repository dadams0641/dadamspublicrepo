#!/bin/bash
# v1.1.1
##################################################
# v1.0.0 - Written by Drew Happli - 10/09/2019   #
#   automate key generation and copying to       #
#   remote servers.                              #
##################################################
# v1.1.0 - Drew Happli - 10/16/2019              #
#   Made the script a little cleaner             #
##################################################

# Variables
# Add some color to the messages. 
RED='\033[0;41;30m'
STD='\033[0;0;39m'
GRN='\033[30;48;5;82m'
BLU='\033[0;44;97m'

# Do we have a hostname?
if [ -z "$1" ]
	then
	echo "${RED}Please include a server you want your SSH Key to be copied to"
	echo "Example: /usr/local/bin/keygen.sh <server>"
	echo "         /usr/local/bin/keygen.sh lkwdev1 ${STD}"
	exit 1
	elif [ -f ~/.ssh/id_*.pub ]
		then
			ssh-copy-id $USER@$1
		else
			ssh-keygen -b 4096 -t rsa -q 
			ssh-copy-id $USER@$1
fi
